﻿app.controller('PackingHOLandingController', ['$scope', 'Applicationservice', '$rootScope', '$window', '$filter', '$timeout', '$location', 'AppURL', function ($scope, Applicationservice, $rootScope, $window, $filter, $timeout, $location, AppURL) {

    $scope.redirecttoplant = function () {
        $window.location.assign(AppURL + '/dashboard/Plant_Details/')
    };


    $scope.varBrand_ID = '';
    $scope.varPlant_ID = '';
    $scope.QuarterTamplateList = [];
    $scope.ALLPlant_ProductList = [];
    $scope.BrandType = [];
    $scope.BrandName = [];
    $scope.headername = '';
    $scope.plants = [];
    $scope.value = [];
    $scope.isAutoPlay = false;

    var marqueeid = 0;
    var lastTab = '';
    var activeTab;
    var counter = 0;
    var count = 0
    var id;
    var length;

    $scope.MarqueeData = function (marqueeid) {
        var promiseSucc = Applicationservice.USP_Get_Packaging_Product_Marquee(marqueeid);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {
                obj = JSON.parse(pl.data)["Table"];
                $scope.ar_marqueeData = obj;
                $scope.SetMarqueeData($scope.ar_marqueeData);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.SetMarqueeData = function (obj) {
        $("#marqid").html('');
        var ul = document.getElementById("marqid");

        var html = '';
        for (var i = 0; i < obj.length; i++) {
            $scope.plants = obj[i]["Plant_Name"];
            $scope.value = obj[i]["value"];
            var li = document.createElement("li");
            li.setAttribute("id", "marq" + i);
            html += '<li id="marq' + i + '" class="non-marquee ' + (i == 0 ? "use-marquee" : "") + '"><div style="width:100%;height: 20px;">'
                + '<div class="HOmarqueemini" style="float:left;background-color:#2ca9ab;height: 20px;color:white;padding-top:3px;text-align:center;min-width:8.5%">'
                + ' <div style="display: inline-block;">' + $scope.plants + '</div>'
                + '<div style="display: inline-block;float: right;padding-right: 5px;background: #e39d45;padding: 3px;margin-top: -3px;"><small>MTD</small></div></div>'
                + '<div class="HOmarqueeValuemini" style="float:left;height: 20px;"><div id="marq11' + i + '" class="' + (i == 0 ? "marquee" : "") + '" style="color:blackheight:20px;padding-top:3px;">'
                + $scope.value + '</div></div></div></li>';
        }

        $("#marqid").html(html);
        length = document.getElementById("marqid").getElementsByTagName("li").length;

        $("#marqid").parent().css('height', '20px');

        $('.marquee').bind('finished', function () {
            $scope.changemarquee();
        }).marquee({
            pauseOnHover: true,
            duration: 20000
        });
    };

    $scope.changemarquee = function () {
        if (length != 0) {
            counter = counter + 1;

            lastTab = document.getElementById("marq11" + (counter - 1));
            $(lastTab).parents("li").removeClass("use-marquee");
            $(lastTab).parents("li").addClass("non-marquee");
            $(lastTab).removeClass("marquee");

            if (counter == length) {
                counter = 0;
                $scope.SetMarqueeData($scope.ar_marqueeData);
                return;
            }
            activeTab = document.getElementById("marq11" + counter);
            $(activeTab).addClass("marquee");
            $(activeTab).parents("li").addClass("use-marquee");
            $(activeTab).bind('finished', function () {
                $scope.changemarquee();
            }).marquee({
                pauseOnHover: true,
                duration: 20000
            });
        }
    };


    var timr = null;
    //$rootScope.OnAutoScrollProductClick = function () {
    //var PlayProduct = localStorage.getItem('PlayProduct');
    //if (PlayProduct == "1") {
    //    localStorage.setItem('PlayProduct', 0);
    //    $('#fa_play').removeClass('fa-pause');
    //    $('#fa_play').addClass('fa-play');
    //    angular.element('#wrapper').scope().mBrcmnProductDisable = false;
    //    angular.element('#wrapper').scope().mBrcmnCycleDisable = false;
    //    clearInterval(chrtPosChangeInterval);
    //}
    //else {
    //    localStorage.setItem('PlayProduct', 1);
    //    $('#fa_play').removeClass('fa-play');
    //    $('#fa_play').addClass('fa-pause');

    //    angular.element('#wrapper').scope().mBrcmnProductDisable = true;
    //    angular.element('#wrapper').scope().mBrcmnCycleDisable = true;
    //    GetProductAutoList();
    //}
    //}
    $scope.AutoPlayBrandList = function (from_date, to_date) {
        $rootScope.AutoPlayBrandList = [];
        var promiseSucc = Applicationservice.USP_Get_Refine_AutoPlayProd(from_date, to_date,"Packing");
        promiseSucc.then(function (pl) {
            if (pl.data != null) {
                $rootScope.AutoPlayBrandList = JSON.parse(pl.data);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    function GetProductAutoList(chngFlg) {
        if ($rootScope.AutoPlayBrandList.length > 0) {
            var PlayProduct = localStorage.getItem('PlayProduct');
            if (PlayProduct == "1") {
                var LastProductStore = localStorage.getItem('lastProductPlay');

                var CurrentProduct = (LastProductStore != undefined && LastProductStore != null && LastProductStore != "" && LastProductStore != "null") ? parseInt(LastProductStore) : 0;

                if (CurrentProduct > 0 && CurrentProduct == $rootScope.AutoPlayBrandList.length) {
                    CurrentProduct = 0;
                }

                if (CurrentProduct > 0 && chngFlg == true) {
                    CurrentProduct--;
                }

                $scope.varBrand_ID = $rootScope.AutoPlayBrandList[CurrentProduct].brand_Name;
                $scope.brand_Name = $rootScope.AutoPlayBrandList[CurrentProduct].Row_Id;

                angular.element('#wrapper').scope().mBrcmnProduct = $scope.varBrand_ID;
                $('.breadcrumbs-menu ul').attr('style', 'opacity: 0;');
                
                if ($scope.varBrand_ID != undefined || $scope.varBrand_ID != '') {
                    $('#brand_' + $scope.brand_Name).prop('checked', true);
                    $('#liBrcmnProduct').text($('#brand_' + $scope.brand_Name).siblings('p').html());
                }

                if ($scope.varBrand_ID != undefined && $scope.varBrand_ID != null && $scope.varBrand_ID != "") {
                    localStorage.setItem("backBrandGlCode", $scope.brand_Name);
                }

                $('.breadcrumbs-menu ul').attr('style', 'opacity: 1; transition: opacity 500ms linear;');
                $scope.USP_Get_Yearly_QuarterNo('load');
                CurrentProduct = parseInt(CurrentProduct) + 1;
                localStorage.setItem('lastProductPlay', CurrentProduct);
            }
        }
    }

    $scope.fileronChange = function (plantID, ProductID) {
        var role_code = localStorage.getItem('var_RoleName');
        if (role_code.toLowerCase() == "HO".toLowerCase() || role_code.toLowerCase() == "AWL Admin".toLowerCase()) {
            plantID = '';
        }

        $window.location.assign(AppURL + '/dashboard/packingholanding?prm=' + $rootScope.EncryptionText("Pnt=" + plantID + "&Prd=" + ProductID));
    };

    $scope.onclickLoad = function (action) {
        $('.cyclePanl').attr('class', 'box mtd highlightpnl');
        $('#' + action).attr("class", "box mtd highlightpnl cyclePanl");
        localStorage.setItem('varCycle', $('.cyclePanl').attr('id'));
        angular.element('#wrapper').scope().mBrcmnCycleName = action.toUpperCase();
        var cycle = $rootScope.GetMonthDetails(action);
        $('#liBrcmnCycle').text(cycle);
        $scope.headername = cycle;
        $scope.USP_Get_Yearly_QuarterNo('click');

    };

    $scope.initLoadData = function () {

        $rootScope.mvisibleBack = false;
        $rootScope.mvisibleDateCycle = true;
        $rootScope.mvisibleHoreport = false;
        $rootScope.topHeading = 'Packing Summary (HO)';
        var FID = localStorage.getItem("FID");
        $rootScope.insertformvisit($rootScope.topHeading, FID);
        var url_main = $window.location.pathname.toLowerCase();
        if (url_main.search('dashboard/packingholanding') != -1) {
            var url = $window.location.search;
            if (url.split('?').length > 1) {
                var Decrp = $rootScope.DecryptionText(url.split('?prm=')[1]);
                if (Decrp != null && Decrp != '') {
                    $scope.varPlant_ID = (Decrp.split('&')[0].split('=')[1]);

                    $('.breadcrumbs-menu ul').attr('style', 'opacity: 0;');
                    setTimeout(function () {
                        if ($scope.varPlant_ID != null && $scope.varPlant_ID != '') {
                            $('#plant_' + $scope.varPlant_ID).prop('checked', true);
                            $('#liBrcmnPlant').text($('#plant_' + $scope.varPlant_ID).siblings('p').html());
                        }
                        else {
                            $('#liBrcmnPlant').text('All Plant');
                        }

                        var brand_id = (Decrp.split('&')[1].split('=')[1]);
                        localStorage.setItem("backBrandGlCode", brand_id);
                        var prod_name = $('#brand_' + brand_id).attr('data-productname');
                        $scope.varBrand_ID = prod_name;

                        $('#brand_' + brand_id).prop('checked', true);
                        $('#liBrcmnProduct').text($('#brand_' + brand_id).siblings('p').html());

                        angular.element('#wrapper').scope().mBrcmnProduct = $scope.varBrand_ID;
                        angular.element('#wrapper').scope().mBrcmnPlant = $scope.varPlant_ID;
                        $('.breadcrumbs-menu ul').attr('style', 'opacity: 1; transition: opacity 500ms linear;');
                        $scope.MarqueeData(0);
                        $scope.USP_Get_Yearly_QuarterNo('load');
                    }, 1500);
                }
            }
            else {
                setTimeout(function () {
                    var brand_id = $('ul#BrandList').find('li label input:checked').parents('label').attr('data-id');
                    localStorage.setItem("backBrandGlCode", brand_id);
                    $scope.varBrand_ID = $('#brand_' + brand_id).attr('data-productname');
                    $scope.MarqueeData(0);
                    $scope.USP_Get_Yearly_QuarterNo('load');
                }, 2000);
            }
            if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
                $rootScope.mvisiblePlay = false;
            }
        }
        // $scope.USP_Get_Yearly_QuarterNo('load');
    };

    $scope.insertformvisit = function (formname) {
        var app = '';
        var flag = 'D';
        var ip = localStorage.getItem('your ip');
        var pglcode = localStorage.getItem('personglcode');
        var version = localStorage.getItem('ApplicationVersion');
        if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
            var app = 'M';
        } else {
            app = 'W';
        }
        var promiseSucc = Applicationservice.Insert_Login_Details('', '', ip, '', '', '', pglcode, app, formname, version, flag);
        promiseSucc.then(function (pl) {
            var data = $.parseJSON(pl.data);
            var id = data["Table"][0]["NID"]
            localStorage.setItem("FID", id);
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.USP_Get_Yearly_QuarterNo = function (action) {
        var highlightCycle = localStorage.getItem('varCycle');
        var cycle = $rootScope.GetMonthDetails(highlightCycle);
        $scope.headername = cycle;
        $('.cyclePanl').attr('class', 'box mtd highlightpnl');
        $('#' + highlightCycle).attr("class", "box mtd highlightpnl cyclePanl");

        var promiseSucc = Applicationservice.Get_Date_Range(highlightCycle);
        promiseSucc.then(function (pl) {
            if (pl.data != null) {
                
                $scope.QuarterTamplateList = pl.data;
                if (pl.data != null && pl.data.length > 4) {
                    var from_date = $scope.QuarterTamplateList[0]['dtFromDate'];
                    var to_date = $scope.QuarterTamplateList[0]['dtToDate'];

                    if (action == 'load') {

                        $('#yesterday').html('');
                        $('#mtd').html('');
                        $('#qtd').html('');
                        $('#ytd').html('');
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'Yesterday');

                        from_date = $scope.QuarterTamplateList[1]['dtFromDate'];
                        to_date = $scope.QuarterTamplateList[1]['dtToDate'];
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'MTD');

                        from_date = $scope.QuarterTamplateList[2]['dtFromDate'];
                        to_date = $scope.QuarterTamplateList[2]['dtToDate'];
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'QTD');

                        from_date = $scope.QuarterTamplateList[3]['dtFromDate'];
                        to_date = $scope.QuarterTamplateList[3]['dtToDate'];
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'YTD');
                        $scope.AutoPlayBrandList(from_date, to_date);
                    }

                    var from_date = $scope.QuarterTamplateList[0]['dtFromDate'];
                    var to_date = $scope.QuarterTamplateList[0]['dtToDate'];
                    $scope.GetSubjectListBAryesterday($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'ActualVSIntend');
                    $scope.GetSubjectListBAryesterday($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'PackType');

                    from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                    to_date = $scope.QuarterTamplateList[4]['dtToDate'];
                    $scope.GetSubjectListBAr($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'ActualVSIntend');
                    $scope.GetSubjectListBAr($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'PackType');

                    var PlayProduct = localStorage.getItem('PlayProduct');
                    if (PlayProduct == "1") {
                        $('.overlaydisplyProductName').fadeTo(100, 0.9);
                        $('.displyProductName').fadeIn(100);
                        $('.displyProductName h1').html($('#liBrcmnProduct').html());
                        $('.displyProductName').fadeOut(3000);
                        setTimeout(function () {
                            chrtPosChangeInterval = setInterval($scope.rotateCycle, 5000);
                        }, 500);
                    }
                }

            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.GetALLPlant_Product_Refind_Dashboard = function (varBrand_ID, varPlant_ID, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.USP_ALLPlant_Product_Packaging_Dashboard(varBrand_ID, varPlant_ID, from_date, to_date, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {
                $scope.ALLPlant_ProductList = JSON.parse(pl.data)['Table'];
                if ($scope.ALLPlant_ProductList != null) {
                    var d = new Date();
                    var last_year = parseInt(d.getFullYear()) - 1;

                    var html = '';
                    var ChrColor = $scope.ALLPlant_ProductList[0]['ChrColor'];
                    html += '<div class="box-left">';
                    html += '<h5>' + varAction + '</h5>';
                    html += '<h4></h4>';
                    html += '<h1>' + addCommas($scope.ALLPlant_ProductList[0]['Current_TotalQty']) + '<small style="font-size: 40%;">MT</small></h1>';
                    html += '</div>';
                    html += '<div class="box-right">';
                    html += '<div class="box-lastyrTag">vs ' + last_year + '</div>';
                    html += '<div class="box-right-arrow">';
                    html += '<i class="fa fa-arrow-down darrow" style="color:' + (ChrColor == 'Red' ? '#fff' : '#fff') + ';"></i>';
                    html += '</div>';
                    html += '<h3 style="color:' + (ChrColor == 'Red' ? '#fff' : '#fff') + ';">' + $scope.ALLPlant_ProductList[0]['YOYPer'] + '%</h3>';
                    html += '</div>';
                    if (varAction == 'Yesterday') {
                        $('#yesterday').html(html);
                    }
                    else if (varAction == 'MTD') {
                        $('#mtd').html(html);
                    }
                    else if (varAction == 'QTD') {
                        $('#qtd').html(html);
                    }
                    else if (varAction == 'YTD') {
                        $('#ytd').html(html);
                    }
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetSubjectListBAr = function (varPlant_ID, varBrand_ID, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.USP_ALLPlant_Product_Packaging_Dashboard(varPlant_ID, varBrand_ID, from_date, to_date, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null || pl.data != '') {
                dataSource1 = $.parseJSON(pl.data)['Table'];
                if (dataSource1 != null) {
                    var scrnHeight1 = ($('.header-top').hasClass('header-top-hide') ? 15 : $('.header-top').height()) + 120 + $('#toppanel').height();
                    var scrnHeight = $(window).height();
                    var arr = [];
                    $scope.varPackType = [];
                    if (varAction == 'PackType') {
                        $scope.varPackType = $.parseJSON(pl.data)['Table1'];
                        if ($scope.varPackType != null && $scope.varPackType != '' && $scope.varPackType != undefined) {
                            for (var k = 0; k < $scope.varPackType.length; k++) {
                                arr.push({ 'valueField': $scope.varPackType[k]["varPackType"], 'name': $scope.varPackType[k]["varPackType"], "visible": true });
                            }
                        }
                    }
                    if ($scope.isAutoPlay == true) {
                        if (varAction == 'ActualVSIntend') {
                            B1chart.bindDchart("chartid1", dataSource1, varAction, ($('#dvMain').find('div#chartid1').html() != undefined ? (scrnHeight - scrnHeight1) : ((scrnHeight - scrnHeight1 - 70) / 3)));
                        } else if (varAction == 'PackType') {
                            Stck1chart.bindDchart("chartid3", dataSource1, arr, ($('#dvMain').find('div#chartid3').html() != undefined ? (scrnHeight - scrnHeight1) : ((scrnHeight - scrnHeight1 - 70) / 3)));
                        }
                    } else {
                        if (varAction == 'ActualVSIntend') {
                            B1chart.bindDchart("chartid11", dataSource1, varAction, 300);
                        } else if (varAction == 'PackType') {
                            Stck1chart.bindDchart("chartid33", dataSource1, arr, 350);
                        }
                    }
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.GetSubjectListBAryesterday = function (varPlant_ID, varBrand_ID, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.USP_ALLPlant_Product_Packaging_Dashboard(varPlant_ID, varBrand_ID, from_date, to_date, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null || pl.data != '') {
                dataSource1 = $.parseJSON(pl.data)['Table'];
                if (dataSource1 != null) {
                    var scrnHeight1 = ($('.header-top').hasClass('header-top-hide') ? 15 : $('.header-top').height()) + 120 + $('#toppanel').height();
                    var scrnHeight = $(window).height();
                    var arr = [];
                    $scope.varPackType = [];
                    if (varAction == 'PackType') {
                        $scope.varPackType = $.parseJSON(pl.data)['Table1'];
                        if ($scope.varPackType != null && $scope.varPackType != '' && $scope.varPackType != undefined) {
                            for (var k = 0; k < $scope.varPackType.length; k++) {
                                arr.push({ 'valueField': $scope.varPackType[k]["varPackType"], 'name': $scope.varPackType[k]["varPackType"], "visible": true });
                            }
                        }
                    }
                    if ($scope.isAutoPlay == true) {
                        if (varAction == 'ActualVSIntend') {
                            B1chart.bindDchart("chartid2", dataSource1, varAction, ($('#dvMain').find('div#chartid2').html() != undefined ? (scrnHeight - scrnHeight1) : ((scrnHeight - scrnHeight1 - 70) / 3)));
                            if (dataSource1.length > 0) {
                                $('#zoom2').attr("data-hasData", "1");
                            }
                            else {
                                $('#zoom2').attr("data-hasData", "0");
                            }
                        } else if (varAction == 'PackType') {
                            Stck1chart.bindDchart("chartid4", dataSource1, arr, ($('#dvMain').find('div#chartid4').html() != undefined ? (scrnHeight - scrnHeight1) : ((scrnHeight - scrnHeight1 - 70) / 3)));
                            if (dataSource1.length > 0) {
                                $('#zoom1').attr("data-hasData", "1");
                            }
                            else {
                                $('#zoom1').attr("data-hasData", "0");
                            }
                        }
                    } else {
                        if (varAction == 'ActualVSIntend') {
                            if (dataSource1.length > 0) {
                                $('#zoom2').css("display", "block");
                                B1chart.bindDchart("chartid22", dataSource1, varAction, 300);
                            }
                            else {
                                $('#dvMain').find('div#chartid22').html('');
                                $('#zoom2').css("display", "none");
                            }

                        } else if (varAction == 'PackType') {
                            if (dataSource1.length > 0) {
                                $('#zoom1').css("display", "block");
                                Stck1chart.bindDchart("chartid44", dataSource1, arr, 350);
                            }
                            else {
                                $('#dvMain').find('div#chartid44').html('');
                                $('#zoom1').css("display", "none");
                            }
                        }
                    }
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    var B1chart = {
        bindDchart: function (chartid, dataSource, varAction, height) {
            $("#" + chartid).dxChart({
                dataSource: dataSource,
                barWidth: 0.5,
                palette: ['#4ebfe0', '#feb21b'],
                onDrawn: function (e) {
                    if (chartid == 'chartid11') {
                        e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'auto'); });
                    }
                    else {
                        e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'auto'); });
                    }

                },
                commonSeriesSettings: {
                    type: "bar",
                    argumentField: 'VarPlant',
                    label: {
                        rotationAngle: 270,
                        position: 'outside',
                        backgroundColor: 'transparent',
                        alignment: "center",
                        font: {
                            color: "black",
                            size: "11px"
                        },
                        visible: (($scope.isAutoPlay == true && chartid != 'chartid1') ? false : true),
                    }
                },
                series: [
                     { valueField: "decIntend", name: "Indent", color: "#4ebfe0" },
                     { valueField: "decActual", name: "Actual", color: "#feb21b" }
                ],
                onPointClick: function (info, varBrand_ID) {
                    if (chartid == 'chartid11') {
                        var SelectedSlab = dataSource.filter(function (entry) {
                            return entry.VarPlant === info.target.argument
                        })[0];
                       
                        localStorage.setItem("backPlantGlCode", SelectedSlab.intPlantID);

                        if (!$scope.isExt) {
                            $window.location.assign(AppURL + '/dashboard/PackingPlantLanding?prm=' + $rootScope.EncryptionText("Pnt=" + SelectedSlab.intPlantID + "&Prd="));
                        }
                    }
                },

                equalBarWidth: false,
                size: {
                    height: height
                },
                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center",
                    itemTextPosition: "right",
                    visible: true
                },
                argumentAxis: {
                    label: {
                        overlappingBehavior: {
                            mode: "rotate",
                            rotationAngle: 270,
                            //displayMode: "rotate",
                            //rotationAngle: 45,
                        }
                    },
                },
                tooltip: {
                    enabled: false
                }
            }).dxChart("instance");
        }
    };
    var Stck1chart = {
        bindDchart: function (chartid, dataSource, arr, height) {

            $("#" + chartid).dxChart({
                dataSource: dataSource,
                palette: "Harmony Light",
                rotated: true,
                barWidth: (dataSource.length < 3 ? 0.2 : ''),
                redrawOnResize: true,
                commonSeriesSettings: {
                    argumentField: 'VarPlant',
                    type: "fullStackedBar",
                    label: {
                        visible: ($scope.isAutoPlay == true ? false : true),
                        font: {
                            color: "white",
                            size: "11px"
                        },
                        backgroundColor: "transparent",
                    }
                },
                size: {
                    height: height,
                },
                margin: {
                    top: 10
                },
                series: arr,
                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center",
                    itemTextPosition: "right"
                },

            });
        }
    };

    var chrtCounter = 1;
    var chrtPosChangeInterval;
    var load = document.getElementById("loadspinner");
    var spin = document.getElementById("loadspin");
    showload = function () {
        load.style.display = "block";
        spin.style.display = "block";
    },

     hideload = function () {
         load.style.display = "none";
         spin.style.display = "none";
     };

    $scope.rotateCycle = function () {
        showload();
        var dvMainHtml = '';
        var dvDetailHtml1 = '', dvDetailHtml2 = '', dvDetailHtml3 = '';
        var chart1, chart2, series1, series2, series3, series4, dtlchrtID, dtlchrtID3, dtlchrtID4;

        var mainchrtID = $('#dvMain').find('div.chart-img div').attr('id');
        chart1 = $('#' + mainchrtID).dxChart('instance');
        series1 = chart1.option();

        dvMainHtml = $('#dvMain').html();
        dvDetailHtml1 = $('#dvdetail1').html();
        dvDetailHtml2 = $('#dvdetail2').html();
        dvDetailHtml3 = $('#dvdetail3').html();

        //   if (chrtCounter == 1) {
        dtlchrtID = $('#dvdetail1').find('div.chart-img div').attr('id');
        chart2 = $('#' + dtlchrtID).dxChart('instance');
        series2 = chart2.option();

        dtlchrtID3 = $('#dvdetail2').find('div.chart-img div').attr('id');
        series3 = $('#' + dtlchrtID3).dxChart('instance').option();

        dtlchrtID4 = $('#dvdetail3').find('div.chart-img div').attr('id');
        series4 = $('#' + dtlchrtID4).dxChart('instance').option();

        $('#dvdetail1').html(dvDetailHtml2);
        $('#dvdetail2').html(dvDetailHtml3);
        $('#dvdetail3').html(dvMainHtml);
        $('#dvMain').html(dvDetailHtml1);

        $("#" + dtlchrtID3).html('');
        $("#" + dtlchrtID4).html('');

        var scrnHeight1 = ($('.header-top').hasClass('header-top-hide') ? 15 : $('.header-top').height()) + 120 + $('#toppanel').height();
        var scrnHeight = $(window).height();

        series3.size.height = (scrnHeight - scrnHeight1 - 70) / 3;
        $("#" + dtlchrtID3).dxChart(series3).dxChart("instance");
        series4.size.height = (scrnHeight - scrnHeight1 - 70) / 3;
        $("#" + dtlchrtID4).dxChart(series4).dxChart("instance");


        $("#" + mainchrtID).html('');
        $("#" + dtlchrtID).html('');
        series1.commonSeriesSettings.label.visible = false
        series1.size.height = (scrnHeight - scrnHeight1 - 70) / 3;
        $("#" + mainchrtID).dxChart(series1).dxChart("instance");

        series2.size.height = (scrnHeight - scrnHeight1);
        series2.commonSeriesSettings.label.visible = true
        $("#" + dtlchrtID).dxChart(series2).dxChart("instance");

        chrtCounter++;
        if ($('#dvMain').find('div.chart-box').attr('data-hasData') != undefined) {
            if ($('#dvMain').find('div.chart-box').attr('data-hasData') == 0) {
                $scope.rotateCycle();
            }
        }

        if (chrtCounter == 5) {
            chrtCounter = 1;
            clearInterval(chrtPosChangeInterval);
            GetProductAutoList(false);
        }
        hideload();
    };

    $scope.autoRorate = function () {
        clearInterval(chrtPosChangeInterval);
    };
    $rootScope.OnAutoScrollProductClick = function () { };

    $(document).delegate('.fa-play', 'click', function () {
        $scope.isAutoPlay = true;
        $('#toppanel').css('pointer-events', 'none');
        $('.header-top').css('pointer-events', 'none');
        $('.show-menu').addClass("displ");
        $(this).css('pointer-events', 'auto');
        element = document.getElementById('dvMainOuter');

        if (element.requestFullScreen) {
            element.requestFullScreen();
        } else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        } else if (element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if (element.webkitRequestFullScreen) {
            element.webkitRequestFullScreen();
        }

        setTimeout(function () {
            localStorage.setItem('PlayProduct', 1);
            $('#fa_play').removeClass('fa-play');
            $('#fa_play').addClass('fa-pause');
            angular.element('#wrapper').scope().mBrcmnProductDisable = true;
            angular.element('#wrapper').scope().mBrcmnCycleDisable = true;
            $('.show-menu').hide();
            GetProductAutoList(true);

        }, 100);
    });

    $(document).delegate('.fa-pause', 'click', function () {
        $('#toppanel').css('pointer-events', 'auto');
        $('.header-top').css('pointer-events', 'auto');
        $('.show-menu').removeClass("displ");
        $('.show-menu').show();
        $scope.isAutoPlay = false;
        localStorage.setItem('PlayProduct', 0);
        elem = document.getElementById('dvMainOuter');
        if (document.cancelFullScreen) {
            document.cancelFullScreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }

        $('#fa_play').removeClass('fa-pause');
        $('#fa_play').addClass('fa-play');
        angular.element('#wrapper').scope().mBrcmnProductDisable = false;
        angular.element('#wrapper').scope().mBrcmnCycleDisable = false;
        clearInterval(chrtPosChangeInterval);
        $scope.initLoadData();
    });

    $scope.GenerateScrollableGrid = function (intheight, id) {
        var ar_width = [], obj = 0;
        ar_width.push({ width: 125, align: 'center' });
        ar_width.push({ width: 50, align: 'center' });
        if (id == 'utchart') {
            obj = $scope.utype.length;
        } else {
            obj = $scope.ctype.length
        }
        for (var col = 0; col < obj; col++) {
            ar_width.push({ width: 120, align: 'center' })
        }

        $("#fullChrt").find('#' + id).fxdHdrCol({
            fixedCols: 2,
            width: ($("#fullChrt").find('#' + id).parents('div.chart-box').parent('div').width() - 15),
            height: intheight - 10,
            colModal: ar_width,
            sort: false
        });
    };

}]);
﻿app.controller('Plant_Wise_Line_WiseController', ['$scope', 'Applicationservice', '$rootScope', '$window', '$filter', '$timeout', '$location', 'AppURL', function ($scope, Applicationservice, $rootScope, $window, $filter, $timeout, $location, AppURL) {

    $rootScope.OnBackClick = function () {
        var BrandGlcode = localStorage.getItem("backBrandGlCode");
        $window.location.assign(AppURL + '/dashboard/PackingPlantLanding?prm=' + $rootScope.EncryptionText("Pnt=" + $scope.varPlant_ID + "&Prd=" + $scope.varBrand_ID));
    }

    $scope.varBrand_ID = '';
    $scope.varPlant_ID = '';
    $scope.PackType = '';
    $scope.dtFromDate = new Date();
    $scope.dtToDate = new Date();
    passive: false;
    $scope.fileronChange = function (plantID, ProductID) {
        var role_code = localStorage.getItem('var_RoleName');
        $window.location.assign(AppURL + '/dashboard/Plant_Wise_Line_Wise?prm=' + $rootScope.EncryptionText("Pnt=" + plantID + "&Prd=" + ProductID));
    };

    $scope.initLoadData = function () {
        $rootScope.mvisibleBack = true;
        $rootScope.mvisibleDateCycle = true;
        $rootScope.mvisibleHoreport = false;
        $rootScope.topHeading = 'Packing: Plant wise Line wise';
        var FID = localStorage.getItem("FID");
        $rootScope.insertformvisit($rootScope.topHeading, FID);
        var url_main = $window.location.pathname.toLowerCase();
        if (url_main.search('dashboard/plant_wise_line_wise') != -1) {
            var url = $window.location.search;
            if (url.split('?').length > 1) {
                var Decrp = $rootScope.DecryptionText(url.split('?prm=')[1]);
                if (Decrp != null && Decrp != '') {
                    $scope.varPlant_ID = (Decrp.split('&')[0].split('=')[1]);
                    $scope.varBrand_ID = (Decrp.split('&')[1].split('=')[1]);
                    $('.breadcrumbs-menu ul').attr('style', 'opacity: 0;');
                    setTimeout(function () {
                        if ($scope.varPlant_ID != null && $scope.varPlant_ID != '') {
                            $('#plant_' + $scope.varPlant_ID).prop('checked', true);
                            $('#liBrcmnPlant').text($('#plant_' + $scope.varPlant_ID).siblings('p').html());
                        }
                        else {
                            $('#liBrcmnPlant').text('All Plant');
                        }

                        localStorage.setItem("backBrandGlCode", $scope.varBrand_ID);

                        $('label[data-productname="' + $scope.varBrand_ID + '"]').find('input').prop('checked', true);

                        if ($scope.varBrand_ID != "") {
                            $('#liBrcmnProduct').text($scope.varBrand_ID);
                        } else {
                            $scope.varBrand_ID = $('#liBrcmnProduct').text();
                        }
                        angular.element('#wrapper').scope().mBrcmnProduct = $scope.varBrand_ID;
                        angular.element('#wrapper').scope().mBrcmnPlant = $scope.varPlant_ID;
                        $('.breadcrumbs-menu ul').attr('style', 'opacity: 1; transition: opacity 500ms linear;');
                        $scope.USP_Get_Yearly_QuarterNo('');
                    }, 1500);

                }
            }
            else {
                setTimeout(function () {
                    $scope.varPlant_ID = $('ul#plantList').find('li input:checked').parents('li').attr('data-id');
                    $scope.varBrand_ID = $('ul#BrandList').find('li label input:checked').parents('label').attr('data-productname');
                    $scope.USP_Get_Yearly_QuarterNo('');
                }, 1500);
            }
        }
    };

    $scope.USP_Get_Yearly_QuarterNo = function (action) {

        var highlightCycle = localStorage.getItem('varCycle');
        var cycle = $rootScope.GetMonthDetails(highlightCycle);
        $scope.headername = cycle;

        var promiseSucc = Applicationservice.Get_Date_Range(highlightCycle);
        promiseSucc.then(function (pl) {

            if (pl.data != null) {
                $scope.QuarterTamplateList = pl.data;
                if (pl.data != null && pl.data.length > 4) {
                    var from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                    var to_date = $scope.QuarterTamplateList[4]['dtToDate'];

                    $scope.dtFromDate = from_date;
                    $scope.dtToDate = to_date;
                    $scope.varCycle = localStorage.getItem('varCycle');

                    $scope.QtyType = 'M';
                    if ($scope.varCycle != '' && $scope.varCycle != "" && $scope.varCycle != 'mtd') {
                        $scope.QtyType = ($scope.varCycle == 'qtd' ? 'Q' : 'Y');
                    }
                    $scope.GetData_Production($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'PackTypeWise');
                    $scope.GetData_Line_Utilization($scope.varPlant_ID, $scope.varBrand_ID, from_date, to_date, 'LineUtilization');
                    $scope.GetData_UtilityWise($scope.varPlant_ID, $scope.varBrand_ID, '', '', '', from_date, to_date, $scope.QtyType, 'UtilityWise');
                    $scope.Get_PackTypeWise_Indent_VS_Actual($scope.varPlant_ID, $scope.varBrand_ID, '', from_date, to_date, 'PackTypeIndentVsAct');
                    $scope.GetData_Line_Utilization_Grid($scope.varPlant_ID, $scope.varBrand_ID, '', from_date, to_date, 'LineUtilizationGrid');
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.GetData_Production = function (varPlant_ID, varPackType, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.USP_PackType_Wise_Packaging_Dashboard(varPlant_ID, varPackType, '', '', '', from_date, to_date, $scope.QtyType, varAction);
        promiseSucc.then(function (pl) {

            if (pl.data != null && pl.data != '' && pl.data.length > 0) {
                dataSource1 = $.parseJSON(pl.data)['Table'];

                if (dataSource1 != null) {

                    var arr = [];

                    $scope.varPackType = $.parseJSON(pl.data)['Table1'];
                    if ($scope.varPackType != null && $scope.varPackType != '' && $scope.varPackType != undefined) {
                        for (var k = 0; k < $scope.varPackType.length; k++) {
                            arr.push({ 'valueField': $scope.varPackType[k]["ph3"], 'name': $scope.varPackType[k]["ph3"], "visible": true });
                        }
                    }
                    Stck1chart.bindDchart("chartid1", dataSource1, arr);
                }
                //else {
                //   
                //    //$('#demoChemical').css("display", "none");
                //    // $('.quality-parameters-section').css("margin-bottom", "10px");
                //}
            }

        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };
    $scope.GetData_Line_Utilization = function (varPlant_ID, varPackType, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.USP_PackType_Wise_Packaging_Dashboard(varPlant_ID, varPackType, '', '', '', from_date, to_date, $scope.QtyType, varAction);
        promiseSucc.then(function (pl) {

            if (pl.data != null && pl.data != '') {
                dataSource1 = $.parseJSON(pl.data)['Table'];
                if (dataSource1 != null) {

                    var arr = [];

                    //$scope.varPackType = $.parseJSON(pl.data)['Table1'];
                    //if ($scope.varPackType != null && $scope.varPackType != '' && $scope.varPackType != undefined) {
                    //    for (var k = 0; k < $scope.varPackType.length; k++) {
                    //        arr.push({ 'valueField': $scope.varPackType[k]["ph3"], 'name': $scope.varPackType[k]["ph3"], "visible": true });
                    //    }
                    //}
                    Stck2chart.bindDchart("chartid2", dataSource1);
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };
    $scope.GetData_UtilityWise = function (varPlant_ID, varPackType, strRefinaryCode, ComponentName, ComponentUOM, from_date, to_date, chrMonthType, varAction) {
        //if (strRefinaryCode != '') {
        //    $('#hdrPackTypeWise').html('Utility Consumption (MT) - ' + strRefinaryCode);
        //} else {
        //    $('#hdrPackTypeWise').html('Utility Consumption (MT)');
        //}
        $("#hdnRefinaryCode").val(strRefinaryCode);

        var promiseSucc = Applicationservice.USP_PackType_Wise_Packaging_Dashboard(varPlant_ID, varPackType, strRefinaryCode, ComponentName, ComponentUOM, from_date, to_date, chrMonthType, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {
                var dataSource = $.parseJSON(pl.data)['Table'];
                $scope.GetSubjectListgauge(dataSource);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetSubjectListgauge = function (dataSource) {

        if (dataSource != '' && dataSource != null && dataSource.length > 0) {
            var divId = '';
            var uldiv = document.getElementById("ulutchart");
            uldiv.innerHTML = '';
            for (var i = 0; i < dataSource.length; i++) {

                var dynDiv1 = document.createElement("li");
                dynDiv1.setAttribute("id", "liutchart" + i);
                dynDiv1.setAttribute("style", "display:inline;cursor: pointer;");
                var dynDiv = document.createElement("div");
                dynDiv.setAttribute("id", "chartutlty" + i);
                dynDiv.setAttribute("class", "utility_chart");
                dynDiv.setAttribute("data-charttype", "gauge");
                dynDiv.setAttribute("data-chrtheight", "200");
                dynDiv.setAttribute("onclick", "angular.element(this).scope().RedirectToRefinary('chartutlty" + i + "')");
                if (i == 2) {
                    uldiv.setAttribute("class", "bxslider");
                }
                document.getElementById('ulutchart').appendChild(dynDiv1);
                document.getElementById("liutchart" + i).appendChild(dynDiv);

                options.bindguage("chartutlty" + i, '#4d4d4d',
                    dataSource[i]["Actual_Qty"], dataSource[i]["Max_Qty"],
                    (dataSource[i]["Brand_Name"] + " [" + dataSource[i]["UOM"] + "]"), dataSource[i]["Brand_Name"], dataSource[i]["UOM"]);
            }
            $('.bxslider').bxSlider({
                mode: 'horizontal',
                moveSlides: 1,
                slideMargin: 90,
                infiniteLoop: false,
                slideWidth: 250,
                minSlides: ($(window).width() < 1024 && $(window).width() > 576 ? 2 : ($(window).width() < 576 ? 1 : 2)),
                maxSlides: ($(window).width() < 1024 && $(window).width() > 576 ? 2 : ($(window).width() < 576 ? 1 : 2)),
                speed: 500,
            });
            //$('.bxslider').bxSlider({
            //    mode: 'horizontal',
            //    moveSlides: 1,
            //    slideMargin: 100,
            //    infiniteLoop: false,
            //    minSlides:4,
            //    maxSlides: 4,
            //    speed: 500,
            //    slideWidth: 200,
            //});

        } else {
            var uldiv = document.getElementById("ulutchart");
            uldiv.innerHTML = '';
        }


    };
    //var B1chart = {
    //    bindDchart: function (chartid, dataSource) {
    //       //debugger
    //        $("#" + chartid).dxChart({
    //            dataSource: dataSource,
    //            barWidth: 0.5,
    //            palette: ['#007bff;'],
    //            commonSeriesSettings: {
    //                type: "bar",
    //                argumentField: "country",
    //                label: {
    //                    font: {
    //                        color: "black",
    //                        size: "12px",
    //                    },
    //                    backgroundColor: "transparent",
    //                    visible: true,

    //                },

    //            }, size:
    //                 {
    //                     height: 250
    //                 },
    //            series: [
    //                 {
    //                     valueField: "hydro", color: "#007bff"
    //                 }],
    //            equalBarWidth: false,
    //            legend: {
    //                verticalAlignment: "bottom",
    //                horizontalAlignment: "center",
    //                itemTextPosition: "center",
    //                visible: false
    //            },
    //            tooltip: {
    //                enabled: false
    //            }
    //        }).dxChart("instance");
    //    }
    //};
    var Stck1chart = {
        bindDchart: function (chartid, dataSource, arr) {
            $("#" + chartid).dxChart({
                dataSource: dataSource,
                resolveLabelOverlapping: 'Stack',
                palette: "Harmony Light",
                rotated: true,
                onDrawn: function (e) {
                    e.element.find(".dxc-series, .dxc-labels").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'pointer'); });
                },
                commonSeriesSettings: {
                    argumentField: 'varLine',
                    type: "fullStackedBar",
                    label: {
                        font: {
                            color: "white",
                            size: "11px",
                        },
                        backgroundColor: "transparent",
                        visible: true,

                    },
                    selectionMode: 'allArgumentPoints'
                },
                tooltip: {
                    enabled: (chartid == "chartid2" ? true : false),
                    shared: true,
                    customizeTooltip: function (info) {
                        //debugger

                        var chart = $('#' + chartid + '').dxChart('instance');
                        var argument = info.argument;
                        item = chart._dataSource._items;
                        var SelectedSlab = item.filter(function (entry) {
                            return entry.varLine === argument
                        })[0];

                        var perc = SelectedSlab[info.seriesName + '_Percent'];

                        return {
                            html: "<div>" +
                            //  info.argumentText + " " +
                            info.seriesName +
                            ":<b> " +
                            perc +
                            "%</b> </div>"
                        };
                    }
                },
                margin: {
                    top: 10
                },
                onPointClick: function (info) {
                    //info.target.isSelected() ? info.target.clearSelection() : info.target.select();
                    //var pointVal = '';
                    //pointVal = info.target.argument;
                    //if (chartid == 'chartid1') {
                    //    $scope.GetData_UtilityWise($scope.varPlant_ID, $scope.varBrand_ID, pointVal, '', '', $scope.dtFromDate, $scope.dtToDate, '', 'UtilityWise');
                    //    $scope.Get_PackTypeWise_Indent_VS_Actual($scope.varPlant_ID, $scope.varBrand_ID, pointVal, $scope.dtFromDate, $scope.dtToDate, 'PackTypeIndentVsAct');
                    //}
                },
                size: {
                    height: 250
                },
                customizePoint: function (arg) {
                    //return {
                    //    selectionStyle: {  
                    //        border: {
                    //            visible: true,
                    //            color: '#25a0a2',
                    //            width: 3
                    //        }
                    //    }
                    //}
                },
                series: arr,
                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center",
                    itemTextPosition: "right"
                },

            });
        }
    };

    var OnChartSeriesClick = function (e) {
        var series = e.target;
    };

    var selectedsrs = null;
    var Stck2chart = {
        bindDchart: function (chartid, dataSource) {
 
            $("#" + chartid).dxChart({
                dataSource: dataSource,
                commonSeriesSettings: {
                    argumentField: "Refinary_Code",
                    valueField: "Percentage",
                    type: "stackedBar",
                    label: {
                        font: {
                            color: "white",
                            size: "11px",
                        },
                        visible: true,
                        position: 'outside'
                    }
                },
                onDrawn: function (e) {
                    e.element.find(".dxc-series, .dxc-labels").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'pointer'); });
                },
                onPointClick: function (info) {
                    info.target.isSelected() ? info.target.clearSelection() : info.target.select();
                    var pointVal = '';
                    pointVal = info.target.argument;     
                    if (chartid == 'chartid2') {     
                        if (!info.target.isSelected()) {
                            pointVal = "";
                            $scope.GetData_Line_Utilization_Grid($scope.varPlant_ID, $scope.varBrand_ID, pointVal, $scope.dtFromDate, $scope.dtToDate, 'LineUtilizationGrid');
                            $scope.GetData_UtilityWise($scope.varPlant_ID, $scope.varBrand_ID, pointVal, '', '', $scope.dtFromDate, $scope.dtToDate, '', 'UtilityWise');
                            $scope.Get_PackTypeWise_Indent_VS_Actual($scope.varPlant_ID, $scope.varBrand_ID, pointVal, $scope.dtFromDate, $scope.dtToDate, 'PackTypeIndentVsAct');
                            selectedsrs.clearSelection();
                        } else {
                            //$scope.GetData_UtilityWise($scope.varPlant_ID, $scope.varBrand_ID, pointVal, '', '', $scope.dtFromDate, $scope.dtToDate, '', 'UtilityWise');
                            //$scope.Get_PackTypeWise_Indent_VS_Actual($scope.varPlant_ID, $scope.varBrand_ID, pointVal, $scope.dtFromDate, $scope.dtToDate, 'PackTypeIndentVsAct');
                            $scope.GetData_Line_Utilization_Grid($scope.varPlant_ID, $scope.varBrand_ID, pointVal, $scope.dtFromDate, $scope.dtToDate, 'LineUtilizationGrid');
                            $scope.GetData_UtilityWise($scope.varPlant_ID, $scope.varBrand_ID, pointVal, '', '', $scope.dtFromDate, $scope.dtToDate, '', 'UtilityWise');
                            $scope.Get_PackTypeWise_Indent_VS_Actual($scope.varPlant_ID, $scope.varBrand_ID, pointVal, $scope.dtFromDate, $scope.dtToDate, 'PackTypeIndentVsAct');

                            var tmpchart1 = $("#chartid1").dxChart("getAllSeries");
                            for (var i = 0; i < tmpchart1.length; i++) {
                                for (var j = 0; j < tmpchart1[i].getAllPoints().length; j++) {
                                    if (pointVal == tmpchart1[i].getAllPoints()[j].argument) {
                                        tmpchart1[i].getAllPoints()[j].select();
                                        selectedsrs = tmpchart1[i].getAllPoints()[j]
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                    }
                }, customizePoint: function (arg) {
                    //return { selectionStyle: { color: "#ffffff" } }
                },
                seriesTemplate: {

                    nameField: "varPackType",
                    customizeSeries: function (valueFromNameField) {
                        return {
                            label: {

                                visible: true,
                                customizeText: function (pointInfo) {

                                    var series = $("#" + chartid).dxChart('instance').getAllSeries();
                                    var lastSeries = series[series.length - 1];
                                    if (pointInfo.seriesName !== lastSeries.name) {
                                        return "";
                                    }
                                    return Math.round(pointInfo.total * 100) / 100;
                                }
                            }
                        };
                    }
                },

                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center"
                }, margin: {
                    top: 10
                },
                size: {
                    height: 250
                },
                argumentAxis: {
                    label: {
                        overlappingBehavior: {
                            mode: "rotate",
                            rotationAngle: 270,
                            //displayMode: "rotate",
                            //rotationAngle: 45,
                        }
                    },
                },
                tooltip: {
                    enabled: true,
                    shared: true,
                    customizeTooltip: function (info) {

                        var chart = $("#" + chartid).dxChart('instance');
                        var argument = info.argument;
                        item = chart._dataSource._items;
                        var SelectedSlab = item.filter(function (entry) {

                            return entry.varLine === argument
                        })[0];

                        //var perc = SelectedSlab[info.seriesName + '_Percent'];

                        var perc = info.value;

                        return {
                            html: "<div>" +
                            //  info.argumentText + " " +
                            info.seriesName +
                            ":<b> " +
                            perc +
                            "</b> </div>"
                        };
                    }
                }
            });

            //$("#" + chartid).dxChart({
            //    dataSource: dataSource,
            //    //resolveLabelOverlapping: 'Stack',
            //    palette: "Harmony Light",
            //    rotated: false,
            //    onDrawn: function (e) {
            //        e.element.find(".dxc-series, .dxc-labels").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'pointer'); });
            //    },
            //    commonSeriesSettings: {
            //        argumentField: "Refinary_Code",
            //        valueField: "Percentage",
            //        type: "stackedBar",
            //        label: {
            //            font: {
            //                color: "white",
            //                size: "11px",
            //            },
            //            backgroundColor: "transparent",
            //            visible: false,

            //        },
            //        selectionMode: 'allArgumentPoints'
            //    },               
            //    tooltip: {
            //        enabled: (chartid == "chartid2" ? true : false),
            //        shared: true,
            //        customizeTooltip: function (info) {

            //            var chart = $('#' + chartid + '').dxChart('instance');
            //            var argument = info.argument;
            //            item = chart._dataSource._items;
            //            var SelectedSlab = item.filter(function (entry) {
            //                return entry.varLine === argument
            //            })[0];

            //            //var perc = SelectedSlab[info.seriesName + '_Percent'];
            //            var perc = info.Percentage;
            //            return {
            //                html: "<div>" +
            //                //  info.argumentText + " " +
            //                info.seriesName +
            //                ":<b> " +
            //                perc +
            //                "%</b> </div>"
            //            };
            //        }
            //    },
            //    margin: {
            //        top: 10
            //    },
            //    onPointClick: function (info) {
            //        info.target.isSelected() ? info.target.clearSelection() : info.target.select();
            //        var pointVal = '';
            //        if (info.target.isSelected()) {
            //            pointVal = info.target.argument;
            //        } else {
            //            pointVal = '';
            //        }

            //        if (chartid == 'chartid1') {
            //            $scope.GetData_UtilityWise($scope.varPlant_ID, $scope.varBrand_ID, pointVal, '', '', $scope.dtFromDate, $scope.dtToDate, '', 'UtilityWise');
            //        }
            //        //if (chartid == 'chartid2') {
            //        //    $scope.GetData_UtilityWise($scope.varPlant_ID, $scope.varBrand_ID, pointVal, '', '', $scope.dtFromDate, $scope.dtToDate, '', 'UtilityWise');
            //        //}
            //    },
            //    size:
            //        {
            //            height: 250
            //        },
            //    seriesTemplate: {				
            //        nameField: "varPackType",
            //        customizeSeries: function(valueFromNameField) {
            //            return { label: { 
            //                visible: true,
            //                customizeText: function(pointInfo) {
            //                    debugger                               
            //                    var series = $("#" + chartid).dxChart('instance').getAllSeries();
            //                    var lastSeries = series[series.length - 1];
            //                    if (pointInfo.seriesName !== lastSeries.name) { 
            //                        return ""; 
            //                    } 
            //                    return pointInfo.total;
            //                }
            //            } };
            //        }
            //    },
            //    legend: {
            //        verticalAlignment: "bottom",
            //        horizontalAlignment: "center",
            //        itemTextPosition: "right"
            //    },

            //});
        }
    };


    var options = {
        bindguage: function (guageid, guagecolor, actual, maxval, titletext, brand, umo) {
            var objgauge = $("#" + guageid).dxCircularGauge($.extend(true, {}, {
                value: actual,
                subvalues: actual,
                containerBackgroundColor: guagecolor,
                geometry: {
                    startAngle: 180,
                    endAngle: 0
                },
                scale: {
                    startValue: 0,
                    endValue: maxval,
                    tickInterval: maxval,
                    label: {
                        visible: true,
                        format: {
                            precision: 2
                        }
                    },
                    tick: {
                        color: 'transparent'
                    },
                    orientation: "inside"
                },
                tooltip: {
                    enabled: false,
                    ToolTipVisibility: "always"
                },
                title: {
                    text: titletext,
                    verticalAlignment: "bottom",
                    font: {
                        size: 12,
                        weight: 600
                    },
                },
                size: {
                    height: 200,
                },

                valueIndicator: {
                    type: "triangleNeedle",
                    color: guagecolor,
                    width: 15,
                },
                subvalueIndicator: {
                    type: "textcloud",
                    text: {
                        customizeText: function (arg) {
                            return parseFloat(arg.valueText).toFixed(2);
                        }
                    }
                },
                rangeContainer: {
                    offset: 30,
                    fontsize: 12,
                    ranges: [
                        { startValue: 0, endValue: maxval, color: "rgb(254, 178, 27)" },
                    ],
                    width: 40
                },

                label: {
                    enabled: true
                }
            }));
            $("#" + guageid).append('<input type="hidden" value="' + brand + '" id="hdnbrand' + guageid + '"  />');
            $("#" + guageid).append('<input type="hidden" value="' + umo + '" id="hdnumo' + guageid + '" />');
        }
    };

    $scope.RedirectToRefinary = function (id) {
        var hdnbrand = $('#hdnbrand' + id).val();
        var hdnuom = $('#hdnumo' + id).val();
        var hdnRefinaryCode = $('#hdnRefinaryCode').val();
        $window.location.assign(AppURL + '/dashboard/LineWiseConsumptionGraph?prm=' + $rootScope.EncryptionText('Pnt=' + $scope.varPlant_ID + '&Prd=' + $scope.varBrand_ID +
            '&brand=' + hdnbrand + '&umo=' + hdnuom + '&RefinaryCode=' + hdnRefinaryCode));
    };


    $scope.GenerateScrollableGrid = function (intheight, id) {
        var ar_width = [], obj = 0;
        ar_width.push({ width: 125, align: 'center' });
        ar_width.push({ width: 50, align: 'center' });
        if (id == 'utchart') {
            obj = $scope.utype.length;
        } else {
            obj = $scope.ctype.length
        }
        for (var col = 0; col < obj; col++) {
            ar_width.push({ width: 120, align: 'center' })
        }

        $("#fullChrt").find('#' + id).fxdHdrCol({
            fixedCols: 2,
            width: ($("#fullChrt").find('#' + id).parents('div.chart-box').parent('div').width() - 15),
            height: intheight - 10,
            colModal: ar_width,
            sort: false
        });
    };

    $scope.Get_PackTypeWise_Indent_VS_Actual = function (varPlant_ID, varPackType, strRefinaryCode, from_date, to_date, varAction) {
        if (strRefinaryCode == '') {
            $scope.mvarRefinary_Code = '';
        } else {
            $scope.mvarRefinary_Code = '- ' + strRefinaryCode;
        }
        var promiseSucc = Applicationservice.USP_PackType_Wise_Packaging_Dashboard(varPlant_ID, varPackType, strRefinaryCode, '', '', from_date, to_date, $scope.QtyType, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {

                $scope.ChemicalArray = $.parseJSON(pl.data)['Table'];
                $scope.BindPackTypeWise_Indent_VS_ActualChart();
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.BindPackTypeWise_Indent_VS_ActualChart = function () {

        var jsonData = $scope.ChemicalArray;
        $scope.varPackTypeVal = '';
        // var jsonData = $.parseJSON($scope.ChemicalArray)['Table'];;
        $("#div_cchart").html('');
        $scope.ctype = [];
        $scope.cname = [];
        if (jsonData != undefined && jsonData != null && jsonData.length > 0) {

            var obj = jsonData;
            if (obj != undefined && obj != null && obj.length > 0) {
                $scope.varPackTypeVal = obj[0]["TotalPackTypeVal"];
                var col = [];
                for (var i = 0; i < obj.length; i++) {
                    for (var key in obj[i]) {
                        if (col.indexOf(key) === -1) {
                            if (key != 'TotalPackTypeVal') {
                                col.push(key);
                            }
                        }
                    }
                }
                var table = document.createElement("table");
                table.style.width = "100%";
                table.setAttribute('class', 'table-bordered')
                //table.setAttribute("border", "1px solid");
                //table.style.borderColor = "#ddd";
                var tr = table.insertRow(-1);

                for (var i = 0; i < col.length; i++) {
                    var th = document.createElement("th");
                    th.style.backgroundColor = "#229c9e";
                    th.style.color = "#fff";
                    th.style.padding = "0.65rem";
                    th.style.lineHeight = "19px";
                    th.style.fontSize = "14px";
                    th.innerHTML = col[i];
                    tr.appendChild(th);
                }               
                for (var i = 0; i < obj.length; i++) {
                    tr = table.insertRow(-1);
                    for (var j = 0; j < col.length; j++) {
                        var tabCell = tr.insertCell(-1);
                        if (j == 0) {
                            tabCell.innerHTML = obj[i][col[j]];
                            tabCell.style.textAlign = "center";
                            tabCell.style.padding = "0.50rem";
                            tabCell.style.lineHeight = "15px";
                            tabCell.style.fontSize = "12px";
                        }
                        else {
                            tabCell.innerHTML = obj[i][col[j]];
                            tabCell.style.textAlign = "right";
                            tabCell.style.padding = "0.50rem";
                            tabCell.style.lineHeight = "15px";
                            tabCell.style.fontSize = "12px";
                        }

                    }
                }


                //if (obj.length > 1) {
                    tr = table.insertRow(-1);
                    var tabCell = tr.insertCell(-1);
                    tabCell.innerHTML = "Total";
                    tabCell.style.textAlign = "center";
                    tabCell.style.padding = "0.50rem";
                    tabCell.style.lineHeight = "15px";
                    tabCell.style.fontSize = "12px";
                    tabCell.style.fontWeight = "bolder";

                    for (var j = 1; j < col.length; j++) {
                        var tabCell = tr.insertCell(-1);
                        var sum = 0;
                        for (var i = 0; i < obj.length; i++) {
                            sum += obj[i][col[j]];
                        }
                        tabCell.innerHTML = parseFloat(sum).toFixed(2);
                        tabCell.style.textAlign = "right";
                        tabCell.style.padding = "0.50rem";
                        tabCell.style.lineHeight = "15px";
                        tabCell.style.fontSize = "12px";
                        tabCell.style.fontWeight = "bolder";
                    }
                //}

                var divContainer = document.getElementById("div_cchart");
                divContainer.innerHTML = "";
                divContainer.appendChild(table);

                $('#zoom3').css("display", "block");
            }
            else {
                $('#zoom3').css("display", "block");
            }
        }
        else {
            $('#zoom3').css("display", "block");
        }
    }


    $scope.GetData_Line_Utilization_Grid = function (varPlant_ID, varPackType, strRefinaryCode, from_date, to_date, varAction) {

        if (strRefinaryCode == '') {
            $scope.mvarRefinary_Code = '';
        } else {
            $scope.mvarRefinary_Code = '- ' + strRefinaryCode;
        }

        var promiseSucc = Applicationservice.USP_PackType_Wise_Packaging_Dashboard(varPlant_ID, varPackType, strRefinaryCode, '', '', from_date, to_date, $scope.QtyType, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {

                $scope.SKUWiseArray = $.parseJSON(pl.data)['Table'];
                $scope.BindSKUWise_Utilisation();
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.BindSKUWise_Utilisation = function () {

        var jsonData = $scope.SKUWiseArray;
        // var jsonData = $.parseJSON($scope.ChemicalArray)['Table'];;
        $("#div_Utilizationchart").html('');
        $scope.ctype = [];
        $scope.cname = [];
        if (jsonData != undefined && jsonData != null && jsonData.length > 0) {

            var obj = jsonData;

            if (obj != undefined && obj != null && obj.length > 0) {
                $scope.mUtilisationTotal = obj[obj.length - 1]["Utilization"];
                var col = [];
                for (var i = 0; i < obj.length; i++) {
                    for (var key in obj[i]) {
                        if (col.indexOf(key) === -1) {
                            if (key != 'Total') {
                                col.push(key);
                            }
                        }
                    }
                }
                var table = document.createElement("table");
                table.style.width = "100%";
                table.setAttribute('class', 'table-bordered')

                //table.setAttribute("border", "1px solid");
                //table.style.borderColor = "#ddd";
                var tr = table.insertRow(-1);

                for (var i = 0; i < col.length; i++) {
                    var th = document.createElement("th");
                    th.style.backgroundColor = "#229c9e";
                    th.style.color = "#fff";
                    th.style.padding = "0.65rem";
                    th.style.lineHeight = "19px";
                    th.style.fontSize = "14px";
                    th.innerHTML = col[i];
                    tr.appendChild(th);
                }
                for (var i = 0; i < obj.length; i++) {

                    tr = table.insertRow(-1);
                    for (var j = 0; j < col.length; j++) {
                        if (col.length - 1 == j) {
                            if (i == 0) {
                                var tabCell = tr.insertCell(-1);
                                tabCell.innerHTML = $scope.mUtilisationTotal;
                                tabCell.align = "center";
                                tabCell.style.minWidth = "80px";
                                tabCell.style.padding = "0.50rem";
                                tabCell.rowSpan = obj.length;
                                tabCell.style.lineHeight = "15px";
                                tabCell.style.fontSize = "12px";
                            }
                            break;
                        }

                        var tabCell = tr.insertCell(-1);
                        tabCell.innerHTML = obj[i][col[j]];
                        tabCell.align = "center";
                        tabCell.style.minWidth = "80px";
                        tabCell.style.padding = "0.50rem";
                        tabCell.style.lineHeight = "15px";
                        tabCell.style.fontSize = "12px";
                        if (obj[i][col[0]] == "Total") {
                            tabCell.style.fontWeight = "bolder";
                        }
                    }
                }

                var divContainer = document.getElementById("div_Utilizationchart");
                divContainer.innerHTML = "";
                divContainer.appendChild(table);

                $('#zoom4').css("display", "block");
            }
            else {
                $('#zoom4').css("display", "block");
            }
        }
        else {
            $('#zoom4').css("display", "block");
        }
    }

    //$scope.producttable = function (datatab) {
    //    if (datatab != '' && datatab != null && Object.keys(datatab).length > 0) {
    //        var obj = datatab;
    //        var ptable = document.createElement("Table");
    //        ptable.setAttribute("class", "tabledata");
    //        document.getElementById("tabchart").appendChild(ptable);
    //        var headtr = document.createElement("tr");
    //        headtr.setAttribute("id", "htr");
    //        document.getElementById("tabchart").appendChild(headtr);
    //        var headth = document.createElement("th");
    //        document.getElementById("htr").appendChild(headth);
    //        for (var i = 0; i < Object.keys(obj).length; i++) {
    //            //var headtr = document.createElement("tr");
    //            //headtr.setAttribute("id","htr");
    //            //document.getElementById("tabchart").appendChild(headtr);
    //            var headth1 = document.createElement("th");
    //            headth1.innerHTML = obj[i];
    //            document.getElementById("htr").appendChild(headth1);
    //        }
    //    }
    //}
}]);
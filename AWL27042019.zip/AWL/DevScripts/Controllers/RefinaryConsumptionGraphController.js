﻿app.controller('RefinaryConsumptionGraphController', ['$scope', 'Applicationservice', '$rootScope', '$window', '$filter', '$timeout', '$location', 'AppURL', function ($scope, Applicationservice, $rootScope, $window, $filter, $timeout, $location, AppURL) {

    var personglcode = localStorage.getItem('personglcode');
    $scope.Type = 'Q';
    $scope.QtyType = 'M';
    $scope.varCycle = 'mtd';
    $scope.QuarterTamplateList = [];
    $scope.val1 = [];
    $scope.fk_ProductGlCode = 0;
    $scope.fk_PlantGlCode = 0;
    $scope.fk_BrandGlCode = 0;
    $scope.Refinaryglcode = 0;
    $scope.varAction = '';
    $scope.mlblCycle = localStorage.getItem('varCycle').toUpperCase()

    $scope.changeCycle = function (strCycle) {
        $('#dl-menu5').dlmenu('closeMenu');
        $scope.mlblCycle = strCycle.toUpperCase();
        $scope.varCycle = strCycle;
        localStorage.setItem('varCycle', $scope.varCycle);
        $('#cycle_' + $scope.varCycle).prop('checked', true)
        $('#liBrcmnCycle').text($scope.mlblCycle);
        $scope.QtyType = 'M';
        if ($scope.varCycle != '' && $scope.varCycle != "" && $scope.varCycle != 'mtd') {
            $scope.QtyType = ($scope.varCycle == 'qtd' ? 'Q' : 'Y');
        }

        var cycle = $rootScope.GetMonthDetails($scope.varCycle);
        $('#liBrcmnCycle').text(cycle);
        $scope.StandardVsActualRefinaryData();
    };

    $scope.initLoadData = function () {
        $rootScope.mvisibleBack = false;
        $rootScope.mvisibleDateCycle = true;
        $rootScope.mvisibleHoreport = false;
        $rootScope.topHeading = 'Refined: Refinary Consumption Graph';
        $scope.varCycle = localStorage.getItem('varCycle');
        $scope.QtyType = 'M';
        var FID = localStorage.getItem("FID");
        $rootScope.insertformvisit($rootScope.topHeading, FID);
        if ($scope.varCycle != '' && $scope.varCycle != "" && $scope.varCycle != 'mtd') {
            $scope.QtyType = ($scope.varCycle == 'qtd' ? 'Q' : 'Y');
        }
        var url_main = $window.location.pathname.toLowerCase();
        if (url_main.search('dashboard/refinaryconsumptiongraph') != -1) {
            var url = $window.location.search;
            if (url.split('?').length > 1) {

                var Decrp = $rootScope.DecryptionText(url.split('?prm=')[1]);
                if (Decrp != null && Decrp != '') {
                    $scope.fk_PlantGlCode = (Decrp.split('&')[0].split('=')[1]);
                    $scope.fk_BrandGlCode = (Decrp.split('&')[1].split('=')[1]);
                    $scope.fk_ProductGlCode = (Decrp.split('&')[2].split('=')[1]);
                    $scope.fk_RefinaryGlCode = (Decrp.split('&')[3].split('=')[1]);

                    angular.element('#wrapper').scope().mBrcmnProduct = $scope.fk_BrandGlCode;
                    angular.element('#wrapper').scope().mBrcmnPlant = $scope.fk_PlantGlCode;
                    $('.breadcrumbs-menu ul').attr('style', 'opacity: 0;');
                    setTimeout(function () {
                        $('#plant_' + $scope.fk_PlantGlCode).prop('checked', true);
                        $('#liBrcmnPlant').text($('#plant_' + $scope.fk_PlantGlCode).siblings('p').html());

                        $('#brand_' + $scope.fk_BrandGlCode).prop('checked', true);
                        $('#liBrcmnProduct').text($('#brand_' + $scope.fk_BrandGlCode).siblings('p').html());
                        $('.breadcrumbs-menu ul').attr('style', 'opacity: 1; transition: opacity 500ms linear;');
                    }, 2000);

                    $scope.StandardVsActualRefinaryData();
                }
            }
        }
    }

    $scope.insertformvisit = function (formname) {
        var app = '';
        var flag = 'D';
        var ip = localStorage.getItem('your ip');
        var pglcode = localStorage.getItem('personglcode');
        var version = localStorage.getItem('ApplicationVersion');
        if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
            var app = 'M';
        } else {
            app = 'W';
        }
        var promiseSucc = Applicationservice.Insert_Login_Details('', '', ip, '', '', '', pglcode, app, formname, version, flag);
        promiseSucc.then(function (pl) {
            var data = $.parseJSON(pl.data);
            var id = data["Table"][0]["NID"]
            localStorage.setItem("FID", id);
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    var searchObject = $location.search();
    if (searchObject != undefined && searchObject.para1 == 'true') {
        $scope.showClose = true;
        $scope.mType = searchObject.para3;
        $scope.QtyType = searchObject.para2;
    } else {
        $scope.showClose = false;
    }
    $scope.OnBackClick = function () {

        $window.location.assign(AppURL + '/dashboard/RefinaryWiseSteamConsumption?prm=' + $rootScope.EncryptionText("Pnt=" + $scope.fk_PlantGlCode + "&Prd=" + $scope.fk_BrandGlCode + "&product_id=" + $scope.fk_ProductGlCode));
    };

    $scope.StandardVsActualRefinaryData = function () {
        debugger;
        var promiseSucc = Applicationservice.GET_REFINARY_NAME_UNIT($scope.fk_PlantGlCode, $scope.fk_BrandGlCode, $scope.fk_ProductGlCode, $scope.fk_RefinaryGlCode, '');
        promiseSucc.then(function (pl) {

            if (pl.data !== null && pl.data !== '') {
                var obj = $.parseJSON(pl.data)['Table'];
                if (obj.length == 0) {
                    return;
                }

                $scope.refinaryname = obj[0]["Refinary_Name"].substr(0, 1).toUpperCase() + obj[0]["Refinary_Name"].substr(1).toLowerCase();
                $scope.unitname = obj[0]["UOM"];
                $scope.Product_Name = obj[0]["Product_Name"].substr(0, 1).toUpperCase() + obj[0]["Product_Name"].substr(1).toLowerCase();
                var action = obj[0]["Product_Category"];
                if (action == "Utility") {
                    $scope.varAction = "GetUtilityConsumptionRefinaryWise";
                }
                else {
                    $scope.varAction = "GetChemicalConsumptionRefinaryWise";
                }
            }

            var varCycle = localStorage.getItem('varCycle');

            var promiseSucc = Applicationservice.Get_Date_Range(varCycle);
            promiseSucc.then(function (pl) {
                if (pl.data != null) {
                    $scope.QuarterTamplateList = pl.data;

                    // var M_FromDate = $scope.QuarterTamplateList[1]['dtFromDate'];
                    // var M_ToDate = $scope.QuarterTamplateList[1]['dtToDate'];

                    $scope.from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                    $scope.to_date = $scope.QuarterTamplateList[4]['dtToDate'];

                    var Type = 'Q';
                    if ($scope.Type == 'Q') {
                        $scope.val1 = $scope.Product_Name + " Consumption Std. Vs Act. (Per MT)";
                    }
                    if ($scope.Type == 'R') {
                        $scope.val1 = $scope.Product_Name + " Consumption Std. Vs Act. (Per MT)";
                    }

                    $scope.QtyType = 'M';
                    if ($scope.varCycle != '' && $scope.varCycle != "" && $scope.varCycle != 'mtd') {
                        $scope.QtyType = ($scope.varCycle == 'qtd' ? 'Y' : 'Y');
                    }

                    $scope.Bind_Refined_Production_chart($scope.fk_BrandGlCode, $scope.fk_PlantGlCode, $scope.from_date, $scope.to_date, $scope.fk_RefinaryGlCode, $scope.fk_ProductGlCode, "M", $scope.Type, $scope.QtyType, $scope.varAction);
                    $scope.Bind_Refined_Production_Qty_chart($scope.fk_BrandGlCode, $scope.fk_PlantGlCode, $scope.from_date, $scope.to_date, $scope.fk_RefinaryGlCode, $scope.fk_ProductGlCode, "M", "Q", "Y", $scope.varAction);
                    $scope.Bind_Refined_Production_RS_chart($scope.fk_BrandGlCode, $scope.fk_PlantGlCode, $scope.from_date, $scope.to_date, $scope.fk_RefinaryGlCode, $scope.fk_ProductGlCode, "M", "R", "Y", $scope.varAction);
                }
            }, function (errorPl) {
                $scope.error = errorPl;
            });
        });


    }

    $scope.Bind_Refined_Production_chart = function (fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, fk_RefinaryGlCode, fk_ProductGlCode, QtyType, Type, chrMonthType, varAction) {

        var promiseSucc = Applicationservice.Get_Refinary_Wise_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, fk_RefinaryGlCode, fk_ProductGlCode, QtyType, Type, chrMonthType, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != '') {
                var QtyType = 'M';
                var Type = 'Q';
                var obj = $.parseJSON(pl.data)['Table'];
                if ($scope.Type == 'Q') {
                    if ($scope.QtyType == 'Y') {
                        chart.bindchart(obj, 'MT');
                    }
                    else {
                        chart.bindchart(obj, 'MT');
                    }
                }
                if ($scope.Type == 'R') {
                    if ($scope.QtyType == 'Y') {
                        chart.bindchart(obj, 'Rs.');
                    }
                    else {
                        chart.bindchart(obj, 'Rs.');
                    }
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.Bind_Refined_Production_Qty_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, fk_RefinaryGlCode, fk_ProductGlCode, QtyType, Type, chrMonthType, varAction) {
        var promiseSucc = Applicationservice.Get_Refinary_Wise_Refined_Dashboard($scope.fk_BrandGlCode, $scope.fk_PlantGlCode, $scope.from_date, $scope.to_date, $scope.fk_RefinaryGlCode, $scope.fk_ProductGlCode, QtyType, Type, chrMonthType, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != '') {
                var obj = $.parseJSON(pl.data)['Table'];
                Achart.bindDchart("chartid1", obj);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    function getMax(arr, prop) {
        var max;
        for (var i = 0 ; i < arr.length ; i++) {
            if (!max || parseFloat(arr[i][prop]) > parseFloat(max))
                max = arr[i][prop];
        }
        return max;
    }

    $scope.Bind_Refined_Production_RS_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, fk_RefinaryGlCode, fk_ProductGlCode, QtyType, Type, chrMonthType, varAction) {
        var promiseSucc = Applicationservice.Get_Refinary_Wise_Refined_Dashboard($scope.fk_BrandGlCode, $scope.fk_PlantGlCode, $scope.from_date, $scope.to_date, $scope.fk_RefinaryGlCode, $scope.fk_ProductGlCode, QtyType, Type, chrMonthType, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != '') {
                var obj = $.parseJSON(pl.data)['Table'];
                Achart.bindDchart("chartid2", obj);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    var chart = {
        bindchart: function (dataSource, valueaxis, titles) {
            var MaxActval = getMax(dataSource, 'Actual_Qty');
            var MaxStdval = parseFloat(getMax(dataSource, 'Standard_Qty')).toFixed(2);
            var chartMax = (MaxActval > MaxStdval) ? (MaxActval + (MaxActval * 0.05)) : (MaxStdval + (MaxStdval * 0.05));
            chartMax = parseFloat(chartMax).toFixed(2);
            var highAverage = parseFloat(MaxStdval).toFixed(2);

            $("#chart1").dxChart({
                dataSource: dataSource,
                margin: {
                    bottom: 10, top: 20, right: 10
                },
                commonSeriesSettings: {
                    argumentField: 'varType',
                    redrawOnResize: true,
                    valueField: "Actual_Qty",
                    type: "bar",
                    color: "#e7d19a",
                    label: {
                        rotationAngle: 270,
                        position: 'outside'
                    }
                },
                customizePoint: function () {
                    if (this.value > highAverage) {
                        return { color: "#ff7c7c", hoverStyle: { color: "#ff7c7c" } };
                    }
                },
                customizeLabel: function () {

                    if (this.value > highAverage) {
                        return {
                            visible: true,
                            font: { color: "black" },
                            backgroundColor: "transparent",
                            customizeText: function () {
                                return parseFloat(this.valueText).toFixed(2);
                            }
                        };
                    }
                    else {
                        return {
                            visible: true,
                            font: { color: "black" },
                            backgroundColor: "transparent",
                            customizeText: function () {
                                return parseFloat(this.valueText).toFixed(2);
                            }
                        };
                    }
                },
                valueAxis: {
                    //maxValueMargin: 0.1,
                    max: chartMax,
                    label: {
                        customizeText: function () {
                            return this.valueText;
                        }
                    },
                    constantLines: [
                        {
                            label: {
                                text: "Std. Value : " + (MaxStdval),
                                horizontalAlignment: "right",
                            },
                            width: 2,

                            value: MaxStdval,
                            color: "#ff7c7c",
                            dashStyle: "dash"
                        }]
                },
                series: [{}],
                legend: {
                    visible: false
                }
            }).dxChart("instance");
        }
    }
    var Achart = {
        bindDchart: function (chartid, dataSource) {
            $("#" + chartid).dxChart({
                palette: "Harmony Light",
                dataSource: dataSource,
                commonSeriesSettings: {
                    type: "area",
                    argumentField: "varType"
                },
                size: {
                    height: 300
                },
                series: [
                    { valueField: "Standard_Qty", name: "Standard" },
                    { valueField: "Actual_Qty", name: "Actual" }
                ],
                margin: {
                    bottom: 20, top: 20
                },
                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "right"
                }
            }).dxChart("instance");
        }
    };


}]);
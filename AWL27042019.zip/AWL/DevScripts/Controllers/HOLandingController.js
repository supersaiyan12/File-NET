app.controller('HOLandingController', ['$scope', 'Applicationservice', '$rootScope', '$window', '$filter', '$timeout', '$location', 'AppURL', function ($scope, Applicationservice, $rootScope, $window, $filter, $timeout, $location, AppURL) {

    $scope.redirecttoplant = function () {
        $window.location.assign(AppURL + '/dashboard/Plant_Details/')
    };
    $scope.varBrand_ID = '';
    $scope.varPlant_ID = '';
    $scope.QuarterTamplateList = [];
    $scope.ALLPlant_ProductList = [];
    $scope.BrandType = [];
    $scope.BrandName = [];
    $scope.utype = [];
    $scope.pname = [];
    $scope.ctype = [];
    $scope.cname = [];

    $scope.plants = [];
    $scope.value = [];
    $scope.UtilityArray = [];
    $scope.ChemicalArray = [];

    $scope.isAutoPlay = false;

    var lastTab = '';
    var activeTab;
    var counter = 0;
    var count = 0
    var id;
    var length;
    $scope.ar_marqueeData = [];
    $scope.MarqueeData = function (marqueeid) {
        var promiseSucc = Applicationservice.Get_Refined_Product_Marquee(marqueeid);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {
                obj = JSON.parse(pl.data)["Table"];
                $scope.ar_marqueeData = obj;
                $scope.SetMarqueeData($scope.ar_marqueeData);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.SetMarqueeData = function (obj) {
        $("#marqid").html('');
        var ul = document.getElementById("marqid");

        var html = '';
        for (var i = 0; i < obj.length; i++) {
            $scope.plants = obj[i]["Plant_Name"];
            $scope.value = obj[i]["value"];
            var li = document.createElement("li");
            li.setAttribute("id", "marq" + i);
            html += '<li id="marq' + i + '" class="non-marquee ' + (i == 0 ? "use-marquee" : "") + '"><div style="width:100%;height: 20px;">'
                + '<div class="HOmarqueemini" style="float:left;background-color:#2ca9ab;height: 20px;color:white;padding-top:3px;text-align:center;min-width:8.5%">'
                + ' <div style="display: inline-block;">' + $scope.plants + '</div>'
                + '<div style="display: inline-block;float: right;padding-right: 5px;background: #e39d45;padding: 3px;margin-top: -3px;"><small>MTD</small></div></div>'
                + '<div class="HOmarqueeValuemini" style="float:left;height: 20px;"><div id="marq11' + i + '" class="' + (i == 0 ? "marquee" : "") + '" style="color:blackheight:20px;padding-top:3px;">'
                + $scope.value + '</div></div></div></li>';
        }

        $("#marqid").html(html);
        length = document.getElementById("marqid").getElementsByTagName("li").length;

        $("#marqid").parent().css('height', '20px');

        $('.marquee').bind('finished', function () {
            $scope.changemarquee();
        }).marquee({
            pauseOnHover: true,
            duration: 20000
        });

    };

    $scope.changemarquee = function () {
        if (length != 0) {
            counter = counter + 1;

            lastTab = document.getElementById("marq11" + (counter - 1));
            $(lastTab).parents("li").removeClass("use-marquee");
            $(lastTab).parents("li").addClass("non-marquee");
            $(lastTab).removeClass("marquee");

            if (counter == length) {
                counter = 0;
                $scope.SetMarqueeData($scope.ar_marqueeData);
                return;
            }
            activeTab = document.getElementById("marq11" + counter);
            $(activeTab).addClass("marquee");
            $(activeTab).parents("li").addClass("use-marquee");
            $(activeTab).bind('finished', function () {
                $scope.changemarquee();
            }).marquee({
                pauseOnHover: true,
                duration: 20000
            });
        }
    };

    $scope.fileronChange = function (plantID, ProductID) {
        var role_code = localStorage.getItem('var_RoleName');
        if (role_code.toLowerCase() == "HO".toLowerCase() || role_code.toLowerCase() == "AWL Admin".toLowerCase()) {
            plantID = '';
        }

        $window.location.assign(AppURL + '/dashboard/HOLanding?prm=' + $rootScope.EncryptionText("Pnt=" + plantID + "&Prd=" + ProductID));
    };

    $scope.onclickLoad = function (action) {
        $('.cyclePanl').attr('class', 'box mtd highlightpnl');
        $('#' + action).attr("class", "box mtd highlightpnl cyclePanl");
        localStorage.setItem('varCycle', $('.cyclePanl').attr('id'));
        angular.element('#wrapper').scope().mBrcmnCycleName = action.toUpperCase();
        var cycle = $rootScope.GetMonthDetails(action);
        $('#liBrcmnCycle').text(cycle);
        $scope.USP_Get_Yearly_QuarterNo('click');
    };

    $scope.initLoadData = function () {

        //debugger

        $rootScope.topHeading = 'Refined: Product Summary (HO)';
        $rootScope.mvisibleBack = false;
        $rootScope.mvisibleDateCycle = true;
        $rootScope.mvisibleHoreport = false;
        var FID = localStorage.getItem("FID");
        $rootScope.insertformvisit($rootScope.topHeading, FID);

        var url_main = $window.location.pathname.toLowerCase();
        if (url_main.search('dashboard/holanding') != -1) {
            var url = $window.location.search;
            if (url.split('?').length > 1) {
                var Decrp = $rootScope.DecryptionText(url.split('?prm=')[1]);
                if (Decrp != null && Decrp != '') {
                    $scope.varPlant_ID = (Decrp.split('&')[0].split('=')[1]);
                    $scope.varBrand_ID = (Decrp.split('&')[1].split('=')[1]);
                    $('.breadcrumbs-menu ul').attr('style', 'opacity: 0;');
                    setTimeout(function () {
                        if ($scope.varPlant_ID != null && $scope.varPlant_ID != '') {
                            $('#plant_' + $scope.varPlant_ID).prop('checked', true);
                            $('#liBrcmnPlant').text($('#plant_' + $scope.varPlant_ID).siblings('p').html());
                        }
                        else {
                            $('#liBrcmnPlant').text('All Plant');
                        }
                        $('#brand_' + $scope.varBrand_ID).prop('checked', true);
                        $('#liBrcmnProduct').text($('#brand_' + $scope.varBrand_ID).siblings('p').html());

                        angular.element('#wrapper').scope().mBrcmnProduct = $scope.varBrand_ID;
                        angular.element('#wrapper').scope().mBrcmnPlant = $scope.varPlant_ID;
                        $('.breadcrumbs-menu ul').attr('style', 'opacity: 1; transition: opacity 500ms linear;');
                    }, 1500);
                    $scope.MarqueeData(0);
                    $scope.USP_Get_Yearly_QuarterNo('load');

                }
            }

            else {
                setTimeout(function () {
                    $scope.varBrand_ID = $('ul#BrandList').find('li label input:checked').parents('label').attr('data-id');
                    $scope.MarqueeData(0);
                    $scope.USP_Get_Yearly_QuarterNo('load');

                }, 2000);
            }

            if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
                $rootScope.mvisiblePlay = false;
            }
        }
    };

    $scope.USP_Get_Yearly_QuarterNo = function (action) {

        var highlightCycle = localStorage.getItem('varCycle');
        $('.cyclePanl').attr('class', 'box mtd highlightpnl');
        $('#' + highlightCycle).attr("class", "box mtd highlightpnl cyclePanl");

        var promiseSucc = Applicationservice.Get_Date_Range(highlightCycle);
        promiseSucc.then(function (pl) {
            if (pl.data != null) {
                $scope.QuarterTamplateList = pl.data;
                if (pl.data != null && pl.data.length > 4) {
                    var from_date = $scope.QuarterTamplateList[0]['dtFromDate'];
                    var to_date = $scope.QuarterTamplateList[0]['dtToDate'];
                    if (action == 'load') {

                        $('#yesterday').html('');
                        $('#mtd').html('');
                        $('#qtd').html('');
                        $('#ytd').html('');
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'Yesterday');

                        from_date = $scope.QuarterTamplateList[1]['dtFromDate'];
                        to_date = $scope.QuarterTamplateList[1]['dtToDate'];
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'MTD');

                        from_date = $scope.QuarterTamplateList[2]['dtFromDate'];
                        to_date = $scope.QuarterTamplateList[2]['dtToDate'];
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'QTD');

                        from_date = $scope.QuarterTamplateList[3]['dtFromDate'];
                        to_date = $scope.QuarterTamplateList[3]['dtToDate'];
                        $scope.GetALLPlant_Product_Refind_Dashboard($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'YTD');

                        from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                        to_date = $scope.QuarterTamplateList[4]['dtToDate'];
                        $scope.AutoPlayBrandList(from_date, to_date);
                    }

                    from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                    to_date = $scope.QuarterTamplateList[4]['dtToDate'];

                    $scope.GetSubjectList($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'ACTUAL LOSS');
                    $scope.GetSubjectList($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'PRODUCTION');
                    $scope.GetSubjectListforUtility($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'UTILITY');
                    $scope.GetSubjectListforChemical($scope.varBrand_ID, $scope.varPlant_ID, from_date, to_date, 'CHEMICAL');
                    $scope.Rankingdata(from_date, to_date);
                }
                var PlayProduct = localStorage.getItem('PlayProductHO');
                if (PlayProduct == "1") {
                    $('.overlaydisplyProductName').fadeTo(100, 0.9);
                    $('.displyProductName').fadeIn(100);
                    $('.displyProductName h1').html($('#liBrcmnProduct').html());
                    $('.displyProductName').fadeOut(3000);
                    setTimeout(function () {
                        chrtPosChangeInterval = setInterval($scope.rotateCycle, 5000);
                    }, 500);
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.AutoPlayBrandList = function (from_date, to_date) {
        $rootScope.AutoPlayBrandList = [];
        var promiseSucc = Applicationservice.USP_Get_Refine_AutoPlayProd(from_date, to_date, "Refine");
        promiseSucc.then(function (pl) {
            if (pl.data != null) {
                $rootScope.AutoPlayBrandList = JSON.parse(pl.data);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.Rankingdata = function (from_date, to_date) {
        var promiseSucc = Applicationservice.USP_GET_Daily_Ranking_Details(from_date, to_date);
        promiseSucc.then(function (pl) {
            if (pl.data == null) {
                return;
            }
            $scope.RankList = JSON.parse(pl.data)['Table'];
            $("#rankList").html('<ul class="bxslider1" id="Rankchart"></ul>');
            if ($scope.RankList != null) {
                var html = '';
                for (var i = 0; i < $scope.RankList.length; i++) {
                    html += '<li id="liutchart0" style="padding-left: 0px; float: left; list-style: none; position: relative; margin-right: 10px;" aria-hidden="false">';
                    html += '<div id="div10" class="progress progress-bar-vertical">';
                    html += '<div id="div20" class="progress-bar" role="progressbar" style="position: absolute;width: inherit;bottom: 8px !important;border-radius: 8px;border-top-left-radius: 0px;border-top-right-radius: 0px;height:' + (parseFloat($scope.RankList[i]['RANKPERCENT']) * 66 / 100) + '%!important"></div>';
                    html += '<div id="div30" style="position:absolute;width: inherit;bottom: 0;height: 100%;">';
                    html += '<div id="span0" class="progress-completed" style="font-size: 14px;padding: 10px 0 8px 0;background: #4988b5;border-top-left-radius: 8px;border-top-right-radius: 8px;color: #fdfdfd;font-weight: bold;">Rank : ' + $scope.RankList[i]['RANKING'] + '</div>';
                    html += '<div id="span20" class="progress-completed" style="padding: 10px 0 5px 0;font-size: 17px;font-weight: bold;color:#656565;">' + $scope.RankList[i]['RANKPERCENT'] + '%</div>';
                    html += '<div id="span30" class="progress-completed" style="padding: 5px;">' + $scope.RankList[i]['PlantName'] + '</div>';
                    html += '</div>';
                    html += '</div>';
                    html += '</li>';
                }
                $('.bxslider1').html(html);

                if (html != "" && $scope.RankList.length > 5) {
                    $('.bxslider1').bxSlider({
                        mode: 'horizontal',
                        moveSlides: 1,
                        auto: true,
                        slideMargin: 0,
                        infiniteLoop: true,
                        randomStart: false,
                        hideControlOnEnd: false,
                        responsive: true,
                        keyboardEnabled: true,
                        autoHover: true,
                        controls: ($scope.isAutoPlay == true ? false : true),
                        speed: 500,
                        maxSlides: 5,
                        stopAutoOnClick: true,
                        slideWidth: 'auto',
                        pager: 0,
                    });
                    //$scope.isAutoPlay

                    //$('.bxslider1').bxSlider({
                    //    auto: true,
                    //    infiniteLoop: true,
                    //  //  responsive: true,
                    //    hideControlOnEnd: true,
                    //    pager:false,
                    //    autoHover: true,
                    //    controls: false,
                    //    maxSlides:5,
                    //    stopAutoOnClick: true,
                    //    slideWidth: 'auto',
                    //});
                }
                else {
                    $('#rankList').css("padding", "0 17px 10px 31px");
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetALLPlant_Product_Refind_Dashboard = function (varBrand_ID, varPlant_ID, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.GetALLPlant_Product_Refind_Dashboard(varBrand_ID, varPlant_ID, from_date, to_date, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {
                $scope.ALLPlant_ProductList = JSON.parse(pl.data)['Table'];
                if ($scope.ALLPlant_ProductList != null) {
                    var d = new Date();
                    var last_year = parseInt(d.getFullYear()) - 1;

                    var html = '';
                    var ChrColor = $scope.ALLPlant_ProductList[0]['ChrColor'];
                    html += '<div class="box-left">';
                    html += '<h5>' + varAction + '</h5>';
                    html += '<h4></h4>';
                    html += '<h1>' + addCommas($scope.ALLPlant_ProductList[0]['Current_TotalQty']) + '<small style="font-size: 40%;">MT</small></h1>';
                    html += '</div>';
                    html += '<div class="box-right">';
                    html += '<div class="box-lastyrTag">vs ' + last_year + '</div>';
                    html += '<div class="box-right-arrow">';
                    html += '<i class="fa ' + (ChrColor == 'Red' ? 'fa-arrow-down' : 'fa-arrow-up') + ' darrow" style="color:' + (ChrColor == 'Red' ? '#fff' : '#fff') + ';"></i>';
                    html += '</div>';
                    html += '<h3 style="color:' + (ChrColor == 'Red' ? '#fff' : '#fff') + ';">' + $scope.ALLPlant_ProductList[0]['YOYPer'] + '%</h3>';
                    html += '</div>';

                    //html += '<div class="box-img">';
                    //html += '<div class="circleBase type1">';
                    //if (ChrColor == 'Red') {
                    //    html += '<i class="fa fa-arrow-down darrow" style="color:red;font-size: larger!important;"></i>';
                    //}
                    //else {
                    //    html += '<i class="fa fa-arrow-up darrow" style="color:#81BB4A;font-size: larger!important;"></i>';
                    //}
                    //html += '</div>';
                    //html += '<label>' + $scope.ALLPlant_ProductList[0]['YOYPer'] + ' %</label>';
                    //html += '</div>';
                    //html += '<div class="box-text">';
                    //html += '<h3>' + varAction + '</h3>';
                    //html += '<h4>VS ' + last_year + '</h4>';
                    //html += '<h2>' + addCommas($scope.ALLPlant_ProductList[0]['Current_TotalQty']) + '<small>MT</small></h2>';
                    //html += '</div>';

                    if (varAction == 'Yesterday') {
                        $('#yesterday').html(html);
                    }
                    else if (varAction == 'MTD') {
                        $('#mtd').html(html);
                    }
                    else if (varAction == 'QTD') {
                        $('#qtd').html(html);
                    }
                    else if (varAction == 'YTD') {
                        $('#ytd').html(html);
                    }
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.GetSubjectList = function (varBrand_ID, varPlant_ID, from_date, to_date, varAction) {

        var promiseSucc = Applicationservice.GetALLPlant_Product_Refind_Dashboard(varBrand_ID, varPlant_ID, from_date, to_date, varAction);
        promiseSucc.then(function (pl) {
            var jsonData = $.parseJSON(pl.data);

            if (jsonData != null && jsonData.Table != null) {
                obj = $.parseJSON(pl.data)['Table'];
                $scope.ALLPlant_ProductList = JSON.parse(pl.data);

                var scrnHeight1 = ($('.header-top').hasClass('header-top-hide') ? 15 : $('.header-top').height()) + 230 + $('#toppanel').height();
                var scrnHeight = $(window).height();
                if ($scope.isAutoPlay == true) {

                    if (varAction == 'PRODUCTION') {
                        //Dchart.bindDchart("doughnutchart1", obj, ((scrnHeight - scrnHeight1)));
                        Dchart.bindDchart("doughnutchart1", obj, ($('#dvMain').find('div#doughnutchart1').html() != undefined ? (scrnHeight - scrnHeight1) : ((scrnHeight - scrnHeight1 - 70) / 3)));
                        if (obj.length > 0) {
                            $('#zoom').attr("data-hasData", "1");
                        }
                        else {
                            $('#zoom').attr("data-hasData", "0");
                            //GetProductAutoList(false);
                        }
                    } else if (varAction == 'ACTUAL LOSS') {
                        //Bchart.bindBchart("barchart1", obj, 'VarPlant', ((scrnHeight - scrnHeight1 - 80) / 3));
                        Bchart.bindBchart("barchart1", obj, 'VarPlant', ($('#dvMain').find('div#barchart1').html() != undefined ? (scrnHeight - scrnHeight1) : ((scrnHeight - scrnHeight1 - 70) / 3)));
                        if (obj.length > 0) {
                            $('#zoom2').attr("data-hasData", "1");
                        }
                        else {
                            $('#zoom2').attr("data-hasData", "0");
                        }
                    }
                } else {
                    if (varAction == 'PRODUCTION') {
                        if (obj.length > 0) {
                            $('#zoom1').css("display", "block");
                            Dchart.bindDchart("doughnutchart", obj, 300);
                        } else {
                            //$('#dvMain').find('div#doughnutchart').html('');
                            //$('#zoom1').css("display", "none");
                            Dchart.bindDchart("doughnutchart", obj, 300);

                        }
                    } else if (varAction == 'ACTUAL LOSS') {

                        if (obj.length > 0) {
                            $('#zoom7').css("display", "block");
                            Bchart.bindBchart("barchart", obj, 'VarPlant', 300);
                        }
                        else {
                            //  $('#dvMain').find('div#barchart').html('');
                            // $('#zoom2').css("display", "none");
                            Bchart.bindBchart("barchart", obj, 'VarPlant', 300);
                        }

                    }
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetSubjectListforUtility = function (varBrand_ID, varPlant_ID, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.GetALLPlant_Product_Refind_Dashboard(varBrand_ID, varPlant_ID, from_date, to_date, varAction);
        promiseSucc.then(function (pl) {
            var jsonData = $.parseJSON(pl.data);
            $scope.UtilityArray = jsonData;
            var scrnHeight1 = ($('.header-top').hasClass('header-top-hide') ? 15 : $('.header-top').height()) + 230 + $('#toppanel').height();
            var scrnHeight = $(window).height();

            if ($scope.isAutoPlay == true) {
                $scope.BindUtilityChartForAuto(((scrnHeight - scrnHeight1 - 80) / 3));
                $(window).resize(function () {
                    $scope.BindUtilityChartForAuto(((scrnHeight - scrnHeight1 - 80) / 3));
                });
            } else {
                $scope.BindUtilityChart(300);
                $(window).resize(function () {
                    $scope.BindUtilityChart(300);
                });
            }

        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.GetSubjectListforChemical = function (varBrand_ID, varPlant_ID, from_date, to_date, varAction) {
        var promiseSucc = Applicationservice.GetALLPlant_Product_Refind_Dashboard(varBrand_ID, varPlant_ID, from_date, to_date, varAction);
        promiseSucc.then(function (pl) {
            var jsonData = $.parseJSON(pl.data);
            $scope.ChemicalArray = jsonData;
            var scrnHeight1 = ($('.header-top').hasClass('header-top-hide') ? 15 : $('.header-top').height()) + 230 + $('#toppanel').height();
            var scrnHeight = $(window).height();
            if ($scope.isAutoPlay == true) {
                $scope.BindChemicalChartForAuto(((scrnHeight - scrnHeight1 - 80) / 3));
                $(window).resize(function () {
                    $scope.BindChemicalChartForAuto(((scrnHeight - scrnHeight1 - 80) / 3));
                });
            } else {
                $scope.BindChemicalChart(300);
                $(window).resize(function () {
                    $scope.BindChemicalChart(300);
                });
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.BindUtilityChart = function (intheight) {
        var jsonData = $scope.UtilityArray;
        $("#div_uchart").html('');
        $scope.utype = [];
        $scope.pname = [];

        if (jsonData != undefined && jsonData != null && jsonData.length > 0) {
            var obj = $.parseJSON(jsonData);
            if (obj != null && obj != '') {

                var u_table = document.createElement("table");
                u_table.setAttribute("id", "utchart");
                document.getElementById("div_uchart").appendChild(u_table);

                var t_thead = document.createElement("thead");
                t_thead.setAttribute("id", "ut_thead");
                document.getElementById("utchart").appendChild(t_thead);

                var t_tbody = document.createElement("tbody");
                t_tbody.setAttribute("id", "ut_tbody");
                document.getElementById("utchart").appendChild(t_tbody);

                var headtr = document.createElement("tr");
                headtr.setAttribute("id", "headertr");
                document.getElementById("ut_thead").appendChild(headtr);

                var headth = document.createElement("th");
                headth.setAttribute("id", "headerplantth");
                headth.innerHTML = "<span style='position:relative;left:34px;'>Plant</span>";
                document.getElementById("headertr").appendChild(headth);

                var headth1 = document.createElement("th");
                headth1.setAttribute("id", "headerstdtr");
                document.getElementById("headertr").appendChild(headth1);

                for (var i = 0; i < obj.length; i++) {
                    if (jQuery.inArray(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"], $scope.utype) == -1) {
                        $scope.utype.push(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"]);

                        var hdrth = document.createElement("th");
                        var str = obj[i]["Col"].split('~')[0].replace("_", " ");
                        hdrth.innerHTML = str.substr(0, 1).toUpperCase() + str.substr(1).toLowerCase() + " (" + obj[i]["Unit"] + ")";
                        document.getElementById("headertr").appendChild(hdrth);
                    }

                    if (jQuery.inArray(obj[i]["Col"].split('~')[1], $scope.pname) == -1) {
                        $scope.pname.push(obj[i]["Col"].split('~')[1]);
                    }
                }

                for (var jtr = 0; jtr < $scope.pname.length; jtr++) {

                    var datatr = document.createElement("tr");
                    datatr.setAttribute("id", "dtrStd_" + jtr);
                    document.getElementById("ut_tbody").appendChild(datatr);

                    var td = document.createElement("td");
                    td.innerHTML = $scope.pname[jtr];
                    td.setAttribute("class", "valigncenter");
                    document.getElementById("dtrStd_" + jtr).appendChild(td);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Std.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrStd_" + jtr).appendChild(stdth);

                    var datatr_Act = document.createElement("tr");
                    datatr_Act.setAttribute("id", "dtrAct_" + jtr);
                    datatr_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("ut_tbody").appendChild(datatr_Act);

                    var td_Act = document.createElement("td");
                    td_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrAct_" + jtr).appendChild(td_Act);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Act.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrAct_" + jtr).appendChild(stdth);

                    for (var col = 0; col < $scope.utype.length; col++) {
                        var colCheck = $scope.utype[col].split('$^%')[0] + '~' + $scope.pname[jtr];
                        var colUnit = $scope.utype[col].split('$^%')[1];
                        for (var i = 0; i < obj.length; i++) {
                            if (colCheck == obj[i]["Col"] && colUnit == obj[i]["Unit"]) {

                                var td_Std = document.createElement("td");
                                td_Std.setAttribute("id", "unametd" + i);
                                td_Std.setAttribute("style", "background:#4ebfe0;color:white;");
                                td_Std.innerHTML = parseFloat(obj[i]["Std"]).toFixed(2);
                                document.getElementById("dtrStd_" + jtr).appendChild(td_Std);

                                var td_Act = document.createElement("td");
                                td_Act.setAttribute("id", "Act_td" + i);
                                td_Act.innerHTML = parseFloat(obj[i]["Act"]).toFixed(2);

                                if (parseFloat(obj[i]["Act"]) > parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("class", "blink_me");
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else if (parseFloat(obj[i]["Std"]) >= parseFloat(obj[i]["Act"]) && parseFloat(obj[i]["Act"]) > 0 && parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else {
                                    td_Act.setAttribute("style", "background:white;color:black;");
                                }
                                document.getElementById("dtrAct_" + jtr).appendChild(td_Act);
                                break;
                            }
                        }
                    }
                }

                var ar_width = [];
                ar_width.push({ width: 125, align: 'center' });
                ar_width.push({ width: 50, align: 'center' });

                for (var col = 0; col < $scope.utype.length; col++) {
                    ar_width.push({ width: 120, align: 'center' })
                }

                $('#utchart').fxdHdrCol({
                    fixedCols: 2,
                    width: ($('#utchart').parents('div.chart-box').parent('div').width() - 15),
                    height: intheight - 10,
                    colModal: ar_width,
                    sort: false
                });
                if ((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1) {
                    $('#div_uchart').find('.ft_container').height(parseInt($('#zoom3').height()) - 75);
                    $('#zoom3').find('.ft_cwrapper').css("height", parseInt($('#zoom3').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_uchart').find('.ft_container').width();
                        $('#div_uchart').find('.ft_rwrapper').css("width", old_wi - 15);
                    }, 1500);
                }
                else if (navigator.userAgent.indexOf("Chrome") != -1) {
                    $('#div_uchart').find('.ft_container').height(parseInt($('#zoom3').height()) - 75);
                    $('#zoom3').find('.ft_cwrapper').css("height", parseInt($('#zoom3').height()) - 85);
                    setTimeout(function () {
                        var old_wi = $('#div_uchart').find('.ft_container').width();
                        $('#div_uchart').find('.ft_rwrapper').css("width", old_wi - 15);

                    }, 1500);
                }
                else if (navigator.userAgent.indexOf("Safari") != -1) {
                    $('#div_uchart').find('.ft_container').height(parseInt($('#zoom3').height()) - 75);
                    $('#zoom3').find('.ft_cwrapper').css("height", parseInt($('#zoom3').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_uchart').find('.ft_container').width();
                        $('#div_uchart').find('.ft_rwrapper').css("width", old_wi - 15);

                    }, 1500);
                }
                else if (navigator.userAgent.indexOf("Firefox") != -1) {
                    $('#div_uchart').find('.ft_container').height(parseInt($('#zoom3').height()) - 75);
                    $('#zoom3').find('.ft_cwrapper').css("height", parseInt($('#zoom3').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_uchart').find('.ft_container').width();
                        $('#div_uchart').find('.ft_rwrapper').css("width", old_wi - 22);
                    }, 1500);
                }
                else if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document.documentMode == true)) //IF IE > 10
                {
                    $('#div_uchart').find('.ft_container').height(parseInt($('#zoom3').height()) - 75);
                    $('#zoom3').find('.ft_cwrapper').css("height", parseInt($('#zoom3').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_uchart').find('.ft_container').width();
                        $('#div_uchart').find('.ft_rwrapper').css("width", old_wi - 22);
                    }, 1500);
                }
                $('#zoom3').css("display", "block");
            }
            else {
                $('#zoom3').css("display", "none");
            }
        }
        else {
            $('#zoom3').css("display", "none");
        }
    }

    $scope.BindChemicalChart = function (intheight) {
        var jsonData = $scope.ChemicalArray;
        $("#div_cchart").html('');
        $scope.ctype = [];
        $scope.cname = [];

        if (jsonData != undefined && jsonData != null && jsonData.length > 0) {
            var obj = $.parseJSON(jsonData);
            if (obj != undefined && obj != null && obj.length > 0) {

                var c_table = document.createElement("table");
                c_table.setAttribute("id", "ctchart");
                document.getElementById("div_cchart").appendChild(c_table);

                var t_tbody = document.createElement("tbody");
                t_tbody.setAttribute("id", "ct_tbody");
                document.getElementById("ctchart").appendChild(t_tbody);

                var t_thead = document.createElement("thead");
                t_thead.setAttribute("id", "ct_thead");
                document.getElementById("ctchart").appendChild(t_thead);

                var headtr = document.createElement("tr");
                headtr.setAttribute("id", "headerctr");
                document.getElementById("ct_thead").appendChild(headtr);

                var headth = document.createElement("th");
                headth.setAttribute("id", "headerthutility");
                headth.innerHTML = "<span style='position:relative;left:34px;'>Plant</span>";
                document.getElementById("headerctr").appendChild(headth);

                var headth1 = document.createElement("th");
                document.getElementById("headerctr").appendChild(headth1);

                for (var i = 0; i < obj.length; i++) {
                    if (jQuery.inArray(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"], $scope.ctype) == -1) {
                        $scope.ctype.push(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"]);

                        var hdrth = document.createElement("th");
                        var str = obj[i]["Col"].split('~')[0].replace("_", " ");
                        hdrth.innerHTML = str.substr(0, 1).toUpperCase() + str.substr(1).toLowerCase() + " (" + obj[i]["Unit"] + ")";
                        document.getElementById("headerctr").appendChild(hdrth);
                    }

                    if (jQuery.inArray(obj[i]["Col"].split('~')[1], $scope.cname) == -1) {
                        $scope.cname.push(obj[i]["Col"].split('~')[1]);
                    }
                }

                for (var jtr = 0; jtr < $scope.cname.length; jtr++) {

                    var datatr = document.createElement("tr");
                    datatr.setAttribute("id", "dtrcStd_" + jtr);
                    document.getElementById("ct_tbody").appendChild(datatr);

                    var td = document.createElement("td");
                    td.innerHTML = $scope.cname[jtr];
                    td.setAttribute("class", "valigncenter");
                    document.getElementById("dtrcStd_" + jtr).appendChild(td);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Std.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrcStd_" + jtr).appendChild(stdth);

                    var datatr_Act = document.createElement("tr");
                    datatr_Act.setAttribute("id", "dtrcAct_" + jtr);
                    datatr_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("ct_tbody").appendChild(datatr_Act);

                    var td_Act = document.createElement("td");
                    td_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrcAct_" + jtr).appendChild(td_Act);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Act.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrcAct_" + jtr).appendChild(stdth);

                    for (var col = 0; col < $scope.ctype.length; col++) {
                        var colCheck = $scope.ctype[col].split('$^%')[0] + '~' + $scope.cname[jtr];
                        var colUnit = $scope.ctype[col].split('$^%')[1];
                        for (var i = 0; i < obj.length; i++) {
                            if (colCheck == obj[i]["Col"] && colUnit == obj[i]["Unit"]) {

                                var td_Std = document.createElement("td");
                                td_Std.setAttribute("id", "pnametd" + i);
                                td_Std.setAttribute("style", "background:#4ebfe0;color:white;");
                                td_Std.innerHTML = parseFloat(obj[i]["Std"]).toFixed(2);
                                document.getElementById("dtrcStd_" + jtr).appendChild(td_Std);

                                var td_Act = document.createElement("td");
                                td_Act.setAttribute("id", "cAct_td" + i);
                                td_Act.innerHTML = parseFloat(obj[i]["Act"]).toFixed(2);

                                if (parseFloat(obj[i]["Act"]) > parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("class", "blink_me");
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else if (parseFloat(obj[i]["Std"]) >= parseFloat(obj[i]["Act"]) && parseFloat(obj[i]["Act"]) > 0 && parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else {
                                    td_Act.setAttribute("style", "background:white;color:black;");
                                }
                                document.getElementById("dtrcAct_" + jtr).appendChild(td_Act);
                                break;
                            }
                        }
                    }
                }

                var ar_width = [];
                ar_width.push({ width: 125, align: 'center' });
                ar_width.push({ width: 50, align: 'center' });

                for (var col = 0; col < $scope.ctype.length; col++) {
                    ar_width.push({ width: 120, align: 'center' })
                }

                $('#ctchart').fxdHdrCol({
                    fixedCols: 2,
                    width: ($('#ctchart').parents('div.chart-box').parent('div').width() - 13),
                    height: intheight,
                    colModal: ar_width,
                    sort: false
                });
                if ((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1) {
                    $('#div_cchart').find('.ft_container').height(parseInt($('#zoom4').height()) - 75);
                    $('#zoom4').find('.ft_cwrapper').css("height", parseInt($('#zoom4').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_cchart').find('.ft_container').width();
                        $('#div_cchart').find('.ft_rwrapper').css("width", old_wi - 15);
                    }, 1500);
                }
                else if (navigator.userAgent.indexOf("Chrome") != -1) {
                    $('#div_cchart').find('.ft_container').height(parseInt($('#zoom4').height()) - 75);
                    $('#zoom4').find('.ft_cwrapper').css("height", parseInt($('#zoom4').height()) - 85);
                    setTimeout(function () {
                        var old_wi = $('#div_cchart').find('.ft_container').width();
                        $('#div_cchart').find('.ft_rwrapper').css("width", old_wi - 15);
                    }, 1500);
                }
                else if (navigator.userAgent.indexOf("Safari") != -1) {
                    $('#div_cchart').find('.ft_container').height(parseInt($('#zoom4').height()) - 75);
                    $('#zoom4').find('.ft_cwrapper').css("height", parseInt($('#zoom4').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_cchart').find('.ft_container').width();
                        $('#div_cchart').find('.ft_rwrapper').css("width", old_wi - 15);
                    }, 1500);
                }
                else if (navigator.userAgent.indexOf("Firefox") != -1) {
                    $('#div_cchart').find('.ft_container').height(parseInt($('#zoom4').height()) - 75);
                    $('#zoom4').find('.ft_cwrapper').css("height", parseInt($('#zoom4').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_cchart').find('.ft_container').width();
                        $('#div_cchart').find('.ft_rwrapper').css("width", old_wi - 22);
                    }, 1500);
                }
                else if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document.documentMode == true)) //IF IE > 10
                {
                    $('#div_cchart').find('.ft_container').height(parseInt($('#zoom4').height()) - 75);
                    $('#zoom4').find('.ft_cwrapper').css("height", parseInt($('#zoom4').height()) - 87);
                    setTimeout(function () {
                        var old_wi = $('#div_cchart').find('.ft_container').width();
                        $('#div_cchart').find('.ft_rwrapper').css("width", old_wi - 22);
                    }, 1500);
                }
                $('#zoom4').css("display", "block");
            }
            else {
                $('#zoom4').css("display", "none");
            }
        }
        else {
            $('#zoom4').css("display", "none");
        }
    }

    $scope.BindUtilityChartForAuto = function (intheight) {
        var jsonData = $scope.UtilityArray;
        $("#div_uchart1").html('');
        $scope.utype = [];
        $scope.pname = [];
        $('#zoom5').attr("data-hasData", "1");
        if (jsonData != undefined && jsonData != null && jsonData.length > 0) {
            var obj = $.parseJSON(jsonData);
            if (obj != null && obj != '') {

                var u_table = document.createElement("table");
                u_table.setAttribute("id", "utchart1");
                document.getElementById("div_uchart1").appendChild(u_table);

                var t_thead = document.createElement("thead");
                t_thead.setAttribute("id", "ut_thead1");
                document.getElementById("utchart1").appendChild(t_thead);

                var t_tbody = document.createElement("tbody");
                t_tbody.setAttribute("id", "ut_tbody1");
                document.getElementById("utchart1").appendChild(t_tbody);

                var headtr = document.createElement("tr");
                headtr.setAttribute("id", "headertr1");
                document.getElementById("ut_thead1").appendChild(headtr);

                var headth = document.createElement("th");
                headth.setAttribute("id", "headerplantth1");
                headth.innerHTML = "<span style='position:relative;left:34px;'>Plant</span>";
                document.getElementById("headertr1").appendChild(headth);

                var headth1 = document.createElement("th");
                headth1.setAttribute("id", "headerstdtr1");
                document.getElementById("headertr1").appendChild(headth1);

                for (var i = 0; i < obj.length; i++) {
                    if (jQuery.inArray(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"], $scope.utype) == -1) {
                        $scope.utype.push(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"]);

                        var hdrth = document.createElement("th");
                        var str = obj[i]["Col"].split('~')[0].replace("_", " ");
                        hdrth.innerHTML = str.substr(0, 1).toUpperCase() + str.substr(1).toLowerCase() + " (" + obj[i]["Unit"] + ")";
                        document.getElementById("headertr1").appendChild(hdrth);
                    }

                    if (jQuery.inArray(obj[i]["Col"].split('~')[1], $scope.pname) == -1) {
                        $scope.pname.push(obj[i]["Col"].split('~')[1]);
                    }
                }

                for (var jtr = 0; jtr < $scope.pname.length; jtr++) {

                    var datatr = document.createElement("tr");
                    datatr.setAttribute("id", "dtrStd1_" + jtr);
                    document.getElementById("ut_tbody1").appendChild(datatr);

                    var td = document.createElement("td");
                    td.innerHTML = $scope.pname[jtr];
                    td.setAttribute("class", "valigncenter");
                    document.getElementById("dtrStd1_" + jtr).appendChild(td);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Std.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrStd1_" + jtr).appendChild(stdth);

                    var datatr_Act = document.createElement("tr");
                    datatr_Act.setAttribute("id", "dtrAct1_" + jtr);
                    datatr_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("ut_tbody1").appendChild(datatr_Act);

                    var td_Act = document.createElement("td");
                    td_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrAct1_" + jtr).appendChild(td_Act);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Act.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrAct1_" + jtr).appendChild(stdth);

                    for (var col = 0; col < $scope.utype.length; col++) {
                        var colCheck = $scope.utype[col].split('$^%')[0] + '~' + $scope.pname[jtr];
                        var colUnit = $scope.utype[col].split('$^%')[1];
                        for (var i = 0; i < obj.length; i++) {
                            if (colCheck == obj[i]["Col"] && colUnit == obj[i]["Unit"]) {

                                var td_Std = document.createElement("td");
                                td_Std.setAttribute("id", "unametd1" + i);
                                td_Std.setAttribute("style", "background:#4ebfe0;color:white;");
                                td_Std.innerHTML = parseFloat(obj[i]["Std"]).toFixed(2);
                                document.getElementById("dtrStd1_" + jtr).appendChild(td_Std);

                                var td_Act = document.createElement("td");
                                td_Act.setAttribute("id", "Act_td1" + i);
                                td_Act.innerHTML = parseFloat(obj[i]["Act"]).toFixed(2);

                                if (parseFloat(obj[i]["Act"]) > parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("class", "blink_me");
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else if (parseFloat(obj[i]["Std"]) >= parseFloat(obj[i]["Act"]) && parseFloat(obj[i]["Act"]) > 0 && parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else {
                                    td_Act.setAttribute("style", "background:white;color:black;");
                                }
                                document.getElementById("dtrAct1_" + jtr).appendChild(td_Act);
                                break;
                            }
                        }
                    }
                }

                var ar_width = [];
                ar_width.push({ width: 125, align: 'center' });
                ar_width.push({ width: 50, align: 'center' });

                for (var col = 0; col < $scope.utype.length; col++) {
                    ar_width.push({ width: 120, align: 'center' })
                }

                $('#utchart1').fxdHdrCol({
                    fixedCols: 2,
                    width: $('#utchart1').parents('div.chart-box').parent('div').width() - 20,//($(document).width() - 50),
                    height: intheight,
                    colModal: ar_width,
                    sort: false
                });

                setTimeout(function () {
                    var old_wi = $('#div_uchart1').find('.ft_container').width();
                    $('#div_uchart1').find('.ft_rwrapper').css("width", old_wi - 15);
                }, 1500);

                //if ((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1) {
                //    $('#div_uchart1').find('.ft_container').height(parseInt($('#zoom5').height()) - 75);
                //    $('#zoom5').find('.ft_cwrapper').css("height", parseInt($('#zoom5').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_uchart1').find('.ft_container').width();
                //        $('#div_uchart1').find('.ft_rwrapper').css("width", old_wi - 15);
                //    }, 1500);
                //}
                //else if (navigator.userAgent.indexOf("Chrome") != -1) {
                //    $('#div_uchart1').find('.ft_container').height(parseInt($('#zoom5').height()) - 75);
                //    $('#zoom5').find('.ft_cwrapper').css("height", parseInt($('#zoom5').height()) - 85);
                //    setTimeout(function () {
                //        var old_wi = $('#div_uchart1').find('.ft_container').width();
                //        $('#div_uchart1').find('.ft_rwrapper').css("width", old_wi - 15);

                //    }, 1500);
                //}
                //else if (navigator.userAgent.indexOf("Safari") != -1) {
                //    $('#div_uchart1').find('.ft_container').height(parseInt($('#zoom5').height()) - 75);
                //    $('#zoom5').find('.ft_cwrapper').css("height", parseInt($('#zoom5').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_uchart1').find('.ft_container').width();
                //        $('#div_uchart1').find('.ft_rwrapper').css("width", old_wi - 15);

                //    }, 1500);
                //}
                //else if (navigator.userAgent.indexOf("Firefox") != -1) {
                //    $('#div_uchart1').find('.ft_container').height(parseInt($('#zoom5').height()) - 75);
                //    $('#zoom5').find('.ft_cwrapper').css("height", parseInt($('#zoom5').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_uchart1').find('.ft_container').width();
                //        $('#div_uchart1').find('.ft_rwrapper').css("width", old_wi - 22);
                //    }, 1500);
                //}
                //else if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document.documentMode == true)) //IF IE > 10
                //{
                //    $('#div_uchart1').find('.ft_container').height(parseInt($('#zoom5').height()) - 75);
                //    $('#zoom5').find('.ft_cwrapper').css("height", parseInt($('#zoom5').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_uchart1').find('.ft_container').width();
                //        $('#div_uchart1').find('.ft_rwrapper').css("width", old_wi - 22);
                //    }, 1500);
                //}
            }
            else {
                //$('#zoom5').css("display", "none"); 
                $('#zoom5').attr("data-hasData", "0");
            }
        }
        else {
            //$('#zoom5').css("display", "none");
            $('#zoom5').attr("data-hasData", "0");
        }
    }

    $scope.BindChemicalChartForAuto = function (intheight) {
        var jsonData = $scope.ChemicalArray;
        $("#div_cchart1").html('');
        $scope.ctype = [];
        $scope.cname = [];

        $('#zoom6').attr("data-hasData", "1");
        if (jsonData != undefined && jsonData != null && jsonData.length > 0) {
            var obj = $.parseJSON(jsonData);
            if (obj != undefined && obj != null && obj.length > 0) {

                var c_table = document.createElement("table");
                c_table.setAttribute("id", "ctchart1");
                document.getElementById("div_cchart1").appendChild(c_table);

                var t_tbody = document.createElement("tbody");
                t_tbody.setAttribute("id", "ct_tbody1");
                document.getElementById("ctchart1").appendChild(t_tbody);

                var t_thead = document.createElement("thead");
                t_thead.setAttribute("id", "ct_thead1");
                document.getElementById("ctchart1").appendChild(t_thead);

                var headtr = document.createElement("tr");
                headtr.setAttribute("id", "headerctr1");
                document.getElementById("ct_thead1").appendChild(headtr);

                var headth = document.createElement("th");
                headth.setAttribute("id", "headerthutility1");
                headth.innerHTML = "<span style='position:relative;left:34px;'>Plant</span>";
                document.getElementById("headerctr1").appendChild(headth);

                var headth1 = document.createElement("th");
                document.getElementById("headerctr1").appendChild(headth1);

                for (var i = 0; i < obj.length; i++) {
                    if (jQuery.inArray(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"], $scope.ctype) == -1) {
                        $scope.ctype.push(obj[i]["Col"].split('~')[0] + '$^%' + obj[i]["Unit"]);

                        var hdrth = document.createElement("th");
                        var str = obj[i]["Col"].split('~')[0].replace("_", " ");
                        hdrth.innerHTML = str.substr(0, 1).toUpperCase() + str.substr(1).toLowerCase() + " (" + obj[i]["Unit"] + ")";
                        document.getElementById("headerctr1").appendChild(hdrth);
                    }

                    if (jQuery.inArray(obj[i]["Col"].split('~')[1], $scope.cname) == -1) {
                        $scope.cname.push(obj[i]["Col"].split('~')[1]);
                    }
                }

                for (var jtr = 0; jtr < $scope.cname.length; jtr++) {

                    var datatr = document.createElement("tr");
                    datatr.setAttribute("id", "dtrcStd1_" + jtr);
                    document.getElementById("ct_tbody1").appendChild(datatr);

                    var td = document.createElement("td");
                    td.innerHTML = $scope.cname[jtr];
                    td.setAttribute("class", "valigncenter");
                    document.getElementById("dtrcStd1_" + jtr).appendChild(td);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Std.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrcStd1_" + jtr).appendChild(stdth);

                    var datatr_Act = document.createElement("tr");
                    datatr_Act.setAttribute("id", "dtrcAct1_" + jtr);
                    datatr_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("ct_tbody1").appendChild(datatr_Act);

                    var td_Act = document.createElement("td");
                    td_Act.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrcAct1_" + jtr).appendChild(td_Act);

                    var stdth = document.createElement("td");
                    stdth.innerHTML = 'Act.';
                    stdth.setAttribute("style", "background-color:#fff");
                    document.getElementById("dtrcAct1_" + jtr).appendChild(stdth);

                    for (var col = 0; col < $scope.ctype.length; col++) {
                        var colCheck = $scope.ctype[col].split('$^%')[0] + '~' + $scope.cname[jtr];
                        var colUnit = $scope.ctype[col].split('$^%')[1];
                        for (var i = 0; i < obj.length; i++) {
                            if (colCheck == obj[i]["Col"] && colUnit == obj[i]["Unit"]) {

                                var td_Std = document.createElement("td");
                                td_Std.setAttribute("id", "pnametd1" + i);
                                td_Std.setAttribute("style", "background:#4ebfe0;color:white;");
                                td_Std.innerHTML = parseFloat(obj[i]["Std"]).toFixed(2);
                                document.getElementById("dtrcStd1_" + jtr).appendChild(td_Std);

                                var td_Act = document.createElement("td");
                                td_Act.setAttribute("id", "cAct_td1" + i);
                                td_Act.innerHTML = parseFloat(obj[i]["Act"]).toFixed(2);

                                if (parseFloat(obj[i]["Act"]) > parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("class", "blink_me");
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else if (parseFloat(obj[i]["Std"]) >= parseFloat(obj[i]["Act"]) && parseFloat(obj[i]["Act"]) > 0 && parseFloat(obj[i]["Std"])) {
                                    td_Act.setAttribute("style", "background:#63c465;color:white;");
                                }
                                else {
                                    td_Act.setAttribute("style", "background:white;color:black;");
                                }
                                document.getElementById("dtrcAct1_" + jtr).appendChild(td_Act);
                                break;
                            }
                        }
                    }
                }

                var ar_width = [];
                ar_width.push({ width: 125, align: 'center' });
                ar_width.push({ width: 50, align: 'center' });

                for (var col = 0; col < $scope.ctype.length; col++) {
                    ar_width.push({ width: 120, align: 'center' })
                }

                $('#ctchart1').fxdHdrCol({
                    fixedCols: 2,
                    width: $('#ctchart1').parents('div.chart-box').parent('div').width() - 20,//($(document).width() - 100),
                    height: intheight - 10,
                    colModal: ar_width,
                    sort: false
                });
                setTimeout(function () {
                    var old_wi = $('#div_cchart1').find('.ft_container').width();
                    $('#div_cchart1').find('.ft_rwrapper').css("width", old_wi - 15);
                }, 1500);
                //if ((navigator.userAgent.indexOf("Opera") || navigator.userAgent.indexOf('OPR')) != -1) {
                //    $('#div_cchart1').find('.ft_container').height(parseInt($('#zoom6').height()) - 75);
                //    $('#zoom6').find('.ft_cwrapper').css("height", parseInt($('#zoom6').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_cchart1').find('.ft_container').width();
                //        $('#div_cchart1').find('.ft_rwrapper').css("width", old_wi - 15);
                //    }, 1500);
                //}
                //else if (navigator.userAgent.indexOf("Chrome") != -1) {
                //    $('#div_cchart1').find('.ft_container').height(parseInt($('#zoom6').height()) - 75);
                //    $('#zoom6').find('.ft_cwrapper').css("height", parseInt($('#zoom6').height()) - 85);
                //    setTimeout(function () {
                //        var old_wi = $('#div_cchart1').find('.ft_container').width();
                //        $('#div_cchart1').find('.ft_rwrapper').css("width", old_wi - 15);
                //    }, 1500);
                //}
                //else if (navigator.userAgent.indexOf("Safari") != -1) {
                //    $('#div_cchart1').find('.ft_container').height(parseInt($('#zoom6').height()) - 75);
                //    $('#zoom6').find('.ft_cwrapper').css("height", parseInt($('#zoom6').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_cchart1').find('.ft_container').width();
                //        $('#div_cchart1').find('.ft_rwrapper').css("width", old_wi - 15);
                //    }, 1500);
                //}
                //else if (navigator.userAgent.indexOf("Firefox") != -1) {
                //    $('#div_cchart1').find('.ft_container').height(parseInt($('#zoom6').height()) - 75);
                //    $('#zoom6').find('.ft_cwrapper').css("height", parseInt($('#zoom6').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_cchart1').find('.ft_container').width();
                //        $('#div_cchart1').find('.ft_rwrapper').css("width", old_wi - 22);
                //    }, 1500);
                //}
                //else if ((navigator.userAgent.indexOf("MSIE") != -1) || (!!document.documentMode == true)) //IF IE > 10
                //{
                //    $('#div_cchart1').find('.ft_container').height(parseInt($('#zoom6').height()) - 75);
                //    $('#zoom6').find('.ft_cwrapper').css("height", parseInt($('#zoom6').height()) - 87);
                //    setTimeout(function () {
                //        var old_wi = $('#div_cchart1').find('.ft_container').width();
                //        $('#div_cchart1').find('.ft_rwrapper').css("width", old_wi - 22);
                //    }, 1500);
                //}
            }
            else {
                //$('#zoom6').css("display", "none");
                $('#zoom6').attr("data-hasData", "0");
            }
        }
        else {
            //$('#zoom6').css("display", "none");
            $('#zoom6').attr("data-hasData", "0");
        }
    }

    var Dchart = {
        bindDchart: function (chartid, Response, height) {
            $("#" + chartid).dxPieChart({
                type: "doughnut",
                palette: "Harmony Light",
                dataSource: Response,
                resolveLabelOverlapping: "shift",
                onDrawn: function (e) {
                    e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'auto'); });
                },
                size: {
                    height: height,
                },
                margin: {
                    top: 20,
                    bottom: 20
                },
                tooltip: {
                    enabled: false,
                },
                legend: {
                    verticalAlignment: "top",
                    horizontalAlignment: "center",
                    itemTextPosition: "top",
                    visible: false
                },
                series: [{
                    argumentField: 'Brand',
                    valueField: 'TotalQty',
                    label: {
                        visible: true,

                        font: {
                            color: "black",
                            size: 12
                        },

                        backgroundColor: "transparent",

                        connector: {
                            visible: true

                        }, customizeText: function (arg) {
                            return arg.argumentText + " : " + "<span style='font-weight:500'>" + parseFloat(arg.value).toFixed(2) + "</span>" + " (" + arg.percentText + ")";

                        }
                    },
                    hoverStyle: {
                        hatching: {
                            direction: 'left',
                            step: 9,
                            opacity: 0.1,
                            width: 25
                        },
                        border: {
                            visible: true,
                            width: 2,
                            color: "white"
                        }
                    },
                }],
                onPointClick: function (info) {

                    var PlayProduct = localStorage.getItem('PlayProductHO');
                    if (PlayProduct == "0") {
                        var clickedPoint = info.target;
                        clickedPoint.isSelected() ? clickedPoint.clearSelection() : clickedPoint.select();
                        var Type = "";

                        var SelectedSlab = Response.filter(function (entry) {
                            return entry.Brand === info.target.argument
                        })[0];
                        localStorage.setItem("backPlantGlCode", SelectedSlab.PlantGlCode);
                        //debugger
                        //$window.location.assign(AppURL + '/dashboard/PlantLanding?prm=' + $rootScope.EncryptionText("Pnt=" + SelectedSlab.PlantGlCode + "&Prd=''&Primary=N"));
                        ProductID = '';
                        $window.location.assign(AppURL + '/dashboard/plantlanding?prm=' + $rootScope.EncryptionText("Pnt=" + SelectedSlab.PlantGlCode + "&Prd=" + ProductID + "&Primary=N"));

                    }
                }
            }).dxPieChart("instance");
        }
    };
    var Bchart = {
        bindBchart: function (chartid, dataSource1, argumentField, height) {
            $scope.GetMinMax(dataSource1);
            $("#" + chartid).dxChart({
                dataSource: dataSource1,
                margin: {
                    bottom: 10, top: 10
                },
                commonSeriesSettings: {
                    argumentField: argumentField,
                    type: "bar",
                    barWidth: 0.2,
                    rotated: true,
                    label: {
                        rotationAngle: 270,
                        position: 'outside',
                        backgroundColor: 'transparent',
                        alignment: "center",
                        visible: true,
                        font: {
                            size: 11,
                            color: "black"
                        },
                        backgroundColor: "transparent",
                    }
                },
                size: {
                    height: height,
                },
                margin: {
                    top: 10,
                    bottom: 20
                },
                argumentAxis: {
                    visible: true,
                    valueMarginsEnabled: false,
                    discreteAxisDivisionMode: "crossLabels",
                    grid: {
                        visible: false
                    },
                    label: {
                        overlappingBehavior: {
                            mode: 'rotate',
                            rotationAngle: 270
                        },
                        font: { size: 12 },
                        customizeText: function (arg) {
                            return (arg.valueText.length > 10 ? arg.valueText.substr(0, 10) + '..' : arg.valueText);
                        }
                    },
                    tooltip: {
                        enabled: true,
                        font: { size: 12 }
                    }
                },
                valueAxis: {
                    min: (min >= 0 ? 0 : min - 1),
                    max: max + 1,
                    title: {
                        text: "%",
                    },
                    position: "left"
                },
                series: [
                    {
                        valueField: "GrossLossPer",
                        name: "Gross Loss",
                        color: "#5186d0",
                        valueErrorBar: {
                            displayMode: 'auto',
                            edgeLength: 0,
                            lowValueField: "GrossLossPer_Std",
                            highValueField: "GrossLossPer_Std",
                            lineWidth: 8,
                            opacity: 0.8,
                            color: '#ffac06'
                        }
                    },
                    {
                        valueField: "NetLossPer",
                        name: "Dead Loss",
                        color: "#f54040",
                        valueErrorBar: {
                            displayMode: 'auto',
                            edgeLength: 0,
                            lowValueField: "NetLossPer_Std",
                            highValueField: "NetLossPer_Std",
                            lineWidth: 8,
                            opacity: 0.8,
                            color: '#ffac06'
                        }
                    }
                ],
                legend: {
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center",
                    itemTextPosition: "right",
                    visible: true
                },
                tooltip: {
                    enabled: true,
                    customizeTooltip: function (arg) {
                        return {
                            text: arg.seriesName + ": <b>" + arg.value + "</b> ( Standard: <b>" + arg.lowErrorValue + "</b>)"
                        };
                    }
                },
                //tooltip: {
                //    enabled: true,
                //    customizeText: function (e) {
                //        return arg.valueText;
                //    }
                //}
            }).dxChart("instance");
        }
    };
    var Schart = {
        bindSchart: function (chartid, dataSource1, argfield, arr) {

            $("#" + chartid).dxChart({
                dataSource: dataSource1,
                rotated: true,
                size: {
                    height: 300,
                },
                commonSeriesSettings: {
                    argumentField: argfield,
                    type: "fullStackedBar",
                    hoverMode: "none",
                    label: {
                        backgroundColor: "transparent",
                        visible: true,
                        format: {
                            type: "fixedPoint",
                            precision: 2,
                        },
                        fill: "transparent",
                        font: {
                            size: 10,
                            color: "white",
                            weight: 500,
                        },
                    }
                },
                series: arr,
                legend: {
                    verticalAlignment: "top",
                    horizontalAlignment: "center",
                    itemTextPosition: "top",
                    visible: true
                }, onLegendClick: function (e) {
                    var series = e.target;
                    if (series.isVisible()) {
                        series.hide();
                    } else {
                        series.show();
                    }
                },

                tooltip: {
                    enabled: false,
                }
            }).dxChart("instance");




        }

    };
    var min = 0, max = 0;
    $scope.GetMinMax = function (dataSource1) {
        if (dataSource1 != null) {

            for (var i = 0; i < dataSource1.length; i++) {
                var tmp_min = Math.min(parseFloat(dataSource1[i]['GrossLossPer']), parseFloat(dataSource1[i]['NetLossPer']), parseFloat(dataSource1[i]['GrossLossPer_Std']), parseFloat(dataSource1[i]['NetLossPer_Std']));
                var tmp_max = Math.max(parseFloat(dataSource1[i]['GrossLossPer']), parseFloat(dataSource1[i]['NetLossPer']), parseFloat(dataSource1[i]['GrossLossPer_Std']), parseFloat(dataSource1[i]['NetLossPer_Std']));

                if (min > parseFloat(tmp_min)) {
                    min = parseFloat(tmp_min);
                }

                if (max < parseFloat(tmp_max)) {
                    max = parseFloat(tmp_max);
                }
            }
        }
    };
    var colorutility = ['#7abd5c', '#229c9e', '#fcb65e', '#e18e92', '#679ec5', '#b6d623'];
    var colorchemical = ['#fcb65e', '#b6d623', '#e18e92', '#7abd5c', '#c1c1c1', '#229c9e', '#8656e5', '#679ec5'];
    var options = {
        size: {
            height: 30,
            width: 120
        },
        tooltip: {
            enabled: true,
            customizeTooltip: function (arg) {
                return {
                    text: 'Act.: ' + parseFloat(arg.value).toFixed(2) + '<br>' + 'Std.: ' + parseFloat(arg.target).toFixed(2)
                }
            },
        },
    }

    var load = document.getElementById("loadspinner");
    var spin = document.getElementById("loadspin");
    showload = function () {
        load.style.display = "block";
        spin.style.display = "block";
    },

     hideload = function () {
         load.style.display = "none";
         spin.style.display = "none";
     };

    var chrtCounter = 1;
    var chrtPosChangeInterval;
    var hasDataflg = 0;
    $scope.rotateCycle = function () {
        showload();
        var dvMainHtml = '';
        var dvDetailHtml1 = '', dvDetailHtml2 = '', dvDetailHtml3 = '';
        var chart1, chart2, series1, series2, series3, series4, dtlchrtID, dtlchrtID3, dtlchrtID4, cntrltype1, cntrltype2, cntrltype3, cntrltype4;

   
        var mainchrtID = $('#dvMain').find('div.chart-img div').attr('id');
        cntrltype1 = $('#' + mainchrtID).attr('data-charttype');
        if (cntrltype1 == 'pie') {
            chart1 = $('#' + mainchrtID).dxPieChart('instance');
            series1 = chart1.option();
        } else if (cntrltype1 == 'bar') {
            chart1 = $('#' + mainchrtID).dxChart('instance');
            series1 = chart1.option();
        }

        dvMainHtml = $('#dvMain').html();
        dvDetailHtml1 = $('#dvdetail1').html();
        dvDetailHtml2 = $('#dvdetail2').html();
        dvDetailHtml3 = $('#dvdetail3').html();

        dtlchrtID = $('#dvdetail1').find('div.chart-img div').attr('id');
        cntrltype2 = $('#' + dtlchrtID).attr('data-charttype');
        if (cntrltype2 == 'pie') {
            chart2 = $('#' + dtlchrtID).dxPieChart('instance');
            series2 = chart2.option();
        } else if (cntrltype2 == 'bar') {
            chart2 = $('#' + dtlchrtID).dxChart('instance');
            series2 = chart2.option();
        }

        dtlchrtID3 = $('#dvdetail2').find('div.chart-img div').attr('id');
        cntrltype3 = $('#' + dtlchrtID3).attr('data-charttype');
        if (cntrltype3 == 'pie') {
            series3 = $('#' + dtlchrtID3).dxPieChart('instance').option();
        } else if (cntrltype3 == 'bar') {
            series3 = $('#' + dtlchrtID3).dxChart('instance').option();
        } else if (cntrltype3 == 'grid') {
            if (dtlchrtID3 == 'div_uchart1') {
                $scope.BindUtilityChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            } else {
                $scope.BindChemicalChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            }
        }

        dtlchrtID4 = $('#dvdetail3').find('div.chart-img div').attr('id');
        cntrltype4 = $('#' + dtlchrtID4).attr('data-charttype');
        if (cntrltype4 == 'pie') {
            series4 = $('#' + dtlchrtID4).dxPieChart('instance').option();
        } else if (cntrltype4 == 'bar') {
            series4 = $('#' + dtlchrtID4).dxChart('instance').option();
        } else if (cntrltype4 == 'grid') {
            if (dtlchrtID4 == 'div_uchart1') {
                $scope.BindUtilityChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            } else {
                $scope.BindChemicalChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            }
        }

        $('#dvdetail1').html(dvDetailHtml2);
        $('#dvdetail2').html(dvDetailHtml3);
        $('#dvdetail3').html(dvMainHtml);
        $('#dvMain').html(dvDetailHtml1);


        //if (hasDataflg == 1) {
        //    $('#dvdetail1').html(dvDetailHtml3);
        //    $('#dvdetail2').html(dvMainHtml);
        //    $('#dvdetail3').html(dvDetailHtml1);
        //    $('#dvMain').html(dvDetailHtml2);
        //} else {
        //    $('#dvdetail1').html(dvDetailHtml2);
        //    $('#dvdetail2').html(dvDetailHtml3);
        //    $('#dvdetail3').html(dvMainHtml);
        //    $('#dvMain').html(dvDetailHtml1);
        //}

        var scrnHeight1 = ($('.header-top').hasClass('header-top-hide') ? 15 : $('.header-top').height()) + 230 + $('#toppanel').height();
        var scrnHeight = $(window).height();
        console.log(scrnHeight + '           ' + scrnHeight1);
        //if ($('#dvdetail1').find('div.chart-box').attr('data-hasData') != undefined) {
        //    if ($('#dvdetail1').find('div.chart-box').attr('data-hasData') == 0) {
        //        $('#dvdetail1').hide();
        //        $('#dvdetail2').show();
        //        $('#dvdetail3').show();
        //        $('#dvMain').show();
        //        hasDataflg = 1;
        //        chrtCounter++;
        //    } else {
        //        $('#dvdetail1').show();
        //        $('#dvdetail2').hide();
        //        $('#dvdetail3').hide();
        //        $('#dvMain').show();
        //        hasDataflg = 0;
        //    }
        //} else {
        //    $('#dvdetail1').show();
        //    $('#dvdetail2').hide();
        //    $('#dvdetail3').hide();
        //    $('#dvMain').show();
        //    hasDataflg = 0;
        //}

        if (cntrltype3 == 'pie') {
            $("#" + dtlchrtID3).html('');
            series3.size.height = ((scrnHeight - scrnHeight1 - 80) / 3);
            series3.series[0].label.visible = true;
            $("#" + dtlchrtID3).dxPieChart(series3).dxPieChart("instance");
        } else if (cntrltype3 == 'bar') {
            $("#" + dtlchrtID3).html('');
            series3.commonSeriesSettings.label.visible = true;
            series3.size.height = ((scrnHeight - scrnHeight1 - 80) / 3);
            $("#" + dtlchrtID3).dxChart(series3).dxChart("instance");
        } else if (cntrltype3 == 'grid') {
            if (dtlchrtID3 == 'div_uchart1') {
                $scope.BindUtilityChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            } else {
                $scope.BindChemicalChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            }
        }

        if (cntrltype4 == 'pie') {
            $("#" + dtlchrtID4).html('');
            series4.size.height = ((scrnHeight - scrnHeight1 - 80) / 3);
            $("#" + dtlchrtID4).dxPieChart(series4).dxPieChart("instance");
        } else if (cntrltype4 == 'bar') {
            $("#" + dtlchrtID4).html('');
            series4.size.height = ((scrnHeight - scrnHeight1 - 80) / 3);
            $("#" + dtlchrtID4).dxChart(series4).dxChart("instance");
        }

        if (cntrltype1 == 'pie') {
            $("#" + mainchrtID).html('');
            series1.series[0].label.visible = true;
            series1.size.height = ((scrnHeight - scrnHeight1 - 80) / 3);
            $("#" + mainchrtID).dxPieChart(series1).dxPieChart("instance");
        }
        else if (cntrltype1 == 'bar') {
            $("#" + mainchrtID).html('');
            series1.commonSeriesSettings.label.visible = true;
            series1.size.height = ((scrnHeight - scrnHeight1 - 80) / 3);
            $("#" + mainchrtID).dxChart(series1).dxChart("instance");
        } else if (cntrltype1 == 'grid') {
            if (mainchrtID == 'div_uchart1') {
                $scope.BindUtilityChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            } else {
                $scope.BindChemicalChartForAuto(((scrnHeight - scrnHeight1 - 85) / 3));
            }
        }

        if (cntrltype2 == 'pie') {
            $("#" + dtlchrtID).html('');
            series2.size.height = (scrnHeight - scrnHeight1);
            series2.series[0].label.visible = true;
            $("#" + dtlchrtID).dxPieChart(series2).dxPieChart("instance");
        } else if (cntrltype2 == 'bar') {
            $("#" + dtlchrtID).html('');
            series2.size.height = (scrnHeight - scrnHeight1);
            series2.commonSeriesSettings.label.visible = true;
            $("#" + dtlchrtID).dxChart(series2).dxChart("instance");
        } else if (cntrltype2 == 'grid') {
            if (dtlchrtID == 'div_uchart1') {
                $scope.BindUtilityChartForAuto((scrnHeight - scrnHeight1 - 20));
            } else {
                $scope.BindChemicalChartForAuto((scrnHeight - scrnHeight1 - 20));
            }
        }
        chrtCounter++;

        if ($('#dvMain').find('div.chart-box').attr('data-hasData') != undefined) {
            if ($('#dvMain').find('div.chart-box').attr('data-hasData') == 0) {
                if (chrtCounter == 5) {
                    chrtCounter = 1;
                    clearInterval(chrtPosChangeInterval);
                    GetProductAutoList(false);
                    hideload();
                    return;
                }
                $scope.rotateCycle();
            }
        }
        if (chrtCounter == 5) {
            chrtCounter = 1;
            clearInterval(chrtPosChangeInterval);
            GetProductAutoList(false);
        }
        hideload();
    };

    $scope.autoRorate = function () {
        clearInterval(chrtPosChangeInterval);
    };

    $rootScope.OnAutoScrollProductClick = function () { };

    $(document).delegate('.fa-play', 'click', function () {
        $scope.isAutoPlay = true;
        $('#toppanel').css('pointer-events', 'none');
        //$('.bx-next').css('pointer-events', 'none');
        //$('.bx-prev').css('pointer-events', 'none');

        $('.header-top').css('pointer-events', 'none');
        $('.show-menu').addClass("displ");
        $(this).css('pointer-events', 'auto');
        element = document.getElementById('dvMainOuter');

        if (element.requestFullScreen) {
            element.requestFullScreen();
        } else if (element.msRequestFullscreen) {
            element.msRequestFullscreen();
        } else if (element.mozRequestFullScreen) {
            element.mozRequestFullScreen();
        } else if (element.webkitRequestFullScreen) {
            element.webkitRequestFullScreen();
        }

        setTimeout(function () {
            localStorage.setItem('PlayProductHO', 1);
            $('#fa_play').removeClass('fa-play');
            $('#fa_play').addClass('fa-pause');
            angular.element('#wrapper').scope().mBrcmnProductDisable = true;
            angular.element('#wrapper').scope().mBrcmnCycleDisable = true;
            GetProductAutoList(true);
            $('.show-menu').hide();
        }, 100);
    });

    $(document).delegate('.fa-pause', 'click', function () {
        $('.header-top').css('pointer-events', 'auto');
        $('#toppanel').css('pointer-events', 'auto');
        $('.show-menu').removeClass("displ");
        $('.show-menu').show();
        $scope.isAutoPlay = false;
        localStorage.setItem('PlayProductHO', 0);
        elem = document.getElementById('dvMainOuter');
        if (document.cancelFullScreen) {
            document.cancelFullScreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        } else if (document.webkitCancelFullScreen) {
            document.webkitCancelFullScreen();
        } else if (document.msExitFullscreen) {
            document.msExitFullscreen();
        }

        setTimeout(function () {
            $('#fa_play').removeClass('fa-pause');
            $('#fa_play').addClass('fa-play');
            angular.element('#wrapper').scope().mBrcmnProductDisable = false;
            angular.element('#wrapper').scope().mBrcmnCycleDisable = false;
            clearInterval(chrtPosChangeInterval);
            $scope.initLoadData();
        }, 100);
    });

    //function toggleFullScreen(flg) {
    //    elem = document.getElementById('wrapper');

    //    if (flg == true && ((document.fullScreenElement !== undefined && document.fullScreenElement === null) || (document.msFullscreenElement !== undefined && document.msFullscreenElement === null) || (document.mozFullScreen !== undefined && !document.mozFullScreen) || (document.webkitIsFullScreen !== undefined && !document.webkitIsFullScreen))) {
    //        if (elem.requestFullScreen) {
    //            elem.requestFullScreen();
    //        } else if (elem.mozRequestFullScreen) {
    //            elem.mozRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
    //        } else if (elem.webkitRequestFullScreen) {
    //            elem.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);
    //        } else if (elem.msRequestFullscreen) {
    //            elem.msRequestFullscreen();
    //        }
    //    } else {
    //        if (document.cancelFullScreen) {
    //            document.cancelFullScreen();
    //        } else if (document.mozCancelFullScreen) {
    //            document.mozCancelFullScreen();
    //        } else if (document.webkitCancelFullScreen) {
    //            document.webkitCancelFullScreen();
    //        } else if (document.msExitFullscreen) {
    //            document.msExitFullscreen();
    //        }
    //    }
    //}

    function GetProductAutoList(chngFlg) {
        if ($rootScope.AutoPlayBrandList.length > 0) {
            var PlayProduct = localStorage.getItem('PlayProductHO');
            if (PlayProduct == "1") {
                var LastProductStore = localStorage.getItem('lastProductPlayHO');

                var CurrentProduct = (LastProductStore != undefined && LastProductStore != null && LastProductStore != "" && LastProductStore != "null") ? parseInt(LastProductStore) : 0;

                if (CurrentProduct > 0 && CurrentProduct == $rootScope.AutoPlayBrandList.length) {
                    CurrentProduct = 0;
                }

                if (CurrentProduct > 0 && chngFlg == true) {
                    CurrentProduct--;
                }

                $scope.varBrand_ID = $rootScope.AutoPlayBrandList[CurrentProduct].intBrandId;

                angular.element('#wrapper').scope().mBrcmnProduct = $scope.varBrand_ID;
                $('.breadcrumbs-menu ul').attr('style', 'opacity: 0;');

                if ($scope.varBrand_ID != undefined || $scope.varBrand_ID != '') {
                    $('#brand_' + $scope.varBrand_ID).prop('checked', true);
                    $('#liBrcmnProduct').text($('#brand_' + $scope.varBrand_ID).siblings('p').html());
                }

                if ($scope.varBrand_ID != undefined && $scope.varBrand_ID != null && $scope.varBrand_ID != "") {
                    localStorage.setItem("backBrandGlCode", $scope.varBrand_ID);
                }

                $('.breadcrumbs-menu ul').attr('style', 'opacity: 1; transition: opacity 500ms linear;');
                $scope.USP_Get_Yearly_QuarterNo('load');
                CurrentProduct = parseInt(CurrentProduct) + 1;
                localStorage.setItem('lastProductPlayHO', CurrentProduct);
            }
        }
    }

    $scope.Export_xl = function (flg) {
        var strHtml = '<table><thead><tr style="background-color:#1d83ec;color:#ffffff">';
        if (flg == 'Utilities') {
            $('.ft_scroller').find('table#utchart #ut_thead tr th').each(function () {
                strHtml += '<th style="background-color:#229C9E;background:#229C9E;text-align:center;"><b>' + $(this).text() + '</b></th>';
            });
            strHtml += '</tr></thead><tbody>';

            $('.ft_scroller').find('table#utchart #ut_tbody tr').each(function () {
                strHtml += '<tr>';
                $(this).find('td').each(function () {
                    strHtml += '<td>' + $(this).text() + '</td>';
                });
                strHtml += '</tr>';
            });
        } else if (flg == 'Chemical') {
            $('.ft_scroller').find('table#ctchart #ct_thead tr th').each(function () {
                strHtml += '<th style="background:#63c465;text-align:center;"><b>' + $(this).text() + '</b></th>';
            });
            strHtml += '</tr></thead><tbody>';

            $('.ft_scroller').find('table#ctchart #ct_tbody tr').each(function () {
                strHtml += '<tr>';
                $(this).find('td').each(function () {
                    strHtml += '<td>' + $(this).text() + '</td>';
                });
                strHtml += '</tr>';
            });
        } else {
            return;
        }
        strHtml += '</tbody><table>';

        var filename = flg + '_' + $('#liBrcmnProduct').html() + "_" + $('#liBrcmnCycle').html() + ".xls";
        var contentType = 'data:application/vnd.ms-excel';

        try {
            var blob = new Blob(['<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>Sheet1</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--> ' +
                '<style type="text/css">td{border: 1px solid #ddd !important;background-color: #fff !important;color: #000 !important;} </style> </head>' +
                '<body style="background-color: #ffffff;"><table><tr><td>' + strHtml + '</td></tr></table></body></html>'], { type: contentType });
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blob, filename);
            } else {
                var linkElement = document.createElement('a');
                var url = window.URL.createObjectURL(blob);
                linkElement.setAttribute('href', url);
                linkElement.setAttribute("download", filename);
                var clickEvent = new MouseEvent("click", {
                    "view": window,
                    "bubbles": true,
                    "cancelable": false
                });
                linkElement.dispatchEvent(clickEvent);
            }
        } catch (ex) {
            console.log(ex);
        }
    }

    $scope.GenerateScrollableGrid = function (intheight, id) {
        var ar_width = [], obj = 0;
        ar_width.push({ width: 125, align: 'center' });
        ar_width.push({ width: 50, align: 'center' });
        if (id == 'utchart') {
            obj = $scope.utype.length;
        } else {
            obj = $scope.ctype.length
        }
        for (var col = 0; col < obj; col++) {
            ar_width.push({ width: 120, align: 'center' })
        }

        $("#fullChrt").find('#' + id).fxdHdrCol({
            fixedCols: 2,
            width: ($("#fullChrt").find('#' + id).parents('div.chart-box').parent('div').width() - 15),
            height: intheight - 10,
            colModal: ar_width,
            sort: false
        });
    };

}]);
﻿app.controller('Plant_DetailsController', ['$scope', 'Applicationservice', '$rootScope', '$window', '$filter', '$timeout', '$location', 'AppURL', function ($scope, Applicationservice, $rootScope, $window, $filter, $timeout, $location, AppURL) {
    $scope.QuarterTamplateList = [];
    $scope.MaterialTable = [];
    $scope.QualityParameter = [];

    var personglcode = localStorage.getItem('personglcode');
    $scope.vType = 'UQ';
    $scope.cType = "CPM";
    $scope.dType = 'CQ';
    $scope.fk_PlantGlCode = 0;
    $scope.fk_BrandGlCode = 0;

    $scope.Standard = "Standard";
    $scope.Actual = "Actual";
    $scope.Standardvalue = "Standard QTY.";
    $scope.Actualvalue = "Actual QTY."
    $scope.isExt = false;
    $scope.fileronChange = function (plantID, ProductID) {
        $window.location.assign(AppURL + '/dashboard/plant_details?prm=' + $rootScope.EncryptionText("Pnt=" + plantID + "&Prd=" + ProductID));
    };

    //$scope.RedirectToRefinary = function (id) {
    //    if (!$scope.isExt) {
    //        var divId = $('#hdn' + id).val();
    //        $window.location.assign(AppURL + '/dashboard/RefinaryWiseSteamConsumption?prm=' + $rootScope.EncryptionText('Pnt=' + $scope.fk_PlantGlCode + '&Prd=' + $scope.fk_BrandGlCode + '&product_id=' + divId));
    //    }
    //};

    $scope.initLoadData = function () {
        $rootScope.mvisibleBack = true;
        $rootScope.mvisibleDateCycle = true;
        $rootScope.mvisibleHoreport = false;
        $rootScope.topHeading = 'Refined: Refined Details';
        var FID = localStorage.getItem("FID");
        $rootScope.insertformvisit($rootScope.topHeading, FID);
        var url_main = $window.location.pathname.toLowerCase();
        if (url_main.search('dashboard/plant_details') != -1) {
            var url = $window.location.search;
            if (url.split('?').length > 1) {

                var Decrp = $rootScope.DecryptionText(url.split('?prm=')[1]);
                if (Decrp != null && Decrp != '') {
                    $scope.fk_PlantGlCode = (Decrp.split('&')[0].split('=')[1]);
                    $scope.fk_BrandGlCode = (Decrp.split('&')[1].split('=')[1]);

                    angular.element('#wrapper').scope().mBrcmnProduct = $scope.fk_BrandGlCode;
                    angular.element('#wrapper').scope().mBrcmnPlant = $scope.fk_PlantGlCode;
                    $('.breadcrumbs-menu ul').attr('style', 'opacity: 0;');
                    setTimeout(function () {
                        $('#plant_' + $scope.fk_PlantGlCode).prop('checked', true);
                        $('#liBrcmnPlant').text($('#plant_' + $scope.fk_PlantGlCode).siblings('p').html());

                        if ($scope.fk_BrandGlCode == undefined || $scope.fk_BrandGlCode == '') {
                            $scope.fk_BrandGlCode = $('ul#BrandList').find('li label input:checked').parents('label').attr('data-id');
                        }
                        else {
                            $('#brand_' + $scope.fk_BrandGlCode).prop('checked', true);
                            $('#liBrcmnProduct').text($('#brand_' + $scope.fk_BrandGlCode).siblings('p').html());
                        }

                        localStorage.setItem("backPlantGlCode", $scope.fk_PlantGlCode);
                        if ($scope.fk_BrandGlCode != undefined && $scope.fk_BrandGlCode != null && $scope.fk_BrandGlCode != "") {
                            localStorage.setItem("backBrandGlCode", $scope.fk_BrandGlCode);
                        }

                        $('.breadcrumbs-menu ul').attr('style', 'opacity: 1; transition: opacity 500ms linear;');
                        $scope.USP_Get_Yearly_QuarterNo('load');
                    }, 1500);
                }
            }
            else {
                setTimeout(function () {
                    $scope.fk_PlantGlCode = $('ul#plantList').find('li input:checked').parents('li').attr('data-id');
                    $scope.fk_BrandGlCode = $('ul#BrandList').find('li label input:checked').parents('label').attr('data-id');
                    localStorage.setItem("backPlantGlCode", $scope.fk_PlantGlCode);
                    localStorage.setItem("backBrandGlCode", $scope.fk_BrandGlCode);
                    $scope.USP_Get_Yearly_QuarterNo('load');
                }, 1500);
            }
        }
    };


    $scope.onclickLoad = function (action) {
        $('.cyclePanl').attr('class', 'box mtd highlightpnl');
        $('#' + action).attr("class", "box mtd highlightpnl cyclePanl");
        localStorage.setItem('varCycle', $('.cyclePanl').attr('id'));
        angular.element('#wrapper').scope().mBrcmnCycleName = action.toUpperCase();
        var cycle = $rootScope.GetMonthDetails(action);
        $('#liBrcmnCycle').text(cycle);
        $scope.USP_Get_Yearly_QuarterNo('click');
    };

    $rootScope.OnBackClick = function () {
        var PlantGlcode = localStorage.getItem("backPlantGlCode");
        var BrandGlcode = localStorage.getItem("backBrandGlCode");
        $window.location.assign(AppURL + '/dashboard/PlantLanding?prm=' + $rootScope.EncryptionText("Pnt=" + PlantGlcode + "&Prd="));
    }

    $scope.USP_Get_Yearly_QuarterNo = function (action) {
        //var highlightCycle = $('.cyclePanl').attr('id');
        //highlightCycle = (highlightCycle == 'yesterday' ? 'mtd' : highlightCycle);
        var highlightCycle = localStorage.getItem('varCycle');
        $('.cyclePanl').attr('class', 'box mtd highlightpnl');
        $('#' + highlightCycle).attr("class", "box mtd highlightpnl cyclePanl");

        jQuery.map($rootScope.DisableProductionList, function (obj) {
            if (parseInt(obj) === parseInt($scope.fk_BrandGlCode)) {
                $scope.isExt = true;
            }
        });

        var promiseSucc = Applicationservice.Get_Date_Range(highlightCycle);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {

                $scope.QuarterTamplateList = pl.data;
                var from_date = $scope.QuarterTamplateList[0]['dtFromDate'];
                var to_date = $scope.QuarterTamplateList[0]['dtToDate'];
                var QtyType = 'M';
                var Type = 'Q';

                if (action == 'load') {
                    $('#yesterday').html('');
                    $('#mtd').html('');
                    $('#qtd').html('');
                    $('#ytd').html('');

                    $scope.Get_Refined_Dashboard(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'Yesterday');

                    from_date = $scope.QuarterTamplateList[1]['dtFromDate'];
                    to_date = $scope.QuarterTamplateList[1]['dtToDate'];
                    $scope.Get_Refined_Dashboard(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'MTD');

                    from_date = $scope.QuarterTamplateList[2]['dtFromDate'];
                    to_date = $scope.QuarterTamplateList[2]['dtToDate'];
                    $scope.Get_Refined_Dashboard(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'QTD');

                    from_date = $scope.QuarterTamplateList[3]['dtFromDate'];
                    to_date = $scope.QuarterTamplateList[3]['dtToDate'];
                    $scope.Get_Refined_Dashboard(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'YTD');
                }
                from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                to_date = $scope.QuarterTamplateList[4]['dtToDate'];
                $scope.Bind_Refined_Production_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'GetProduction');
                $scope.Bind_Refined_MaterialBal_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'GetMaterialBalance');
                $scope.Bind_Refined_QualityPrm_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'GetQualityParameter');
                $scope.Bind_Refined_ByProduct_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, QtyType, Type, 'GetBYProducts');

                $scope.Bind_Refined_Utility_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, Type, 'GetUtility');
                $scope.Bind_Refined_Chemical_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, Type, 'GetChemical');
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.Get_Refined_Dashboard = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, QtyType, Type, varAction) {
        var promiseSucc = Applicationservice.Get_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, QtyType, Type, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != '' && pl.data != null) {
                var obj = $.parseJSON(pl.data)['Table'];
                var d = new Date();
                var last_year = parseInt(d.getFullYear()) - 1;

                var html = '';
                var ChrColor = obj[0]['ChrColor'];
                html += '<div class="box-left">';
                html += '<h5>' + varAction + '</h5>';
                html += '<h4></h4>';
                html += '<h1>' + addCommas(obj[0]['Current_TotalQty']) + '<small style="font-size: 40%;">MT</small></h1>';
                html += '</div>';
                html += '<div class="box-right">';
                html += '<div class="box-lastyrTag">vs ' + last_year + '</div>';
                html += '<div class="box-right-arrow">';
                html += '<i class="fa ' + (ChrColor == 'Red' ? 'fa-arrow-down' : 'fa-arrow-up') + ' darrow" style="color:' + (ChrColor == 'Red' ? '#fff' : '#fff') + ';"></i>';
                html += '</div>';
                html += '<h3 style="color:' + (ChrColor == 'Red' ? '#fff' : '#fff') + ';">' + obj[0]['YOYPer'] + '%</h3>';
                html += '</div>';
                //html += '<div class="box-img">';
                //html += '<div class="circleBase type1">';
                //if (ChrColor == 'Red') {
                //    html += '<i class="fa fa-arrow-down darrow" style="color:red"></i>';
                //}
                //else {
                //    html += '<i class="fa fa-arrow-up darrow" style="color:green"></i>';
                //}
                //html += '</div>';
                //html += '<label>' + obj[0]['YOYPer'] + ' %</label>';
                //html += '</div>';
                //html += '<div class="box-text">';
                //html += '<h3>' + varAction + '</h3>';
                //html += '<h4>VS ' + last_year + '</h4>';
                //html += '<h2>' + addCommas(obj[0]['Current_TotalQty']) + '<small>MT</small></h2>';
                //html += '</div>';

                if (varAction == 'Yesterday') {
                    $('#yesterday').html(html);
                }
                else if (varAction == 'MTD') {
                    $('#mtd').html(html);
                }
                else if (varAction == 'QTD') {
                    $('#qtd').html(html);
                }
                else if (varAction == 'YTD') {
                    $('#ytd').html(html);
                }
            }
        });
    }

    $scope.Bind_Refined_Production_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, QtyType, Type, varAction) {
       //debugger
        var promiseSucc = Applicationservice.Get_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, QtyType, Type, varAction);
        promiseSucc.then(function (pl) {
           //debugger
            if (pl.data != '' && pl.data != null) {
                var obj = $.parseJSON(pl.data)['Table'];
                $("#chartid1").dxChart({
                    dataSource: obj,
                    barWidth: 0.5,
                    palette: ['#4ebfe0', '#feb21b'],
                    margin: {
                        bottom: 10, top: 10
                    },
                    onDrawn: function (e) {
                        if ($scope.isExt) {
                            e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'default'); }, function () { $(this).css('cursor', 'default'); });
                        }
                        else {
                            e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'auto'); });
                        }
                    },
                    commonSeriesSettings: {
                        type: "bar",
                        argumentField: "Action",
                        valueField: "Quantity",
                        rotated: true,
                        label: {
                            font: { color: "black" },
                            backgroundColor: "transparent",
                            visible: true,
                            //format: {
                            //    type: "fixedPoint"
                            //}
                            overlappingBehavior: {
                                rotated: true,
                                mode: 'rotate',
                                rotationAngle: 315,
                            }
                        }
                    },
                    onPointClick: function (info) {
                        if (!$scope.isExt) {

                          
                            $window.location.assign(AppURL + '/dashboard/Refinery_wise_Std?prm=' + $rootScope.EncryptionText("Pnt=" + $scope.fk_PlantGlCode + "&Prd=" + $scope.fk_BrandGlCode));
                        }
                    },
                    equalBarWidth: false,
                    seriesTemplate: {
                        nameField: "Action"
                    },
                    size: {
                        height: 265
                    },
                    legend: {
                        verticalAlignment: "top",
                        horizontalAlignment: "center",
                        itemTextPosition: "top",
                        visible: false
                    },
                    tooltip: {
                        enabled: false
                    }
                }).dxChart("instance");
            }
        });
    }

    $scope.Bind_Refined_MaterialBal_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, QtyType, Type, varAction) {
        var promiseSucc = Applicationservice.Get_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, QtyType, Type, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != '' && pl.data != null) {
                var obj = $.parseJSON(pl.data)['Table'];
                $("#chartid2").dxChart({
                    dataSource: obj,
                    barWidth: 0.5,
                    palette: (obj.length == 5 ? ['#5186d0', '#88b0e8', '#feb21b', '#63c465', '#f54040'] : ['#5186d0', '#feb21b', '#63c465', '#f54040']),
                    margin: {
                        bottom: 10, top: 10
                    },
                    commonSeriesSettings: {
                        type: "rangebar",
                        rangeValue1Field: "Standard_Value",
                        rangeValue2Field: "value",
                        argumentField: "varType",
                        label: {
                            visible: true,
                            format: 'percent',
                            font: { color: "black" },
                            backgroundColor: "transparent",
                            precision: 2,
                            rotated: true,
                            customizeText: function (arg) {
                                var text = "";
                                if (arg.index === 1) {
                                    text = (arg.point.originalValue - arg.point.originalMinValue).toFixed(2);
                                }
                                return text;
                            },
                            overlappingBehavior: {
                                rotated: true,
                                mode: 'rotate',
                                rotationAngle: 315,
                            }
                        },

                    },

                    equalBarWidth: false,
                    seriesTemplate: {
                        nameField: "varType"
                    },
                    size: {
                        height: 265
                    },
                    legend: {
                        verticalAlignment: "top",
                        horizontalAlignment: "center",
                        itemTextPosition: "top",
                        visible: false
                    },
                }).dxChart("instance");

                $scope.MaterialTable = $.parseJSON(pl.data)['Table1'];
            }
        });
    }

    $scope.Bind_Refined_QualityPrm_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, QtyType, Type, varAction) {
        var promiseSucc = Applicationservice.Get_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, QtyType, Type, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != '' && pl.data != null) {
                var obj = $.parseJSON(pl.data)['Table'];
                $scope.QualityParameter = $.parseJSON(pl.data)['Table'];
            }
        });
    }

    $scope.Bind_Refined_ByProduct_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, QtyType, Type, varAction) {
        var promiseSucc = Applicationservice.Get_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, QtyType, Type, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != '' && pl.data != null) {
                var obj = $.parseJSON(pl.data)['Table'];
                $("#chartid3").dxChart({
                    dataSource: obj,
                    barWidth: 0.6,
                    margin: {
                        bottom: 30
                    },

                    rotated: true,
                    size:
                    {
                        height: 250
                    },
                    //barWidth:10,
                    commonSeriesSettings: {
                        argumentField: 'Product_Name',
                        type: "bar",
                        label: {
                            font: { color: "black" },
                            backgroundColor: "transparent",
                            visible: true
                        }
                    },
                    //customizeLabel: function () {
                    //    if (this.value <= 0) {
                    //        return {
                    //            visible: false,
                    //        };
                    //    }
                    //},
                    series: [
                        { valueField: "Actual_Qty", name: "Actual", color: "#feb21b" },
                        { valueField: "Standard_Qty", name: "Standard", color: "#4ebfe0" }
                    ], argumentAxis: {
                        valueMarginsEnabled: false
                    },
                    tooltip: {
                        enabled: false
                    },
                    legend: {
                        verticalAlignment: "bottom",
                        horizontalAlignment: "center",
                        itemTextPosition: "right",
                        visible: true
                    },
                }).dxChart("instance");
            }
        });
    }

    $scope.Bind_Refined_Utility_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, Type, varAction) {
        var QtyType = 'M';
        var Type = '';
        if ($scope.vType == 'UR') {
            Type = 'R';
        }
        else {
            Type = 'Q';
        }
        var promiseSucc = Applicationservice.Get_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, QtyType, Type, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null) {
                var obj = $.parseJSON(pl.data)['Table'];
                if (obj != '' && obj != null && obj.length > 0) { 
                    $('#demo').css("display", "block");
                    var divId = '';
                    var uldiv = document.getElementById("ulutchart");
                    // uldiv.setAttribute("id", "ulutchart");
                    $(".clsdonutChart").html('');
                    var rcnt = 0;
                    var ar_tmp = [];
                    for (var i = 0; i < obj.length; i++) {
                        if (rcnt < 2) {
                            ar_tmp.push({ 'id': obj[i]["ID"], 'Product_Name': obj[i]["ProductName"], 'intProductID': obj[i]["intProductID"], 'UOM': obj[i]["UOM"], 'Actual_Qty': parseFloat(obj[i]["Actual_Qty"]).toFixed(2), 'Standard_Qty': parseFloat(obj[i]["Standard_Qty"]).toFixed(2) });
                            rcnt += 1;
                        } else {
                            ar_tmp.push({ 'id': obj[i]["ID"], 'Product_Name': obj[i]["ProductName"], 'intProductID': obj[i]["intProductID"], 'UOM': obj[i]["UOM"], 'Actual_Qty': parseFloat(obj[i]["Actual_Qty"]).toFixed(2), 'Standard_Qty': parseFloat(obj[i]["Standard_Qty"]).toFixed(2) });

                            var dynDiv1 = document.createElement("li");
                            dynDiv1.setAttribute("id", "liutchart" + i);
                            dynDiv1.setAttribute("style", "display:inline");
                            var dynDiv = document.createElement("div");
                            dynDiv.setAttribute("id", "chartutlty" + i);
                            dynDiv.setAttribute("class", "utility_chart");

                            dynDiv.setAttribute("data-charttype", "gauge");
                            dynDiv.setAttribute("data-chrtheight", "180");
                            //dynDiv.setAttribute("onclick", "angular.element(this).scope().RedirectToRefinary('chartutlty" + i + "')");

                            if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
                                if (i > 6) {
                                    uldiv.setAttribute("class", "bxslider1");
                                }
                                $scope.SLiderMargin = 0;
                            }
                            else {
                                if (i > 12) {
                                    uldiv.setAttribute("class", "bxslider1");
                                }
                                $scope.SLiderMargin = 70;
                            }
                            document.getElementById('ulutchart').appendChild(dynDiv1);
                            document.getElementById("liutchart" + i).appendChild(dynDiv);

                            options.bindchrt("chartutlty" + i, ar_tmp, obj[i]["intProductID"], (obj[i]["ProductName"] + " [" + obj[i]["UOM"] + "]"), "clsdonutChart");

                            //var newstring = ucwords(str)
                            //options.bindguage("chartutlty" + i, '#4d4d4d', obj[i]["Standard_Qty"],
                            //    obj[i]["Actual_Qty"], obj[i]["Max_Qty"], obj[i]["intProductId"],
                            //    (obj[i]["Product_Name"] + " [" + obj[i]["UOM"] + "]"));
                            ar_tmp = [];
                            rcnt = 0;
                            //document.getElementById('chartutlty' + i).style.cursor = "pointer";
                        }
                    };
                    $('.bxslider1').bxSlider({
                        mode: 'horizontal',
                        moveSlides: 1,
                        slideMargin: $scope.SLiderMargin,
                        infiniteLoop: false,
                        slideWidth: 250,
                        minSlides: ($(window).width() <= 1024 && $(window).width() > 576 ? 3 : ($(window).width() < 576 ? 2 : 4)),
                        maxSlides: ($(window).width() <= 1024 && $(window).width() > 576 ? 3 : ($(window).width() < 576 ? 2 : 4)),
                        speed: 500,
                    });


                    if (obj.length <= 4) {
                        $('#bxwrapperid').find('.bx-has-pager').css("display", "none");
                    }
                    else {
                        $('#bxwrapperid').find('.bx-has-pager').css("display", "block");
                    }
                    $('#zoom6').css("display", "block");
                }
                else {
                    var uldiv = document.getElementById("ulutchart");
                    uldiv.innerHTML = '';
                    //$('#zoom6').css("display", "none"); 
                    $('#demo').css("display", "none");
                    $('.quality-parameters-section').css("margin-bottom", "10px");
                }
            }
        });
    }

    $scope.Bind_Refined_Chemical_chart = function (dtFrom, dtTo, fk_BrandGlCode, fk_PlantGlCode, Type, varAction) {

        var QtyType = 'M';
        var Type = '';

        if ($scope.dType == 'CR') {
            Type = 'R';
        }
        else {
            Type = 'Q';
        }
        var promiseSucc = Applicationservice.Get_Refined_Dashboard(fk_BrandGlCode, fk_PlantGlCode, dtFrom, dtTo, QtyType, Type, varAction);
        promiseSucc.then(function (pl) {
            if (pl.data != null) {
                var obj = $.parseJSON(pl.data)['Table'];
                if (obj != '' && obj != null && obj.length > 0) {
                    var divId = ''; 
                    $('#demoChemical').css("display", "block");
                    var uldiv = document.getElementById('ulchart');
                    $(".clschemdonutChart").html('');
                    var rcnt = 0;
                    var ar_tmp = [];
                    for (var i = 0; i < obj.length; i++) {

                        if (rcnt < 2) {
                            ar_tmp.push({ 'id': obj[i]["ID"], 'Product_Name': obj[i]["ProductName"], 'intProductID': obj[i]["intProductID"], 'UOM': obj[i]["UOM"], 'Actual_Qty': parseFloat(obj[i]["Actual_Qty"]).toFixed(2), 'Standard_Qty': parseFloat(obj[i]["Standard_Qty"]).toFixed(2) });
                            rcnt += 1;
                        } else {
                            ar_tmp.push({ 'id': obj[i]["ID"], 'Product_Name': obj[i]["ProductName"], 'intProductID': obj[i]["intProductID"], 'UOM': obj[i]["UOM"], 'Actual_Qty': parseFloat(obj[i]["Actual_Qty"]).toFixed(2), 'Standard_Qty': parseFloat(obj[i]["Standard_Qty"]).toFixed(2) });
                            var dynDiv1 = document.createElement("li");
                            dynDiv1.setAttribute("id", "lichart" + i);
                            dynDiv1.setAttribute("style", "display:inline");
                            var dynDiv = document.createElement("div");
                            dynDiv.setAttribute("id", "chartchemical" + i);
                            dynDiv.setAttribute("class", "utility_chart");
                            dynDiv.setAttribute("data-charttype", "gauge");
                            dynDiv.setAttribute("data-chrtheight", "180");
                            //dynDiv.setAttribute("onclick", "angular.element(this).scope().RedirectToRefinary('chartchemical" + i + "')");

                            if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
                                if (i > 6) {
                                    uldiv.setAttribute("class", "bxslider");
                                }
                                $scope.SLiderMargin = 0;
                            }
                            else {
                                if (i > 12) {
                                    uldiv.setAttribute("class", "bxslider");
                                }
                                $scope.SLiderMargin = 70;
                            }


                            //var dyndvTitle = document.createElement("div");
                            //dyndvTitle.setAttribute("style", "text-align: center;margin-top: -55px;font-size: 18px;font-weight: 900;");
                            //dyndvTitle.innerHTML = (obj[i]["ProductName"] + " [" + obj[i]["UOM"] + "]");
                            //dynDiv.appendChild(dyndvTitle);
                            document.getElementById('ulchart').appendChild(dynDiv1);

                            //'<div style="text-align: center;margin-top: -55px;font-size: 18px;font-weight: 900;">' + (obj[i]["ProductName"] + " [" + obj[i]["UOM"] + "]") + '</div>'

                            document.getElementById("lichart" + i).appendChild(dynDiv);
                            options.bindchrt("chartchemical" + i, ar_tmp, obj[i]["intProductID"], (obj[i]["ProductName"] + " [" + obj[i]["UOM"] + "]"), "clschemdonutChart");

                            //     options.bindguage("chartchemical" + i, '#4d4d4d',
                            //  obj[i]["Standard_Qty"], obj[i]["Actual_Qty"], obj[i]["Max_Qty"], obj[i]["intProductId"],
                            //(obj[i]["Product_Name"] + " [" + obj[i]["UOM"] + "]"));
                            ar_tmp = [];
                            rcnt = 0;
                            //document.getElementById('chartchemical' + i).style.cursor = "pointer";
                        }

                    };
                    $('.bxslider').bxSlider({
                        mode: 'horizontal',
                        moveSlides: 1,
                        slideMargin: $scope.SLiderMargin,
                        infiniteLoop: false,
                        slideWidth: 250,
                        minSlides: ($(window).width() <= 1024 && $(window).width() > 576 ? 3 : ($(window).width() < 576 ? 2 : 4)),
                        maxSlides: ($(window).width() <= 1024 && $(window).width() > 576 ? 3 : ($(window).width() < 576 ? 2 : 4)),
                        speed: 500,
                    });


                    if (obj.length <= 4) {
                        $('#bxwrapperid1').find('.bx-has-pager').css("display", "none");
                    }
                    else {
                        $('#bxwrapperid1').find('.bx-has-pager').css("display", "block");
                    }
                    $('#zoom5').css("display", "block");
                } else {
                    var uldiv = document.getElementById('ulchart');
                    uldiv.innerHTML = '';
                    //$('#zoom5').css("display", "none");
                    $('#demoChemical').css("display", "none");
                    $('#zoom6').css("margin-bottom", "10px");
                }
            }
        });
    }

    $scope.OnChange_Utility_Chamical_Bind_chart = function (action) {
        var highlightCycle = $('.cyclePanl').attr('id');
        highlightCycle = (highlightCycle == 'yesterday' ? 'mtd' : highlightCycle);
        //if (action == 'Chemical') {
        //    localStorage.setItem('GaugeUtilityFilter', $scope.dType.substring(1, 2));
        //}
        //else {
        //    localStorage.setItem('GaugeUtilityFilter', $scope.vType.substring(1, 2));
        //}


        var promiseSucc = Applicationservice.Get_Date_Range(highlightCycle);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != '') {

                $scope.QuarterTamplateList = pl.data;
                var from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                var to_date = $scope.QuarterTamplateList[4]['dtToDate'];
                var Type = 'Q'
                if (action == "Utility") {
                    $scope.Bind_Refined_Utility_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, Type, 'GetUtility');
                }
                else if (action == "Chemical") {
                    $scope.Bind_Refined_Chemical_chart(from_date, to_date, $scope.fk_BrandGlCode, $scope.fk_PlantGlCode, Type, 'GetChemical');
                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    window.onload = function () {
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];;
        var date = new Date();

        $('.date').html(months[date.getMonth()] + ' - ' + date.getFullYear());
    }

    $scope.exporttopdf = function (chartid1) {
        $("#" + chartid1).dxChart("instance").exportTo("Exampleqaaaa", "pdf");
    };

    var options = {
        bindchrt: function (guageid, ar_tmp, fk_product_id, titletext, donutclass) {
            var objChrt = $("#" + guageid).dxPieChart($.extend(true, {}, {
                palette: ['#ffac06', '#4ebfe0', '#fcfcfc'],
                dataSource: ar_tmp,
                type: "donut",
                //title: {
                //    text: titletext,
                //    font: {
                //        size: 14,
                //        weight: 600
                //    },
                //    verticalAlignment: "top",
                //    horizontalAlignment: "center"
                //},
                onDrawn: function (e) {
                    if ($scope.isExt) {
                        e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'default'); }, function () { $(this).css('cursor', 'default'); });
                    }
                    else {
                        e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'auto'); });
                    }
                },
                legend: {
                    visible: false
                },
                commonSeriesSettings: {
                    startAngle: 180,
                    innerRadius: 0.1,
                    label: {
                        backgroundColor: 'transparent',
                        visible: true,
                    }
                },
                margin: { top: 40 },
                size: {
                    height: 200,
                    width: 330
                },
                series: [{
                    name: "Standard_Qty",
                    argumentField: "id",
                    valueField: "Standard_Qty",
                    label: {
                        visible: true,
                        font: {
                            color: '#000',
                            weight: 900
                        },
                        customizeText: function (arg) {
                            return (arg.argument != '2' ? '' : parseFloat(arg.valueText).toFixed(2));
                        },
                        position: 'inside',
                    }
                }, {
                    name: "Actual_Qty",
                    argumentField: "id",
                    valueField: "Actual_Qty",
                    label: {
                        font: {
                            color: '#000',
                            weight: 900
                        },
                        visible: true,
                        customizeText: function (arg) {
                            return (arg.argument != '1' ? '' : parseFloat(arg.valueText).toFixed(2));
                        },
                        position: 'inside',
                    },
                }, ],
                onPointClick: function (info) {
                    if (info.target.argument == 3) {
                        return;
                    }

                    if ($scope.isExt) {
                        return;
                    }

                    var clickedPoint = info.target;
                    clickedPoint.isSelected() ? clickedPoint.clearSelection() : clickedPoint.select();
                    var Type = "";

                    var SelectedSlab = ar_tmp.filter(function (entry) {
                        return entry.id === info.target.argument
                    })[0];
                    localStorage.setItem("backPlantGlCode", $scope.fk_PlantGlCode);
                 
                    $window.location.assign(AppURL + '/dashboard/RefinaryWiseSteamConsumption?prm=' + $rootScope.EncryptionText('Pnt=' + $scope.fk_PlantGlCode + '&Prd=' + $scope.fk_BrandGlCode + '&product_id=' + SelectedSlab.intProductID));
                }
            }));

            $("#" + guageid).append('<div class="' + donutclass + '" style="position: absolute;width: 330px;text-align: center;"><div style="text-align: center;margin-top: -73px;font-size: 15px;font-weight: 900;text-transform: capitalize;">' + titletext + '</div></div>');
            $("#" + guageid).append('<input type="hidden" value="' + fk_product_id + '" id="hdn' + guageid + '" value="" />');
        },
        bindguage: function (guageid, guagecolor, value, actual, maxval, fk_product_id, titletext) {

            var objgauge = $("#" + guageid).dxCircularGauge($.extend(true, {}, {
                value: actual,
                containerBackgroundColor: guagecolor,
                onDrawn: function (e) {
                    if ($scope.isExt) {
                        e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'default'); }, function () { $(this).css('cursor', 'default'); });
                    }
                    else {
                        e.element.find(".dxc-series, .dxc-legend").hover(function () { $(this).css('cursor', 'pointer'); }, function () { $(this).css('cursor', 'auto'); });
                    }
                },
                geometry: {
                    startAngle: 180,
                    endAngle: 0
                },
                scale: {
                    startValue: 0,
                    endValue: maxval,
                    tickInterval: maxval,
                    tick: {
                        color: 'transparent'
                    },
                    label: {
                        visible: true
                    },
                    orientation: "inside"
                },
                tooltip: {
                    enabled: false,
                    ToolTipVisibility: "always"
                },
                title: {
                    text: titletext,
                    font: {
                        size: 14,
                        weight: 600
                    },
                    verticalAlignment: "bottom",
                    horizontalAlignment: "center"
                },
                size: {
                    height: 250,
                    width: 300
                },
                subvalues: [parseFloat(value).toFixed(2), parseFloat(actual).toFixed(2)],
                valueIndicator: {
                    type: "triangleNeedle",
                    color: guagecolor,
                    width: 15
                },
                subvalueIndicator: {
                    palette: ["#4ebfe0", "#ffac06"],
                    type: "textcloud",
                    color: "#BB7862",
                    text: {
                        font: {
                            size: 15,
                            color: "#ffffff"
                        },
                        customizeText: function (arg) {
                            return parseFloat(arg.value).toFixed(2);
                        }
                    },
                    offset: -8
                },
                //#5186d0
                rangeContainer: {
                    offset: 30,
                    fontsize: 12,
                    ranges: [
                        { startValue: 0, endValue: value, color: "#ffac06" },
                        { startValue: value, endValue: maxval, color: "#4ebfe0" }
                    ],
                    width: 40
                },

                label: {
                    enabled: true,
                    customizeTooltip: function (arg) {

                        return {
                            color: this.color,
                            text: parseFloat(arg.value).toFixed(2)
                        };
                    },
                    indent: 100
                },
                tooltip: {
                    enabled: true,
                    customizeTooltip: function (arg) {
                        return {
                            color: this.color,
                            text: parseFloat(arg.value).toFixed(2)
                        };
                    },
                    font: {
                        color: "#ffffff",
                        size: 20
                    }
                },
                resolveLabelOverlapping: "shift",
            }));
            $("#" + guageid).append('<input type="hidden" value="' + fk_product_id + '" id="hdn' + guageid + '" value="" />');
        }
    };

}]);
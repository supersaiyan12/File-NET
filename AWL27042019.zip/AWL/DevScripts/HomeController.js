﻿app.controller('HomeController', ['$scope', 'Applicationservice', '$rootScope', '$sce', '$timeout', 'AppURL', 'AuthenticationService', '$window', '$filter', function ($scope, Applicationservice, $rootScope, $sce, $timeout, AppURL, AuthenticationService, $window, $filter) {

    $scope.lblwaring;
    $scope.PlantList = [];
    $scope.BrandList = [];
    $scope.mRefinedLink = AppURL + "/dashboard/HOLanding";
    $scope.mPackingLink = AppURL + "/dashboard/PackingHOLanding";
    $scope.mBrcmnCycleName = localStorage.getItem('varCycle');
    $scope.from_date;
    $scope.to_date;
    $scope.varaction;
    $scope.chrQtyType;
    $scope.chrType;
    $scope.QuarterTamplateList = [];
    $scope.RefinedMenuList = [];
    $scope.PackingMenuList = [];
    $rootScope.DisableProductionList = [];
    $scope.exportlist = [];
    $scope.mBrcmnCycleDisable = false;
    $scope.mUserIcon = AppURL + "/AWLContentFiles/images/user.png";
    $scope.mSignOut = AppURL + "/AWLContentFiles/images/sign-out.png";
    $rootScope.topHeading = "";
    $rootScope.mvisibleBack = true;
    $rootScope.mvisiblePlay = false;
    $rootScope.IsSecPrd = false;
    $rootScope.mvisibleHoreport = false;
    $rootScope.mvisiblePlant = true;
    $rootScope.mvisibleBrand = true;
    $rootScope.mvisibleDateCycle = true;
    $rootScope.mRefinedDash = true;
    $rootScope.mvisibleexport = true;
    $rootScope.mvisibleDownload = true;
    $rootScope.mvisibleArrow = true;
    $rootScope.AutoPlayBrandList = [];
    $scope.OrderHeader = [];
    $scope.OrderComp = [];
    $scope.ProductMst = [];
    $scope.QualityPARAM = [];
    $scope.load;
    $scope.spin;
    $scope.mVersion = "Version ";

    $scope.fileronChange = function (plantID, ProductID) {
        $scope.varBrand_ID = ProductID;
        $scope.varPlant_ID = plantID;
        $scope.LoadMenu();
    };

    $scope.opendropmega = function (flag) {
        $('#liPlant').removeClass("active");
        $('#librand').removeClass("active");
        $('#licycle').removeClass("active");

        if (flag == false) {
            if ($('#drop-brandList1').css('display') == 'block') {
                $('#liPlant').removeClass("active");
            }
            else {
                $('#liPlant').addClass('active');
            }

            $('#drop-brandList1').slideToggle();
            $('#drop-brandList').css("display", "none");
            $('#drop-cycleList').css("display", "none");
        }
    }

    $scope.opendropbrand = function (flag) {

        $('#liPlant').removeClass("active");
        $('#librand').removeClass("active");
        $('#licycle').removeClass("active");

        if (flag == false) {

            if ($('#drop-brandList').css('display') == 'block') {
                $('#librand').removeClass("active");
            }
            else {
                $('#librand').addClass('active');
            }

            $('#drop-brandList').slideToggle();
            //$(".drop-brand").toggleClass("active");
            $('#drop-brandList1').css("display", "none");
            $('#drop-cycleList').css("display", "none");
        }
    }

    $scope.opendropcycle = function (flag) {
        $('#liPlant').removeClass("active");
        $('#librand').removeClass("active");
        $('#licycle').removeClass("active");

        if (flag == false) {

            if ($('#drop-cycleList').css('display') == 'block') {
                $('#licycle').removeClass("active");
            }
            else {
                $('#licycle').addClass('active');
            }

            $('#drop-brandList').css("display", "none");
            $('#drop-brandList1').css("display", "none");
            $('#drop-cycleList').slideToggle();
        }
    }

    $scope.hideload = function () {
        $('#ldrHide').css('display', 'none');
    };

    $scope.keepAlive = function () {
       //debugger
        $scope.hideload();
        var promiseSucc = Applicationservice.keepAlivesession();
        promiseSucc.then(function (pl) {
            $('#ldrHide').attr('style', '');
        }, function (errorPl) {
            localStorage.clear();
            $window.location.assign(AppURL + '/Menu/Login/');
        });
    }


    setTimeout(function run() {
        {
            $scope.hideload();
            $scope.keepAlive();
            setTimeout(run, 3 * 1000 * 60);
        }
    }, 3 * 1000 * 60);

    $scope.LoadMenu = function () {
       //debugger
        var module = '';
        var isDevice = localStorage.getItem("isDevice");
        var local_vers = localStorage.getItem("ApplicationVersion");
        if (local_vers != undefined && local_vers != "" && local_vers != null && isDevice != undefined && isDevice != '' && isDevice != null) {
            $scope.mVersion = "Version " + local_vers;
        }
        else {
            module = 'Web';
            $scope.VersionList = [];
            var promiseSucc = Applicationservice.GetVersion(module);
            promiseSucc.then(function (pl) {
                $scope.VersionList = JSON.parse(pl.data);
                localStorage.setItem("ApplicationVersion", $scope.VersionList[0]["varVersion"]);
                $scope.mVersion = "Version " + $scope.VersionList[0]["varVersion"];
            }, function (errorPl) {
                $scope.error = errorPl;
            });
        }

        $scope.keepAlive();
        var promiseSucc = Applicationservice.CheckLogin();
        promiseSucc.then(function (pl) {
            var url_main = $window.location.pathname.toLowerCase();
            $rootScope.mRefinedDash = true;

            if (url_main.search('dashboard/packing') != -1 || url_main.search('dashboard/plant_wise_line_wise') != -1
                || url_main.search('menu/packing') != -1) {
                $rootScope.mRefinedDash = false;
            }
            $scope.mBrcmnCycleDisable = false;
            $scope.mBrcmnCycleName = localStorage.getItem('varCycle').toUpperCase();
            var personglcode = localStorage.getItem('personglcode');
            var RoleCode = localStorage.getItem('var_RoleName');
           //debugger
            $scope.setmCycleVisulizer();
            $scope.CheckLoginDetail = pl.data;
            $scope.GetPlantList();
            $scope.GetMenuList(personglcode);
            $scope.GetMenuListAccordingRole(personglcode);
            //$scope.GetBreadCrumbDetail();
            $scope.LblUserName = localStorage.getItem('UserFullName');
            //$scope.CheckMenuRights();

        }, function (errorPl) {
            AuthenticationService.setTokenInfo(null);
            localStorage.clear();
            $window.location.assign(AppURL + '/Menu/Login/');
        });

    };

    $scope.setmCycleVisulizer = function () {
        var cycle = $rootScope.GetMonthDetails($scope.mBrcmnCycleName);
        $('#liBrcmnCycle').text(cycle);
        $rootScope.mCycleVisulizer = cycle;
    };

    $scope.CheckMenuRights = function () {
        var Path = $window.location.pathname.split('/').filter(Boolean);
        var fk_MenuGlCode = Path[3];
        var varPageURL = Path[2];
        var fk_RoleGlCode = localStorage.getItem("fk_RoleGlCode");
        var fk_personglcode = localStorage.getItem("personglcode");
        if (fk_RoleGlCode != undefined && varPageURL != undefined && varPageURL != null) {
            var LandingUrl = localStorage.getItem("LandingUrl");
            var promiseSucc = Applicationservice.CheckMenuRights(fk_personglcode, fk_RoleGlCode, varPageURL);
            promiseSucc.then(function (pl) {
                if (pl.data == "Fail")
                    $window.location.assign(LandingUrl);
            }, function (errorPl) {
                $window.location.assign(LandingUrl);
            });
        } else {
            if (Path[2] != "Home")
                $window.location.assign(LandingUrl);
        }
    };

    $scope.GetBreadCrumbDetail = function () {
        if (isNaN(location.pathname.split('/').filter(Boolean)[location.pathname.split('/').filter(Boolean).length - 1]) == false) {
            var promiseSucc = Applicationservice.GetBreadCrumbDetail(localStorage.getItem('personglcode'), location.pathname.split('/').filter(Boolean)[location.pathname.split('/').filter(Boolean).length - 2]);
            promiseSucc.then(function (pl) {
                var bcData = pl.data[0].displayName.split(' < ').filter(Boolean).reverse();
                var lstBreadCrumb = [];
                for (var i = 0; i < bcData.length; i++) {
                    var objBreadCrumb = {};
                    objBreadCrumb.MenuName = bcData[i];
                    lstBreadCrumb.push(objBreadCrumb);
                }
                $scope.BreadCrumbList = lstBreadCrumb;
            }, function (errorPl) {
                $scope.error = errorPl;
            });
        }
        else {
            if (location.pathname.indexOf("/OrderAllocation/OrderAllocation") > 0) {
                var lstBreadCrumb = [];
                for (var i = 0; i < 2; i++) {
                    var objBreadCrumb = {};
                    if (i == 0) {
                        objBreadCrumb.MenuName = "Transaction";
                    }
                    else { objBreadCrumb.MenuName = "Order Allocation"; }
                    lstBreadCrumb.push(objBreadCrumb);
                }
                $scope.BreadCrumbList = lstBreadCrumb;
            }
        }
    }

    $scope.MenuClick = function (dashBoardID, MenuID, baseUrl) {
        sessionStorage.setItem("MenuID", MenuID);
        if (dashBoardID != "") {
            //$location.path(AppURL + '/Menu/Report/')
            $window.location.assign(AppURL + '/Menu/Report/');
            sessionStorage.setItem("DashboardID", dashBoardID);
        } else {
            $window.location.assign(AppURL + '/Menu/' + baseUrl + '/');
            //$location.path()
        }
    };

    $scope.Logout = function () {

        var id = localStorage.getItem('LogID');
        var flag = 'L';

        var promiseSucc = Applicationservice.Insert_Login_Details(id, '', '', '', '', 0, '', '', '', flag);
        promiseSucc.then(function (pl) {

        }, function (errorPl) {
            $scope.error = errorPl;
        });

        $("#divNote").hide();
        $('#FirebugUI').hide();
        $("#captcha").hide();
        localStorage.clear();
        window.location.href = Applicationservice.BaseURL() + '/Menu/Login/';
    };

    //#region MenuLogic
    //Get Parent Menu List as per Logged User
    $scope.GetParentMenuList = function (personglcode) {
        $("#divNote").hide();
        var promiseSucc = Applicationservice.GetparentMenuDtl(personglcode);
        promiseSucc.then(function (pl) {
            $scope.ParentMenuList = pl.data
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };
    //Get Parent wise Child Menu List as per Logged User
    $scope.GetParentWiseChildMenuList = function (parentGlCode) {
        //
        //alert("Child");
        var personglcode = localStorage.getItem('personglcode');
        var promiseSucc = Applicationservice.GetChildMenuDtl(parentGlCode, personglcode);
        promiseSucc.then(function (pl) {
            $scope.ChildMenuList = pl.data
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetMenuList = function (personglcode) {
        var requestedUrl = document.URL;
        var menuCode = requestedUrl.split('/')[parseInt(requestedUrl.split('/').length) - 2];
        var personglcode = localStorage.getItem('personglcode');

        var chrLoginType = 'W';
        if (navigator.userAgent.match(/Mobi/) || navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
            chrLoginType = 'M';
        }

        var promiseSucc = Applicationservice.GetMenuList(personglcode, chrLoginType);
        promiseSucc.then(function (pl) {

            $scope.MenuList = JSON.parse(pl.data).menulist;
            var display = '';
            var ActiveParentMenu = '';
            var DashboardMenu = '';
            //class="active"
            for (var i = 0; i < $scope.MenuList.length; i++) {

                display += '<li id="mnu_' + $scope.MenuList[i].intGLCode + '">';
                display += '<i class="lefticon"><img src="' + AppURL + '/AWLContentFiles/images/' + $scope.MenuList[i].varIconPath + '" /></i>';
                display += '<div class="animated slideInLeft sub-hover">';
                var objRefinedMenu = {};
                var objPackingMenu = {};
                if ($scope.MenuList[i].submenu != null) {
                    for (var j = 0; j < $scope.MenuList[i].submenu.length; j++) {
                        if ($scope.MenuList[i].varMenuName == 'mnuDashboard' && $scope.MenuList[i].submenu[j].extra == 'Refined') {
                            objRefinedMenu = {};
                            objRefinedMenu.menuName = $scope.MenuList[i].submenu[j].varDisplayName;
                            objRefinedMenu.varURL = AppURL + '/' + $scope.MenuList[i].submenu[j].varURL;
                            $scope.RefinedMenuList.push(objRefinedMenu);
                        }
                        else if ($scope.MenuList[i].varMenuName == 'mnuPackingDashboard' && $scope.MenuList[i].submenu[j].extra == 'Packing') {
                            objPackingMenu = {};
                            objPackingMenu.menuName = $scope.MenuList[i].submenu[j].varDisplayName;
                            objPackingMenu.varURL = AppURL + '/' + $scope.MenuList[i].submenu[j].varURL;
                            $scope.PackingMenuList.push(objPackingMenu);
                        }

                        if (menuCode == $scope.MenuList[i].submenu[j].intGLCode) {
                            ActiveParentMenu = $scope.MenuList[i].intGLCode;
                            display += '<a href="' + AppURL + "/" + $scope.MenuList[i].submenu[j].varURL + "/" + $scope.MenuList[i].submenu[j].intGLCode + "/" + localStorage.getItem('personglcode') + '"><div class="menu-title">' + $scope.MenuList[i].submenu[j].varDisplayName + '</div></a>';
                        }
                        else {
                            display += '<a href="' + AppURL + "/" + $scope.MenuList[i].submenu[j].varURL + "/" + $scope.MenuList[i].submenu[j].intGLCode + "/" + localStorage.getItem('personglcode') + '"><div class="menu-title">' + $scope.MenuList[i].submenu[j].varDisplayName + '</div></a>';
                        }
                    }

                }
                display += '</li>';
            }

            objRefinedMenu = {};
            objRefinedMenu.menuName = 'Refine User Manual';
            objRefinedMenu.varURL = AppURL + '/' + 'AWL_User_Manual_Refined_ver 1.4.pdf';
            $scope.RefinedMenuList.push(objRefinedMenu)

            objPackingMenu = {};
            objPackingMenu.menuName = 'Packaging User Manual';
            objPackingMenu.varURL = AppURL + '/' + 'AWL_User_Manual_Packaging ver 1.1.pdf';
            $scope.PackingMenuList.push(objPackingMenu);

            $("#ulMenuDisplay").html(display);
            $("#mnu_" + ActiveParentMenu).removeClass();
            $("#mnu_" + ActiveParentMenu).addClass("active");
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetMenuListAccordingRole = function (personglcode) {
        //   
        $scope.displayMenuName = [];
        var personglcode = localStorage.getItem('personglcode');

        var chrLoginType = 'W';
        if (navigator.userAgent.match(/Mobi/) || navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
            chrLoginType = 'M';
        }

        var promiseSucc = Applicationservice.GetMenuListAccordingRole(personglcode, chrLoginType);
        promiseSucc.then(function (pl) {
            $scope.MenuListAccordingRole = JSON.parse(pl.data);
            for (var i = 0; i < $scope.MenuListAccordingRole.length; i++) {
                $scope.displayMenuName.push($scope.MenuListAccordingRole[i].varDisplayName);
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetPlantList = function () {

        $('#plantList').html('');
        var plantUl = '';
        var personglcode = localStorage.getItem('personglcode');
        var role_code = localStorage.getItem('var_RoleName');

        $scope.PlantList = [];
        var promiseSucc = Applicationservice.Get_General_List(personglcode, role_code, 'Plant', 0, 'S');
        promiseSucc.then(function (pl) {
            $scope.PlantList = JSON.parse(pl.data);
            for (var i = 0; i < $scope.PlantList.length; i++) {
                plantUl += '<li data-id="' + $scope.PlantList[i]['intPlantId'] + '" data-plantname="' + $scope.PlantList[i]['plant_Name'] + '">';
                plantUl += '<label class="pk">';
                plantUl += '<p>' + $scope.PlantList[i]['plant_Name'] + '</p>';
                plantUl += '<input id="plant_' + $scope.PlantList[i]['intPlantId'] + '" ' + (i == 0 ? "checked='true'" : "") + ' type="radio" name="plant" value="' + $scope.PlantList[i]['intPlantId'] + '"  >';
                plantUl += '<span class="checkmark"></span>';
                plantUl += '</label>';
                plantUl += '</li>';
            }
            $('#plantList').html(plantUl);
            $scope.mBrcmnPlantDisable = false;
            // Changes for Plant wise Product
            var url_main = $window.location.pathname.toLowerCase();

            if (url_main.search('dashboard/plantlanding') != -1) {
                    $rootScope.IsSecPrd =  true; 
            } else {
                $rootScope.IsSecPrd = false;
            }

            if (url_main.search('dashboard/holanding') != -1 || url_main.search('dashboard/packingholanding') != -1 || url_main.search('menu/holandingreport') != -1) {
                if (url_main.search('dashboard/packingholanding') != -1 || url_main.search('dashboard/holanding') != -1 || url_main.search('menu/packingholandingreport') != -1) {
                    $rootScope.mvisiblePlay = true;
                }
                $scope.GetBrandList(0);
            }
            else {
                if (url_main.search('dashboard/plant_details') != -1 || url_main.search('menu/horeport') != -1
                    || url_main.search('dashboard/refinarywisesteamconsumption') != -1
                    || url_main.search('dashboard/refinery_wise_std') != -1
                    || url_main.search('dashboard/refinaryconsumptiongraph') != -1
                    || url_main.search('dashboard/plant_wise_line_wise') != -1) {

                    var url = $window.location.search;
                    if (url.split('?').length > 1) {
                        var Decrp = $rootScope.DecryptionText(url.split('?prm=')[1]);
                        if (Decrp != null && Decrp != '') {
                            var fk_PlantGlCode = (Decrp.split('&')[0].split('=')[1]);
                            $scope.GetBrandList(fk_PlantGlCode);
                        }
                    }
                    else {
                        $scope.GetBrandList($scope.PlantList[0]['intPlantId']);
                    }
                }
                else {
                    $scope.GetBrandList($scope.PlantList[0]['intPlantId']);
                }
            }

            //$scope.GetBrandList();
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    $scope.GetBrandList = function (fk_PlantGlCode) {

        var personglcode = localStorage.getItem('personglcode');
        var role_code = localStorage.getItem('var_RoleName');

        var typ = 'Brand';
        var url_main = $window.location.pathname.toLowerCase();
        if (url_main.search('dashboard/plant_wise_line_wise') != -1) {
            typ = 'Pack';
        }

        $scope.BrandList = [];
        var promiseSucc = Applicationservice.Get_General_List(personglcode, role_code, typ, fk_PlantGlCode, ($rootScope.mRefinedDash == true ? 'S' : 'F'));
        promiseSucc.then(function (pl) {
            $scope.BrandList = JSON.parse(pl.data);
            var url = $window.location.pathname.toLowerCase();
            //if ($scope.BrandList.length > 0) {
                $scope.SetBreadcum();
               // getSUN_Soya_RICERow($scope.BrandList, "brand_Name");
            //}
            if (!$rootScope.mRefinedDash) {
                $('ul#BrandList').delegate("li label input", 'change', function () {
                    if (typ == 'Pack') {
                        angular.element('#dvChangeFilter').scope().fileronChange($('ul#plantList').find('li input:checked').parents('li').attr('data-id'), $(this).parents('label').attr('data-productname'));
                    } else {
                        angular.element('#dvChangeFilter').scope().fileronChange($('ul#plantList').find('li input:checked').parents('li').attr('data-id'), $(this).parents('label').attr('data-id'));
                    }
                });
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    };

    function getSUN_Soya_RICERow(arr, prop) {
        for (var i = 0 ; i < arr.length ; i++) {
            if (
			  (arr[i][prop].toLowerCase()).trim() == "Soya".toLowerCase() 
				  || (arr[i][prop].toLowerCase()).trim() == "sun".toLowerCase() 
				|| (arr[i][prop].toLowerCase()).trim() == "Rice Bran".toLowerCase()
				) {
                $rootScope.DisableProductionList.push(arr[i]["intBrandId"]);
            }
        }
    }

    $scope.SetBreadcum = function () { 
        var role_code = localStorage.getItem('var_RoleName');
        var url = $window.location.pathname.toLowerCase();
        var mlinkProduct = '';
        if ($scope.PlantList != null && $scope.PlantList.length > 0) {
            if ((role_code == "HO" || role_code == "AWL Admin") && (url.search('dashboard/plantlanding') != -1 || url.search('dashboard/packingplantlanding') != -1
                    || url.search('dashboard/plant_details') != -1 || url.search('menu/horeport') != -1
                    || url.search('menu/plantlandingreport') != -1) || url.search('dashboard/plant_wise_line_wise') != -1 || url.search('menu/packingplantlandingreport') != -1) {
                $scope.mBrcmnPlantName = $scope.PlantList[0]['plant_Name'];
                $scope.mBrcmnPlant = $scope.PlantList[0]['intPlantId'];
                $scope.mBrcmnPlantDisable = false;
            } else if (role_code == "Admin") {
                $scope.mBrcmnPlantName = $scope.PlantList[0]['plant_Name'];
                $scope.mBrcmnPlant = $scope.PlantList[0]['intPlantId'];
                $scope.mBrcmnPlantDisable = false;
            } else if (role_code == "PlantManager" && (url.search('dashboard/plantlanding') != -1
                || url.search('dashboard/packingplantlanding') != -1
                || url.search('dashboard/plant_details') != -1
                || url.search('menu/home') != -1)) {
                $scope.mBrcmnPlantName = $scope.PlantList[0]['plant_Name'];
                $scope.mBrcmnPlant = $scope.PlantList[0]['intPlantId'];
                $scope.mBrcmnPlantDisable = false;
            } else {

                $scope.mBrcmnPlantName = "All Plant";
                $scope.mBrcmnPlant = "";
                $scope.mBrcmnPlantDisable = true;
            }
        }

        if ($scope.BrandList != null && $scope.BrandList.length > 0) {

            if ($rootScope.mRefinedDash) {
                mlinkProduct = $scope.BrandList[0]['intBrandId'];
            }
            else {
                mlinkProduct = $scope.BrandList[0]['Row_Id'];
            }

            if ((role_code == "HO" || role_code == "AWL Admin") && (url.search('dashboard/holanding') != -1 ||
                url.search('menu/holandingreport') != -1 || url.search('dashboard/packingholanding') != -1 ||
                url.search('menu/packingholandingreport') != -1 || url.search('menu/home') != -1)) {
                $scope.mBrcmnProduct = mlinkProduct;
                $scope.mBrcmnProductName = $scope.BrandList[0]['brand_Name'];
                $scope.mBrcmnProductDisable = false;
            } else if (role_code == "Admin") {
                $scope.mBrcmnProduct = mlinkProduct;
                $scope.mBrcmnProductName = $scope.BrandList[0]['brand_Name'];
                $scope.mBrcmnProductDisable = false;
            } else if ((role_code == "HO" || role_code == "PlantManager" || role_code == "AWL Admin") &&
                (url.search('dashboard/plant_details') != -1 || url.search('menu/horeport') != -1 ||
                url.search('dashboard/plant_wise_line_wise') != -1)) {
                $scope.mBrcmnProduct = mlinkProduct;
                $scope.mBrcmnProductName = $scope.BrandList[0]['brand_Name'];
                $scope.mBrcmnProductDisable = false;
            } else {
                $scope.mBrcmnProduct = "";
                $scope.mBrcmnProductName = "All Product";
                $scope.mBrcmnProductDisable = true;

            }
        } else {
        
            $scope.mBrcmnProduct = "0";
            $scope.mBrcmnProductName = "All Product";
            $scope.mBrcmnProductDisable = true;
        }

        $('#liBrcmnProduct').text($scope.mBrcmnProductName);


        if ((role_code == "HO" || role_code == "AWL Admin") && url.search('dashboard/holanding') != -1 && url.search('dashboard/packingholanding') != -1) {
            var backPlantGlCode = localStorage.getItem("backPlantGlCode");
            var backBrandGlCode = localStorage.getItem("backBrandGlCode");
            if ((backPlantGlCode == undefined || backPlantGlCode == "" || backPlantGlCode == null) && (backBrandGlCode == undefined || backBrandGlCode == "" || backBrandGlCode == null)) {
                localStorage.setItem("backPlantGlCode", "");
                localStorage.setItem("backBrandGlCode", $scope.mBrcmnProduct);
            }
        }

        if (role_code.toLowerCase() == 'HO'.toLowerCase() || role_code.toLowerCase() == 'Admin'.toLowerCase() || role_code.toLowerCase() == 'AWL Admin'.toLowerCase()) {
            if ($rootScope.mRefinedDash) {
                $scope.mRefinedLink = (AppURL + '/dashboard/HOLanding?prm=' + $rootScope.EncryptionText("Pnt=&Prd=" + mlinkProduct));
            }
            else {
                $scope.mRefinedLink = (AppURL + '/dashboard/packingholanding?prm=' + $rootScope.EncryptionText("Pnt=&Prd=" + mlinkProduct));
            }
        }
        else if (role_code.toLowerCase() == 'PlantManager'.toLowerCase()) {

            if ($rootScope.mRefinedDash) {
                $scope.mRefinedLink = (AppURL + '/dashboard/PlantLanding?prm=' + $rootScope.EncryptionText("Pnt=" + $scope.mBrcmnPlant + "&Prd=" + $scope.mBrcmnProduct));
            }
            else {
                $scope.mRefinedLink = (AppURL + '/dashboard/packingplantlanding?prm=' + $rootScope.EncryptionText("Pnt=" + $scope.mBrcmnPlant + "&Prd=" + $scope.mBrcmnProduct));
            }
        }

        $scope.mBrcmnCycleDisable = true;
        if (url.search('dashboard/holanding') > 0
                || url.search('dashboard/plantlanding') > 0
                || url.search('dashboard/plant_details') > 0
                || url.search('dashboard/packingholanding') > 0
                || url.search('dashboard/packingplantlanding') > 0
                || url.search('dashboard/plant_wise_line_wise') > 0
            ) {
            $scope.mBrcmnCycleDisable = false;
        }

        if (url.search('dashboard/packingholanding') <= 0) {
            localStorage.setItem("PlayProduct", "0")
            localStorage.setItem("lastProductPlay", "0")
        }
        if (url.search('dashboard/holanding') <= 0) {
            localStorage.setItem("PlayProductHO", "0")
            localStorage.setItem("lastProductPlay", "0")
        }
        //if (url.search('menu/horeport') > 0 || url.search('menu/plantlandingreport') > 0) {

        //    $("#licycle").css("display", "none");
        //}
        //else {
        //    $("#licycleg").css("display", "none");
        //    $("#licyclegs").css("display", "none");
        //}
    }

    var arrayCol = [];
    var arrCol = [];
    $scope.exportdata = function () {
        $scope.varCycle = localStorage.getItem('varCycle');
        $scope.QtyType = 'M';
        if ($scope.varCycle != '' && $scope.varCycle != "" && $scope.varCycle != 'mtd') {
            $scope.QtyType = ($scope.varCycle == 'qtd' ? 'Q' : 'Y');
        }
        var promiseSucc = Applicationservice.Get_Date_Range($scope.varCycle);
        promiseSucc.then(function (pl) {
            if (pl.data != null) {

                $scope.QuarterTamplateList = pl.data;
                var from_date = $scope.QuarterTamplateList[4]['dtFromDate'];
                var to_date = $scope.QuarterTamplateList[4]['dtToDate'];

                var Path = $window.location.pathname.split('/').filter(Boolean);
                var fk_MenuGlCode = Path[3];
                var varPageURL = Path[2];
                var fk_RoleGlCode = localStorage.getItem("fk_RoleGlCode");

                var brandid = $('ul#BrandList').find('li label input:checked').parents('label').attr('data-id');
                var plantid = $('ul#plantList').find('li input:checked').parents('li').attr('data-id');
                var typeid = '';

                var url = $window.location.pathname.toLowerCase();
                if (url.search('dashboard/plant_wise_line_wise') != -1) {
                    typeid = $('ul#BrandList').find('li label input:checked').parents('label').attr('data-productname')
                }

                if (varPageURL.toUpperCase() == "HOLanding".toUpperCase() || varPageURL.toUpperCase() == "HOLandingReport".toUpperCase() || varPageURL.toUpperCase() == "packingHoLandingReport".toUpperCase()) {
                    plantid = '';
                }
                else if (varPageURL.toUpperCase() == "plantlanding".toUpperCase() || varPageURL.toUpperCase() == "PlantLandingReport".toUpperCase() || varPageURL.toUpperCase() == "PlantLandingReport".toUpperCase()) {
                    brandid = '';
                }
                var chrType = "Q";

                if ($rootScope.mRefinedDash == false) {
                    $("#exportmodal1").modal('show');
                    var varAction = "GetAllData";
                    var promiseSucc = Applicationservice.USP_PackType_Wise_Packaging_Dashboard(plantid, typeid, '', '', '', from_date, to_date, 'M', varAction);
                    promiseSucc.then(function (pl1) {
                        var table1 = $.parseJSON(pl1.data)['Table'];
                        $scope.OrderHeader = table1;
                        $("#tb1").dxDataGrid({
                            dataSource: table1,
                            selection: {
                                mode: "multiple"
                            },
                            "export": {
                                enabled: true,
                                fileName: "Raw Data",
                                allowExportSelectedData: true
                            },
                            width: "180%",
                            columns:
                        ["PO_Number", "Product_Code", "Product_Description", "Plant_Code", "Plant_Name", { dataField: "Act_Finish_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }, { dataField: "idocDate", dataType: "date", width: 100, format: 'dd/MM/yyyy' }, "Insp_Lot", "UOM", "Actual_Quantity", "Refinary_Code", "Gross_Wt", "Net_Wt", "Mat_Freight_Grp", "Mat_Group_Pack_Material", "PH1", "ph2", "ph3"],
                            paging: {
                                pageSize: 5
                            },
                            pager: {
                                showPageSizeSelector: true,
                            },

                            searchPanel: {
                                visible: true
                            }
                        }).dxDataGrid("instance");

                        var table2 = $.parseJSON(pl1.data)['Table1'];
                        $scope.OrderComp = table2;
                        $("#tb2").dxDataGrid({
                            dataSource: table2,
                            selection: {
                                mode: "multiple"
                            },
                            "export": {
                                enabled: true,
                                fileName: "Raw Data",
                                allowExportSelectedData: true
                            },
                            width: "250%",
                            columns: ["Plant_Code", "Plant_Name", "Product_Code", "Product_Description", "Component_Code", "Component_Description", "PO_Number", "GMov", "MVT", "Product_Description", "Requiremnt_Qty", "Actual_Qty", "UOM", "Batch", "Amount_IN_LC_MT", "Amount_IN_LC", "CrCy", { dataField: "Sync_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }],
                            paging: {
                                pageSize: 5
                            },
                            pager: {
                                showPageSizeSelector: true,
                            },
                            searchPanel: {
                                visible: true
                            }
                        }).dxDataGrid("instance");
                    }, function (errorPl) {
                        $scope.error = errorPl;
                    });
                }

                else {
                    var promiseSucc = Applicationservice.Get_Refined_Dashboard(brandid, plantid, from_date, to_date, $scope.QtyType, chrType, "GetAllData");
                    promiseSucc.then(function (pl1) {

                        var table1 = $.parseJSON(pl1.data)['Table'];
                        $scope.OrderHeader = table1;
                        var t1 = table1;
                        for (var key in table1) {
                            arrayCol.push(key);
                        }
                        $("#tab1").dxDataGrid({
                            dataSource: table1,
                            selection: {
                                mode: "multiple"
                            },
                            "export": {
                                enabled: true,
                                fileName: "Raw Data",
                                allowExportSelectedData: true
                            },
                            width: "180%",
                            columns:
                        ["PO_Number", "Product_Code", "Product_Name", "Product_Description", "Brand_Name", "Plant_Code", "Plant_Name", "UOM", "Standard_Quantity", "Actual_Quantity", { dataField: "Sched_Start_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }, { dataField: "Act_Start_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }, { dataField: "Sched_Fin_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }, { dataField: "Act_Finish_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }, { dataField: "Sync_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }],
                            paging: {
                                pageSize: 5
                            },
                            pager: {
                                showPageSizeSelector: true,
                            },
                            searchPanel: {
                                visible: true
                            }
                        }).dxDataGrid("instance");

                        var table2 = $.parseJSON(pl1.data)['Table1'];
                        $scope.OrderComp = table2;
                        $("#tab2").dxDataGrid({
                            dataSource: table2,
                            selection: {
                                mode: "multiple"
                            },
                            "export": {
                                enabled: true,
                                fileName: "Raw Data",
                                allowExportSelectedData: true
                            },
                            width: "250%",
                            columns: ["Plant_Code", "Plant_Name", "Brand_Name", "Product_Code", "Product_Name", "Product_Category", "PO_Number", "GMov", "MVT", "Item", "Refinary_Code", "Refinary_Name", "Component_Code", "Component_Name", "Componet_Category", "Product_Description", "Requiremnt_Qty", "Standard_Qty_MT", "Actual_Qty_MT", "Actual_Qty", "UOM", "Batch", "Amount_IN_LC_MT", "Amount_IN_LC", "CrCy", { dataField: "Sync_Date_Time", dataType: "date", width: 100, format: 'dd/MM/yyyy' }],
                            paging: {
                                pageSize: 5
                            },
                            pager: {
                                showPageSizeSelector: true,
                            },
                            searchPanel: {
                                visible: true
                            }
                        }).dxDataGrid("instance");

                        var table3 = $.parseJSON(pl1.data)['Table2'];
                        $scope.ProductMst = table3;
                        $("#tab3").dxDataGrid({
                            dataSource: table3,
                            selection: {
                                mode: "multiple"
                            },
                            "export": {
                                enabled: true,
                                fileName: "Raw Data",
                                allowExportSelectedData: true
                            },
                            width: "150%",
                            columns: ["Plant_Code", "Plant_Name", "Product_Code", "Product_Name", "Component_Code", "Product_Name", "Product_Standard_Value", "UOM"],
                            paging: {
                                pageSize: 5
                            },
                            pager: {
                                showPageSizeSelector: true,
                            },
                            searchPanel: {
                                visible: true
                            }
                        }).dxDataGrid("instance");

                        var table4 = $.parseJSON(pl1.data)['Table3'];
                        $scope.QualityPARAM = table4;
                        $("#tab4").dxDataGrid({
                            dataSource: table4,
                            selection: {
                                mode: "multiple"
                            },
                            "export": {
                                enabled: true,
                                fileName: "Raw Data",
                                allowExportSelectedData: true
                            },
                            width: "90%",
                            columns: ["PO_Number", "Product_Code", "ParameterCode", "Parameter_Name", "Parameter_Value"],
                            paging: {
                                pageSize: 5
                            },
                            pager: {
                                showPageSizeSelector: true,
                            },
                            searchPanel: {
                                visible: true
                            }
                        }).dxDataGrid("instance");

                        $('#exportmodal').removeAttr("style");
                        $('#exportmodal').css("display", "block");

                    }, function (errorPl) {
                        $scope.error = errorPl;
                    });

                }
            }
        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $scope.ChangeBrand = function (item) {
        if (item != null) {
            $scope.mBrcmnProduct = item.intBrandId;
            $scope.mBrcmnProductName = item.brand_Name;
            angular.element('#dvChangeFilter').scope().fileronChange($scope.mBrcmnPlant, $scope.mBrcmnProduct);
        }
    };

    //#endregion
    $scope.$watch('MenuList', function () {
        $timeout(function () {
            $('#accordion').smartmenus({
                subMenusSubOffsetX: 1,
                subMenusSubOffsetY: -8
            });
        });
    });

    //#endregion
    $scope.$watch('MenuList', function () {
        $timeout(function () {
            $('#accordion').smartmenus({
                subMenusSubOffsetX: 1,
                subMenusSubOffsetY: -8
            });
        });

    });

    $rootScope.ErrorMessage = function (msg, title) {
        //$('.modal-title').html(title);
        $('#myModal').find('.modal-title').html(title)
        $(".errmsg").html(msg);
        $(".modal-header button").children().children()[0].src = AppURL + "/AWLContentFiles/images/close-x.png";
        $('#msg').attr('style', 'color:red;');
        $('#myModal').modal('show');
    }

    $rootScope.SuccessMessage = function (msg, title) {
        //$('.modal-title').html(title);
        $('#myModal').find('.modal-title').html(title)
        $(".errmsg").html(msg);
        $(".modal-header button").children().children()[0].src = AppURL + "/AWLContentFiles/images/close-x.png";
        $('#msg').attr('style', 'color:green;');
        $('#myModal').modal('show');
    }

    $rootScope.EncryptionText = function (text) {
        var encrypted = CryptoJS.AES.encrypt(text, $rootScope.base64Key, { iv: $rootScope.iv });
        return encrypted;
    }

    $rootScope.DecryptionText = function (text) {
        var cipherParams = CryptoJS.lib.CipherParams.create({
            ciphertext: CryptoJS.enc.Base64.parse(text)
        });
        var decrypted = CryptoJS.AES.decrypt(cipherParams, $rootScope.base64Key, { iv: $rootScope.iv });
        return decrypted.toString(CryptoJS.enc.Utf8);
    };

    $scope.GetScopeMonthDetails = function (action) {
        var d = new Date();
        var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        var arQuater = [4, 1, 2, 3];
        //var Year = d.getFullYear() + '-' + (d.getFullYear() + 1);
        var Year = (arQuater[Math.floor((d.getMonth() + 3) / 3) - 1] != 4) ? (d.getFullYear() + '-' + (d.getFullYear() + 1)) : ((d.getFullYear() - 1) + '-' + d.getFullYear());
        var cycle = action.toUpperCase() + ": " + (action.toLowerCase() == 'mtd' ? monthNames[d.getMonth()] + ',' + d.getFullYear() : (action.toLowerCase() == 'qtd' ? 'Q' + arQuater[Math.floor((d.getMonth() + 3) / 3) - 1] + ',' + d.getFullYear() : Year));
        return cycle;
    }

    $rootScope.GetMonthDetails = function (action) {
        var cycle = $scope.GetScopeMonthDetails(action);
        return cycle;
    }

    $rootScope.insertformvisit = function (formname, FID) {

        var app = '';
        var flag = 'D';
        var Dip = '';

        var pglcode = localStorage.getItem('personglcode');

        var version = localStorage.getItem('ApplicationVersion');
        if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null || /(android)/i.test(navigator.userAgent)) {
            app = 'A';
            if (navigator.userAgent.toLowerCase().match(/(ipad|iphone|ipod)/) != null) {
                app = 'I';
            }
        } else {
            app = 'W';
        }
        if (FID == '' || FID == undefined) {
            Dip = '';
        }
        else {
            Dip = FID;
        }
        var promiseSucc = Applicationservice.Insert_Login_Details(Dip, '', '', '', '', pglcode, app, formname, version, flag);
        promiseSucc.then(function (pl) {
            if (pl.data != null && pl.data != undefined) {
                var data = $.parseJSON(pl.data);
                var id = data["Table"][0]["NID"]
                localStorage.setItem("FID", id);
            }
            else {

            }

        }, function (errorPl) {
            $scope.error = errorPl;
        });
    }

    $('.allbtnExport').click(function () {

        $('#AllExportDiv1').html('');
        $('#AllExportDiv2').html('');
        $('#AllExportDiv3').html('');
        $('#AllExportDiv4').html('');

        var strHeaderHtml = '<table id="tex1"><tr style="background-color:#1d83ec;color:#ffffff">';
        var grid = $rootScope.mRefinedDash == true ? $("#tab1").dxDataGrid("instance") : $("#tb1").dxDataGrid("instance");
        var tab2 = $rootScope.mRefinedDash == true ? $("#tab2").dxDataGrid("instance") : $("#tb2").dxDataGrid("instance");

        var columnIndicies = [];
        var colCount = grid.columnCount();
        for (var i = 0; i < colCount; i++) {
            if ('' + grid.columnOption(i).visible + '' == 'true')
                columnIndicies.push({ index: i, fieldName: grid.columnOption(i, "dataField") });
        }

        $.each(columnIndicies, function (key, val) {
            strHeaderHtml += '<td style="background-color:#229C9E;background:#229C9E;text-align:center;"><b>' + columnIndicies[key]["fieldName"] + '</b></td>';
        });

        strHeaderHtml += '</tr>';

        $.each($scope.OrderHeader, function (Hkey, Hval) {
            strHeaderHtml += '<tr>';
            $.each(columnIndicies, function (key, val) {
                strHeaderHtml += '<td>' + $scope.OrderHeader[Hkey][columnIndicies[key]["fieldName"]] + '</td>';
            });
            strHeaderHtml += '</tr>';
        });

        strHeaderHtml += '</table>';

        var strOItemHtml = '<table id="tex2"><tr style="background-color:#1d83ec;color:#ffffff">';
        columnIndicies = [];
        var tab2colCount = tab2.columnCount();
        for (var j = 0; j < tab2colCount; j++) {
            if ('' + tab2.columnOption(j).visible + '' == 'true')
                columnIndicies.push({ index: j, fieldName: tab2.columnOption(j, "dataField") });
        }

        $.each(columnIndicies, function (key, val) {
            strOItemHtml += '<td style="background-color:#229C9E;background:#229C9E;text-align:center;"><b>' + columnIndicies[key]["fieldName"] + '</b></td>';
        });
        strOItemHtml += '</tr>';

        $.each($scope.OrderComp, function (Orderkey, Compval) {
            strOItemHtml += '<tr>';
            $.each(columnIndicies, function (key, val) {
                strOItemHtml += '<td>' + $scope.OrderComp[Orderkey][columnIndicies[key]["fieldName"]] + '</td>';
            });
            strOItemHtml += '</tr>';
        });

        strOItemHtml += '</table>';

        $('#AllExportDiv1').html(strHeaderHtml);
        $('#AllExportDiv2').html(strOItemHtml);

        if ($rootScope.mRefinedDash == true) {
            var tab3 = $("#tab3").dxDataGrid("instance");
            var strProductHtml = '<table id="tex3"><tr style="background-color:#1d83ec;color:#ffffff">';
            columnIndicies = [];
            var tab3colCount = tab3.columnCount();
            for (var k = 0; k < tab3colCount; k++) {
                if ('' + tab3.columnOption(k).visible + '' == 'true')
                    columnIndicies.push({ index: k, fieldName: tab3.columnOption(k, "dataField") });
            }

            $.each(columnIndicies, function (key, val) {
                strProductHtml += '<td style="background-color:#229C9E;background:#229C9E;text-align:center;"><b>' + columnIndicies[key]["fieldName"] + '</b></td>';
            });
            strProductHtml += '</tr>';

            $.each($scope.ProductMst, function (Pkey, Cval) {
                strProductHtml += '<tr>';
                $.each(columnIndicies, function (PIkey, val) {
                    strProductHtml += '<td>' + $scope.ProductMst[Pkey][columnIndicies[PIkey]["fieldName"]] + '</td>';
                });
                strProductHtml += '</tr>';
            });

            strProductHtml += '</table>';
            $('#AllExportDiv3').html(strProductHtml);

            var tab4 = $("#tab4").dxDataGrid("instance");
            var strQualityHtml = '<table id="tex4"><tr style="background-color:#1d83ec;color:#ffffff">';
            columnIndicies = [];
            var tab4colCount = tab4.columnCount();
            for (var k = 0; k < tab4colCount; k++) {
                if ('' + tab4.columnOption(k).visible + '' == 'true')
                    columnIndicies.push({ index: k, fieldName: tab4.columnOption(k, "dataField") });
            }

            $.each(columnIndicies, function (key, val) {
                strQualityHtml += '<td style="background-color:#229C9E;background:#229C9E;text-align:center;"><b>' + columnIndicies[key]["fieldName"] + '</b></td>';
            });
            strQualityHtml += '</tr>';

            $.each($scope.QualityPARAM, function (Pkey, Cval) {
                strQualityHtml += '<tr>';
                $.each(columnIndicies, function (PIkey, val) {
                    strQualityHtml += '<td>' + $scope.QualityPARAM[Pkey][columnIndicies[PIkey]["fieldName"]] + '</td>';
                });
                strQualityHtml += '</tr>';
            });

            strQualityHtml += '</table>';

            $('#AllExportDiv4').html(strQualityHtml);
            tablesToExcel(['tex1', 'tex2', 'tex3', 'tex4'], [$('#btnOrderHeader').html(), $('#btnOrderComp').html(), $('#btnProductMst').html(), $('#btnQualityParam').html()], 'ExportData.xls', 'Excel');
        }
        else {
            tablesToExcel(['tex1', 'tex2'], [$('#btnPOrderHeader').html(), $('#btnPOrderComp').html()], 'ExportData.xls', 'Excel');
        }

        $('#AllExportDiv1').html('');
        $('#AllExportDiv2').html('');
        $('#AllExportDiv3').html('');
        $('#AllExportDiv4').html('');

    });

    //showloader = function () {
    //    load.style.display = "block";
    //    spin.style.display = "block";
    //}

    //hideloader = function () {
    //    load.style.display = "none";
    //    spin.style.display = "none";
    //};

    var tablesToExcel = (function () {
        var filename = 'ExportData' + ".xls";
        var uri = 'data:application/vnd.ms-excel;base64,'
        , tmplWorkbookXML = '<?xml version="1.0"?><?mso-application progid="Excel.Sheet"?><Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet" xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">'
          + '<DocumentProperties xmlns="urn:schemas-microsoft-com:office:office"><Author>Ravi</Author><Created>{created}</Created></DocumentProperties>'
          + '<Styles>'
          + '<Style ss:ID="Date"><NumberFormat ss:Format="Medium Date"></NumberFormat></Style>'
          + '</Styles>'
          + '{worksheets}</Workbook>'
        , tmplWorksheetXML = '<Worksheet ss:Name="{nameWS}"><Table>{rows}</Table></Worksheet>'
        , tmplCellXML = '<Cell{attributeStyleID}{attributeFormula}><Data ss:Type="{nameType}">{data}</Data></Cell>'
        , base64 = function (s) { return window.btoa(unescape(encodeURIComponent(s))) }
        , format = function (s, c) { return s.replace(/{(\w+)}/g, function (m, p) { return c[p]; }) }
        return function (tables, wsnames, wbname, appname) {
            var ctx = "";
            var workbookXML = "";
            var worksheetsXML = "";
            var rowsXML = "";
            for (var i = 0; i < tables.length; i++) {
                if (!tables[i].nodeType) tables[i] = document.getElementById(tables[i]);
                console.log(tables[i]);
                for (var j = 0; j < tables[i].rows.length; j++) {
                    rowsXML += '<Row>'
                    for (var k = 0; k < tables[i].rows[j].cells.length; k++) {
                        var dataValue = tables[i].rows[j].cells[k].getAttribute("data-value");
                        dataValue = (dataValue) ? dataValue : tables[i].rows[j].cells[k].innerText.replace('_', ' ');
                        ctx = {
                            attributeStyleID: ''
                               , nameType: 'String'
                               , data: dataValue
                               , attributeFormula: ''
                        };
                        rowsXML += format(tmplCellXML, ctx);
                    }
                    rowsXML += '</Row>'
                }
                ctx = { rows: rowsXML, nameWS: wsnames[i] || 'Sheet' + i };
                worksheetsXML += format(tmplWorksheetXML, ctx);
                rowsXML = "";
            }

            ctx = { created: (new Date()).getTime(), worksheets: worksheetsXML };
            workbookXML = format(tmplWorkbookXML, ctx);

            var blob = new Blob([workbookXML], { type: 'data:application/vnd.ms-excel' });
            //var link = document.createElement("A");
            //link.href = uri + base64(workbookXML);
            //link.download = wbname || 'Workbook.xls';
            //link.target = '_blank';
            //document.body.appendChild(link);
            //link.click();
            //document.body.removeChild(link);



            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(blob, filename);
            } else {
                var linkElement = document.createElement('a');
                var url = window.URL.createObjectURL(blob);
                linkElement.setAttribute('href', url);
                linkElement.setAttribute("download", filename);
                var clickEvent = new MouseEvent("click", {
                    "view": window,
                    "bubbles": true,
                    "cancelable": false
                });
                linkElement.dispatchEvent(clickEvent);
            }
        }
    })();
}]);
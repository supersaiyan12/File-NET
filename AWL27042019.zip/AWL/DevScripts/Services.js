﻿app.service('Applicationservice', ['$http', '$window', 'AppURL', 'AuthenticationService', function ($http, $window, AppURL, AuthenticationService) {

    this.BaseURL = function () {
        return AppURL;
    }

    this.GetToken = function (username, password) {
        var data = "grant_type=password&username=" + username + "&password=" + password;
        return $http.post(AppURL + "/token", data, {
            headers:
               { 'Content-Type': 'application/x-www-form-urlencoded' }
        });
    }

    this.GetparentMenuDtl = function (personglcode) {
        return $http.get(AppURL + "/api/MenuAPI/GetparentMenuDtl?fk_personGlCode=" + personglcode, AuthenticationService.setHeader($http));
    };

    this.GetChildMenuDtl = function (parentGlCode, personglcode) {
        return $http.get(AppURL + "/api/MenuAPI/GetChildMenuDtl?fk_personGlCode=" + personglcode + "&fk_parentglcode=" + parentGlCode, AuthenticationService.setHeader($http));
    };

    this.GetLoginDetail = function (username, password) {
        return $http.get(AppURL + "/api/MenuAPI/GetloginDetail?username=" + username + "&password=" + password);
    };

    this.Logout = function Logout() {
        return $http.get(AppURL + "/api/MenuAPI/Logout/");
    };

    this.CheckDormantAccount = function (personglcode) {
        return $http.get(AppURL + "/api/MenuAPI/CheckDormantAccount?Id=" + personglcode, AuthenticationService.setHeader($http));
    };

    this.InsertLoginFailedAttempts = function (username) {
        return $http.post(AppURL + "/api/MenuAPI/InsertLoginFailedAttempts?username=" + username, AuthenticationService.setHeader($http));
    };

    this.CheckLogin = function () {
        return $http.get(AppURL + "/api/MenuAPI/CheckLogin", AuthenticationService.setHeader($http));
    };

    this.GetMenuList = function (fk_PersonGlCode, chrLoginType) {
        return $http.get(AppURL + "/api/MenuAPI/GetMenuList?fk_PersonGlCode=" + fk_PersonGlCode + "&chrLoginType=" + chrLoginType, AuthenticationService.setHeader($http));
    };

    this.GetMenuListAccordingRole = function (fk_PersonGlCode, chrLoginType) {
        return $http.get(AppURL + "/api/MenuAPI/GetMenuListAccordingRole?fk_PersonGlCode=" + fk_PersonGlCode + "&chrLoginType=" + chrLoginType, AuthenticationService.setHeader($http));
    };

    this.GetBreadCrumbDetail = function (fk_PersonGlCode, MenuID) {
        return $http.get(AppURL + "/api/MenuAPI/GetBreadCrumbDetail?fk_PersonGlCode=" + fk_PersonGlCode + "&MenuID=" + MenuID, AuthenticationService.setHeader($http));
    };

    this.GetMenuListForMenuAccess = function (fk_RoleGlCode) {
        return $http.get(AppURL + "/api/MenuAPI/GetMenuListForMenuAccess?fk_RoleGlCode_Other=" + fk_RoleGlCode, AuthenticationService.setHeader($http));
    };

    this.CheckMenuRights = function (fk_MenuGlCode, fk_RoleGlCode, varPageURL) {
        return $http.get(AppURL + "/api/MenuAPI/CheckMenuRights?fk_MenuGlCode=" + fk_MenuGlCode + "&fk_RoleGlCode=" + fk_RoleGlCode + "&URLPage=" + varPageURL, AuthenticationService.setHeader($http));
    };

    this.refreshToken = function () {
        var token = AuthenticationService.getTokenInfo();
        var data = "grant_type=refresh_token&refresh_token=" + token.refresh_token + "&client_id=";
        return $http.post(AppURL + "/token", data);
    };

    this.GetPersonDetails = function (intOperatorID) {
        return $http.get(AppURL + "/api/MenuAPI/GetPersonDetails?intOperatorID=" + intOperatorID);
    };

    this.SavePersonDetails = function (jsonData) {
        var data = jsonData;
        return $http.post(AppURL + "/api/MenuAPI/SavePersonDetails", data, AuthenticationService.setHeaderWithJsonContentType($http));
    };

    this.DeletePersonDetails = function (jsonData) {

        var data = jsonData;
        return $http.post(AppURL + "/api/MenuAPI/DeletePersonDetails", data, AuthenticationService.setHeaderWithJsonContentType($http));
    };

    //this.btnClickGo = function (objPenetration) {
    //    return $http.get(AppURL + "/api/MenuAPI/btnGo_Click?objPenetrationObject=" + objPenetration);

    //this.btnClickGo = function (objPenetration) {
    //    return $http.get(AppURL + "/api/MenuAPI/btnGo_Click?objPenetrationObject=" + objPenetration);

    //Person Master

    this.GetPersonMasterList = function () {
        return $http.get(AppURL + "/api/MenuAPI/GetPersonMasterList", AuthenticationService.setHeader($http));
    };

    this.SavePersonMasterDetails = function (jsonData, varRoleId) {
        var data = jsonData;
        return $http.post(AppURL + "/api/MenuAPI/SavePersonMasterDetails?varRoleId=" + varRoleId, data, AuthenticationService.setHeaderWithJsonContentType($http));

    };

    this.getDirectory_UserList = function () {
        return $http.get(AppURL + "/api/MenuAPI/getDirectory_UserList", AuthenticationService.setHeader($http));
    };

    this.GetDesignationList = function () {
        return $http.get(AppURL + "/api/MenuAPI/GetDesignationList", AuthenticationService.setHeader($http));
    };

    this.getPlantList = function () {
        return $http.get(AppURL + "/api/MenuAPI/getPlantList", AuthenticationService.setHeader($http));
    };

    this.GetRoleList = function () {
        return $http.get(AppURL + "/api/MenuAPI/GetRoleList", AuthenticationService.setHeader($http));
    };

    //Menu
    this.SaveRoleWiseMenuAccess = function (jsonData) {
        var data = jsonData;
        return $http.post(AppURL + "/api/MenuAPI/SaveRoleWiseMenuAccess", data, AuthenticationService.setHeaderWithJsonContentType($http));
    };

    //EmailSmsSetting
    this.GetSubject = function (type) {
        return $http.get(AppURL + "/api/MenuAPI/GetEmailSmsSubjectList?type=" + type, AuthenticationService.setHeader($http));
    };

    this.GetUserList = function (type) {
        return $http.get(AppURL + "/api/MenuAPI/GetUserList", AuthenticationService.setHeader($http));
    };

    this.SaveEmailSmsSetting = function (jsonData) {
        var data = jsonData;
        return $http.post(AppURL + "/api/MenuAPI/SaveEmailSmsSetting", data, AuthenticationService.setHeader($http));
    };

    this.GetEmailSMSDetail = function (type) {
        return $http.get(AppURL + "/api/MenuAPI/GetEmailSMSDetail?type=" + type, AuthenticationService.setHeader($http));
    };

    this.GetSharePointUserExist = function (Usermname) {
        return $http.get(AppURL + "/api/MenuAPI/GetSharepointUserDetails?strUsername=" + Usermname, AuthenticationService.setHeader($http));
    };
    //end

    this.GetConfigSectionList = function () {
        return $http.get(AppURL + "/api/MenuAPI/GetConfigSectionList", AuthenticationService.setHeader($http));
    };

    this.GetFilterSectionList = function () {
        return $http.get(AppURL + "/api/MenuAPI/GetFilterSectionList", AuthenticationService.setHeader($http));
    };

    this.GetUserList = function (type) {
        return $http.get(AppURL + "/api/MenuAPI/GetUserList", AuthenticationService.setHeader($http));
    };

    this.ReportSettingTranscationService = function (jsondata, SelectedRoleId, chrFlag) {

        return $http.post(AppURL + "/api/MenuAPI/ReportSettingTranscationAPI?chrFlag=" + chrFlag + "&SelectedRoleId=" + SelectedRoleId, jsondata, AuthenticationService.setHeader($http));
    };

    this.getReportTableListService = function (fk_ReportTemplateGlCode) {
        return $http.get(AppURL + "/api/MenuAPI/getReportTableListService?fk_ReportTemplateGlCode=" + fk_ReportTemplateGlCode, AuthenticationService.setHeader($http));
    };

    this.getConfigured_ReportTamplateListService = function (fk_ReportTemplateGlCode, chrType) {
        return $http.get(AppURL + "/api/MenuAPI/getConfigured_ReportTamplateListService?fk_ReportTemplateGlCode=" + fk_ReportTemplateGlCode + "&chrType=" + chrType, AuthenticationService.setHeader($http));
    };

    this.getFilterList_Data_Service = function (strFilter, strColunHeader, strGroupColumn, stTable, strFlag) {
        return $http.post(AppURL + "/api/MenuAPI/getFilterList_Data_Service?strFilter=" + strFilter + "&strColumnHeader=" + strColunHeader + "&strGroupColumn=" + strGroupColumn + "&strTableName=" + stTable + "&strFlag=" + strFlag, AuthenticationService.setHeader($http));
    };

    //Start :: Config Report Master
    this.getReportTamplateListService = function (chrTableType, fk_MenuGlCode, varAction, intGlCode) {
        return $http.get(AppURL + "/api/MenuAPI/getReportTamplateListAPI?chrTableType=" + chrTableType + "&fk_MenuGlCode=" + fk_MenuGlCode + "&varAction=" + varAction + "&intGlCode=" + intGlCode, AuthenticationService.setHeader($http));
    };

    //this.ReportSettingTamplateDeleteService = function (intglcode, flag) {
    //    return $http.post(AppURL + "/api/MenuAPI/ReportSettingTamplateDeleteAPI?intglcode =" + intglcode + "&flag=" + flag, AuthenticationService.setHeader($http));
    //};

    this.getReportTableDetailService = function (ReportType) {
        return $http.get(AppURL + "/api/MenuAPI/getReportTableDetailAPI?strFlag=" + ReportType, AuthenticationService.setHeader($http));
    };
    // Dashboard Changes
    this.Get_General_List = function (fk_PersonGlCode, RoleCode, varAction, fk_PlantGlCode, varProd_Type) {
        return $http.get(AppURL + "/api/DashbaordAPI/AWL_Get_General_List?fk_PersonGlCode=" + fk_PersonGlCode + "&RoleCode=" + RoleCode + "&varAction=" + varAction + "&fk_PlantGlCode=" + fk_PlantGlCode + "&varProd_Type=" + varProd_Type, AuthenticationService.setHeader($http));
    };

    this.GetALLPlant_Product_Refind_Dashboard = function (Fk_BrandGlCode, CSVFK_PlantGlCode, dtFromDate, dtToDate, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/GetALLPlant_Product_Refind_Dashboard?Fk_BrandGlCode=" + Fk_BrandGlCode + "&CSVFK_PlantGlCode=" + CSVFK_PlantGlCode + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.GetALLProduct_Plant_Refind_Dashboard = function (Fk_PlantGlCode, CSVFK_BrandGlCode, dtFromDate, dtToDate, varAction, isSecPrd) {
        return $http.get(AppURL + "/api/DashbaordAPI/GetALLProduct_Plant_Refind_Dashboard?Fk_PlantGlCode=" + Fk_PlantGlCode + "&CSVFK_BrandGlCode=" + CSVFK_BrandGlCode + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&varAction=" + varAction + "&isSecPrd=" + isSecPrd, AuthenticationService.setHeader($http));
    };

    this.Get_Refined_Dashboard = function (Fk_BrandGlCode, fk_PlantGlCode, dtFromDate, dtToDate, QtyType, Type, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/Get_Refined_Dashboard?Fk_BrandGlCode=" + Fk_BrandGlCode + "&fk_PlantGlCode=" + fk_PlantGlCode + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&QtyType=" + QtyType + "&Type=" + Type + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.Get_Refinary_Wise_Refined_Dashboard = function (Fk_BrandGlCode, fk_PlantGlCode, dtFromDate, dtToDate, fk_RefinaryGlCode, fk_ComponantGlCode, QtyType, Type, chrMonthType, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/Get_Refinary_Wise_Refined_Dashboard?Fk_BrandGlCode=" + Fk_BrandGlCode + "&fk_PlantGlCode=" + fk_PlantGlCode + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&fk_RefinaryGlCode=" + fk_RefinaryGlCode + "&fk_ComponantGlCode=" + fk_ComponantGlCode + "&QtyType=" + QtyType + "&Type=" + Type + "&chrMonthType=" + chrMonthType + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.Get_Yearly_QuarterNo = function () {
        return $http.get(AppURL + "/api/DashbaordAPI/Get_Yearly_QuarterNo", AuthenticationService.setHeader($http));
    };

    this.Get_Date_Range = function (DateCycle) {
        return $http.get(AppURL + "/api/DashbaordAPI/Get_Date_Range?Action=" + DateCycle, AuthenticationService.setHeader($http));
    };

    this.GET_REFINARY_NAME_UNIT = function (fk_plantid, fk_BrandID, fk_productid, fk_RefinaryGlCode, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_GET_REFINARY_NAME_UNIT?fk_plantid=" + fk_plantid + "&fk_BrandID=" + fk_BrandID + "&fk_productid=" + fk_productid + "&fk_RefinaryGlCode=" + fk_RefinaryGlCode + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.USP_ALLPlant_Product_Packaging_Dashboard = function (CSVFK_PlantGlCode, varBrandName, dtFromDate, dtToDate, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_ALLPlant_Product_Packaging_Dashboard?CSVFK_PlantGlCode=" + CSVFK_PlantGlCode + "&varBrandName=" + varBrandName + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.keepAlivesession = function () {
        return $http.get(AppURL + "/api/MenuAPI/keepAlive", AuthenticationService.setHeader($http));
    }

    this.Get_Refined_Product_Marquee = function (fk_PlantGlCode) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_Get_Refined_Product_Marquee?fk_PlantGlCode=" + fk_PlantGlCode, AuthenticationService.setHeader($http));
    }

    this.USP_Get_Packaging_Product_Marquee = function (fk_PlantGlCode) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_Get_Packaging_Product_Marquee?fk_PlantGlCode=" + fk_PlantGlCode, AuthenticationService.setHeader($http));
    }

    this.USP_ALLProduct_Plant_Packaging_Dashboard = function (Fk_PlantGlCode, CSVFK_BrandGlCode, dtFromDate, dtToDate, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_ALLProduct_Plant_Packaging_Dashboard?Fk_PlantGlCode=" + Fk_PlantGlCode + "&CSVFK_BrandGlCode=" + CSVFK_BrandGlCode + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.USP_ALLProduct_Plant_Packing_LineWise = function (Fk_PlantGlCode, CSVFK_BrandGlCode, dtFromDate, dtToDate, chrMonthType, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_ALLProduct_Plant_Packing_LineWise?Fk_PlantGlCode=" + Fk_PlantGlCode + "&CSVFK_BrandGlCode=" + CSVFK_BrandGlCode + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&chrMonthType=" + chrMonthType + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.USP_Get_Monthly_Plant_Perfomance_ScoreCard = function (dtFromDate, dtToDate, Fk_PlantGlCode) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_Get_Monthly_Plant_Perfomance_ScoreCard?dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&Fk_PlantGlCode=" + Fk_PlantGlCode, AuthenticationService.setHeader($http));
    };

    this.USP_GET_Daily_Ranking_Details = function (dtFromDate, dtToDate) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_GET_Daily_Ranking_Details?dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate, AuthenticationService.setHeader($http));
    };

    this.Get_RefinedFactTable = function (fk_Report_ConfigGlCode) {
        return $http.get(AppURL + "/api/MenuAPI/Get_RefinedFactTable?fk_Report_ConfigGlCode=" + fk_Report_ConfigGlCode, AuthenticationService.setHeader($http));
    };

    this.GetVersion = function (strModule) {
        return $http.get(AppURL + "/api/WebServices/GetModuleversion?strModule=" + strModule, AuthenticationService.setHeader($http));
    };

    this.GetApprovedReqList = function () {
        return $http.get(AppURL + "/api/MenuAPI/GetApprovedRequestList", AuthenticationService.setHeader($http));
    };

    this.update_Application_req = function (intid, Approved, pcode) {
        return $http.post(AppURL + "/api/MenuAPI/Update_ApplicationReq?pintGlCode=" + intid + "&pchrApproved=" + Approved + "&pApprovedBy=" + pcode, AuthenticationService.setHeader($http));
    };

    this.USP_PackType_Wise_Packaging_Dashboard = function (Fk_PlantGlCode, varPackType, strRefinaryCode, ComponentName, ComponentUOM, dtFromDate, dtToDate, chrMonthType, varAction) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_PackType_Wise_Packaging_Dashboard?Fk_PlantGlCode=" + Fk_PlantGlCode + "&varPackType=" + varPackType + "&strRefinaryCode=" + strRefinaryCode + "&ComponentName=" + ComponentName + "&ComponentUOM=" + ComponentUOM + "&dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&chrMonthType=" + chrMonthType + "&varAction=" + varAction, AuthenticationService.setHeader($http));
    };

    this.Insert_Login_Details = function (intGlCode, varsystemname, varlogouttime, varusername, varpassword, varpersonglcode, varApplication, varformname, varAppVersion, varFlag) {
        return $http.post(AppURL + "/api/MenuAPI/Insert_Login_Details?intGlCode=" + intGlCode + "&varsystemname=" + varsystemname + "&varlogouttime=" + varlogouttime + "&varusername=" + varusername + "&varpassword=" + varpassword + "&varpersonglcode=" + varpersonglcode + "&varApplication=" + varApplication + "&varformname=" + varformname + "&varAppVersion=" + varAppVersion + "&varFlag=" + varFlag, AuthenticationService.setHeader($http));
    };

    this.Insert_Login_Fail_Details = function (intGlCode, varsystemname, varlogouttime, varusername, varpassword, varpersonglcode, varApplication, varformname, varAppVersion, varFlag) {
        return $http.post(AppURL + "/api/WebServices/Insert_Login_Fail_Details?intGlCode=" + intGlCode + "&varsystemname=" + varsystemname + "&varlogouttime=" + varlogouttime + "&varusername=" + varusername + "&varpassword=" + varpassword + "&varpersonglcode=" + varpersonglcode + "&varApplication=" + varApplication + "&varformname=" + varformname + "&varAppVersion=" + varAppVersion + "&varFlag=" + varFlag, AuthenticationService.setHeader($http));
    };
    this.Get_LoginRecord_Details = function (dtFromDate, dtToDate, Flag) {
        return $http.post(AppURL + "/api/MenuAPI/Get_LoginRecord_Details?dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&Flag=" + Flag, AuthenticationService.setHeader($http));
    };
    this.USP_Refined_MISReport_1 = function (dtFromMonth, FK_BrandGlCode, FK_PlantGlCode) {
        return $http.post(AppURL + "/api/MenuAPI/USP_Refined_MISReport_1?dtFromMonth=" + dtFromMonth + "&FK_BrandGlCode=" + FK_BrandGlCode + "&FK_PlantGlCode=" + FK_PlantGlCode, AuthenticationService.setHeader($http));
    };
    this.USP_Get_Refine_AutoPlayProd = function (dtFromDate, dtToDate, varFlag) {
        return $http.get(AppURL + "/api/DashbaordAPI/USP_Get_Refine_AutoPlayProd?dtFromDate=" + dtFromDate + "&dtToDate=" + dtToDate + "&varFlag=" + varFlag, AuthenticationService.setHeader($http));
    };
}]);


app.service('AuthenticationService', ['$http', '$q', '$window',
        function ($http, $q, $window) {
            var tokenInfo;

            this.setTokenInfo = function (data) {
                tokenInfo = data;
                $window.localStorage.setItem("TokenInfo", JSON.stringify(tokenInfo));
            }

            this.getTokenInfo = function () {
                return JSON.parse($window.localStorage.getItem("TokenInfo"));
            }

            this.removeToken = function () {
                tokenInfo = null;
                $window.localStorage.setItem("TokenInfo", null);
            }

            this.init = function () {
                if ($window.getItem("TokenInfo")) {
                    tokenInfo = JSON.parse($window.localStorage.getItem("TokenInfo"));
                }
            }

            this.setHeader = function (http) {
                delete http.defaults.headers.common['X-Requested-With'];
                if ((this.getTokenInfo() != null && this.getTokenInfo().access_token != undefined && this.getTokenInfo().access_token != null && this.getTokenInfo().access_token != "")) {
                    var Headers = "{Authorization: Bearer " + this.getTokenInfo().access_token + "}";
                    http.defaults.headers.common['Authorization'] = 'Bearer ' + this.getTokenInfo().access_token;
                    http.defaults.headers.common['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
                    return Headers;
                }
            }
            this.setHeaderWithJsonContentType = function (http) {
                delete http.defaults.headers.common['X-Requested-With'];
                if ((this.getTokenInfo() != null && this.getTokenInfo() != undefined && this.getTokenInfo() != null && this.getTokenInfo() != "")) {
                    var Headers = "{Authorization: Bearer " + this.getTokenInfo().access_token + "}";
                    http.defaults.headers.common['Authorization'] = 'Bearer ' + this.getTokenInfo().access_token;
                    http.defaults.headers.common['Content-Type'] = 'application/json';
                    return Headers;
                }
            }
        }
]);